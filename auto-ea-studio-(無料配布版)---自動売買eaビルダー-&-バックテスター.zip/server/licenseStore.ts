import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export interface StoredLicense {
  code: string;
  email: string;
  type: 'lifetime' | 'subscription';
  status: 'active' | 'cancelled' | 'expired';
  createdAt: string;
  expiresAt: string | null;
  maxDevices: number;
  usedDevices: string[];
  notes?: string;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const LICENSES_FILE = path.join(DATA_DIR, 'licenses.json');

// 初期シード用デモライセンス（テスト用）
const INITIAL_DEMO_LICENSES: StoredLicense[] = [
  {
    code: 'PRO-LIFE-7777-8888',
    email: 'test@example.com',
    type: 'lifetime',
    status: 'active',
    createdAt: new Date().toISOString(),
    expiresAt: null,
    maxDevices: 5,
    usedDevices: [],
    notes: '【テスト用】買い切り永久ライセンス',
  },
  {
    code: 'PRO-SUB-2026-9999',
    email: 'sub@example.com',
    type: 'subscription',
    status: 'active',
    createdAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    maxDevices: 5,
    usedDevices: [],
    notes: '【テスト用】月額サブスクリプション（有効期間30日）',
  },
];

function ensureDataFile(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(LICENSES_FILE)) {
      fs.writeFileSync(LICENSES_FILE, JSON.stringify(INITIAL_DEMO_LICENSES, null, 2), 'utf-8');
    }
  } catch (err) {
    console.error('Failed to initialize license data file:', err);
  }
}

export function loadLicenses(): StoredLicense[] {
  ensureDataFile();
  try {
    const raw = fs.readFileSync(LICENSES_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed;
    }
  } catch (err) {
    console.error('Error reading licenses file:', err);
  }
  return [...INITIAL_DEMO_LICENSES];
}

export function saveLicenses(licenses: StoredLicense[]): void {
  ensureDataFile();
  try {
    fs.writeFileSync(LICENSES_FILE, JSON.stringify(licenses, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving licenses file:', err);
  }
}

/**
 * ライセンスコード自動生成
 * 買い切り: PRO-LIFE-XXXX-XXXX
 * サブスク: PRO-SUB-XXXX-XXXX
 */
export function generateRandomCode(type: 'lifetime' | 'subscription'): string {
  const prefix = type === 'lifetime' ? 'PRO-LIFE' : 'PRO-SUB';
  const part1 = crypto.randomBytes(2).toString('hex').toUpperCase();
  const part2 = crypto.randomBytes(2).toString('hex').toUpperCase();
  return `${prefix}-${part1}-${part2}`;
}

/**
 * メールアドレス ＋ 認証コード の照合
 */
export function verifyLicense(
  rawEmail: string,
  rawCode: string,
  deviceId?: string
): {
  success: boolean;
  error?: string;
  license?: {
    isPro: boolean;
    email: string;
    code: string;
    type: 'lifetime' | 'subscription';
    expiresAt: string | null;
  };
} {
  const email = (rawEmail || '').trim().toLowerCase();
  const code = (rawCode || '').trim().toUpperCase();

  if (!email || !code) {
    return {
      success: false,
      error: 'メールアドレスと認証コードの両方を入力してください。',
    };
  }

  const licenses = loadLicenses();
  const target = licenses.find(
    (lic) => lic.email.trim().toLowerCase() === email && lic.code.trim().toUpperCase() === code
  );

  if (!target) {
    return {
      success: false,
      error: '指定されたメールアドレスと認証コードが一致しないか、存在しません。ご確認の上もう一度お試しください。',
    };
  }

  if (target.status !== 'active') {
    return {
      success: false,
      error: 'この認証コードは現在無効化（解約または停止）されています。',
    };
  }

  // サブスクリプションの有効期限判定
  if (target.type === 'subscription' && target.expiresAt) {
    const expireTime = new Date(target.expiresAt).getTime();
    if (Date.now() > expireTime) {
      return {
        success: false,
        error: `サブスクリプションの有効期限（${new Date(target.expiresAt).toLocaleDateString()}）が切れています。更新手続きを行ってください。`,
      };
    }
  }

  // デバイスID登録（最大端末数制限）
  if (deviceId && !target.usedDevices.includes(deviceId)) {
    if (target.usedDevices.length >= target.maxDevices) {
      return {
        success: false,
        error: `このライセンスの最大利用可能端末数（${target.maxDevices}台）に達しています。`,
      };
    }
    target.usedDevices.push(deviceId);
    saveLicenses(licenses);
  }

  return {
    success: true,
    license: {
      isPro: true,
      email: target.email,
      code: target.code,
      type: target.type,
      expiresAt: target.expiresAt,
    },
  };
}

/**
 * 新規ライセンス作成（Stripe Webhook または 管理者発行用）
 */
export function createNewLicense(params: {
  email: string;
  type: 'lifetime' | 'subscription';
  customCode?: string;
  days?: number;
  notes?: string;
}): StoredLicense {
  const licenses = loadLicenses();
  const email = params.email.trim().toLowerCase();
  const code = params.customCode || generateRandomCode(params.type);
  const now = new Date();

  let expiresAt: string | null = null;
  if (params.type === 'subscription') {
    const validityDays = params.days && params.days > 0 ? params.days : 30;
    expiresAt = new Date(now.getTime() + validityDays * 24 * 60 * 60 * 1000).toISOString();
  }

  const newLic: StoredLicense = {
    code,
    email,
    type: params.type,
    status: 'active',
    createdAt: now.toISOString(),
    expiresAt,
    maxDevices: 5,
    usedDevices: [],
    notes: params.notes || (params.type === 'lifetime' ? 'Stripe決済 買い切り' : 'Stripe決済 月額サブスク'),
  };

  // 既存の同一コードがあれば更新、なければ追加
  const existingIdx = licenses.findIndex((l) => l.code === code);
  if (existingIdx >= 0) {
    licenses[existingIdx] = newLic;
  } else {
    licenses.unshift(newLic);
  }

  saveLicenses(licenses);
  return newLic;
}

/**
 * ユーザー作成済みのメール送信サービスへの通知連携
 * （https://ai.studio/apps/a706fedd-4bdd-4004-a93a-5f599d78e28e）
 */
export async function notifyMailService(payload: {
  email: string;
  code: string;
  type: 'lifetime' | 'subscription';
  expiresAt: string | null;
}) {
  const mailAppUrl = process.env.MAIL_SERVICE_WEBHOOK_URL || 'https://ai.studio/apps/a706fedd-4bdd-4004-a93a-5f599d78e28e';
  console.log(`[MailService] Sending license code to ${payload.email} via ${mailAppUrl}`, {
    code: payload.code,
    type: payload.type,
    expiresAt: payload.expiresAt,
  });

  try {
    // 外部Webhook URLが指定されていればPOST送信
    if (process.env.MAIL_SERVICE_WEBHOOK_URL) {
      await fetch(process.env.MAIL_SERVICE_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
    }
  } catch (err) {
    console.error('[MailService] Failed to ping mail service webhook:', err);
  }
}
