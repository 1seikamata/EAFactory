/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { BuyerConfig, BacktestResult, EASpec, SalesPackage, LicenseInfo } from './types';
import { runBacktest } from './services/backtester';
import { generateEASpec } from './services/mqlGenerator';
import { buildSalesPackage } from './services/salesCopyGenerator';
import { Header } from './components/Header';
import { BuyerConfigCard } from './components/BuyerConfigCard';
import { BacktestDashboard } from './components/BacktestDashboard';
import { SourceCodePanel } from './components/SourceCodePanel';
import { SalesPackagePanel } from './components/SalesPackagePanel';
import { AiAssistantModal } from './components/AiAssistantModal';
import { UpgradeModal, UpgradeTrigger } from './components/UpgradeModal';
import { LicenseModal } from './components/LicenseModal';
import { GenerationProgressModal } from './components/GenerationProgressModal';
import { ShareModal } from './components/ShareModal';
import { LanguageProvider, useLanguage } from './i18n/LanguageContext';
import {
  CheckCircle2,
  TrendingUp,
  FileText,
  Code2,
  Lock,
  Crown,
  Key,
} from 'lucide-react';

function AppContent() {
  const { t } = useLanguage();

  // PRO版ライセンス状態（ローカルストレージに永続化）
  const [licenseInfo, setLicenseInfo] = useState<LicenseInfo>(() => {
    try {
      const saved = localStorage.getItem('ea_maker_license');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to parse saved license', e);
    }
    return { isPro: false };
  });

  const [buyerConfig, setBuyerConfig] = useState<BuyerConfig>({
    pair: 'EURUSD',
    timeframe: 'M30',
    desiredPf: '1.2+',
    maxDrawdown: '10%',
    frequency: 'WEEKLY_3_5',
    maxPositions: '1',
    strategyPreset: 'AUTO',
    testPeriod: '3MONTHS',
  });

  const [eaSpec, setEaSpec] = useState<EASpec>(() => generateEASpec(buyerConfig));
  const [backtestResult, setBacktestResult] = useState<BacktestResult>(() =>
    runBacktest(buyerConfig)
  );
  const [salesPackage, setSalesPackage] = useState<SalesPackage>(() =>
    buildSalesPackage(buyerConfig, eaSpec, backtestResult)
  );

  const [isRunningBacktest, setIsRunningBacktest] = useState(false);
  const [isGeneratingModalOpen, setIsGeneratingModalOpen] = useState(false);
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [isUpgradeModalOpen, setIsUpgradeModalOpen] = useState(false);
  const [isLicenseModalOpen, setIsLicenseModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [upgradeTrigger, setUpgradeTrigger] = useState<UpgradeTrigger>('GENERAL');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [activeSection, setActiveSection] = useState<'all' | 'backtest' | 'code' | 'sales'>('all');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleOpenUpgradeModal = (trigger: UpgradeTrigger = 'GENERAL') => {
    setUpgradeTrigger(trigger);
    setIsUpgradeModalOpen(true);
  };

  // ライセンス有効化成功ハンドラ
  const handleActivateLicense = (license: LicenseInfo) => {
    setLicenseInfo(license);
    try {
      localStorage.setItem('ea_maker_license', JSON.stringify(license));
    } catch (e) {
      console.error(e);
    }
    showToast(
      license.type === 'lifetime'
        ? '👑 PRO版（買い切り永久ライセンス）が有効化されました！全機能が開放されました。'
        : '👑 PRO版（月額サブスクリプション）が有効化されました！全機能が開放されました。'
    );
  };

  // ライセンス解除ハンドラ
  const handleDeactivateLicense = () => {
    setLicenseInfo({ isPro: false });
    try {
      localStorage.removeItem('ea_maker_license');
    } catch (e) {
      console.error(e);
    }
    showToast('ライセンスを解除し、無料版に戻しました。');
  };

  const handleExecuteBacktest = () => {
    const newBacktest = runBacktest(buyerConfig);
    const newEa = generateEASpec(buyerConfig);
    const newSales = buildSalesPackage(buyerConfig, newEa, newBacktest);

    setBacktestResult(newBacktest);
    setEaSpec(newEa);
    setSalesPackage(newSales);
    setIsRunningBacktest(true);
    setIsGeneratingModalOpen(true);
  };

  const handleGenerationComplete = () => {
    setIsGeneratingModalOpen(false);
    setIsRunningBacktest(false);
    showToast(t.common.toastGenerated);

    setTimeout(() => {
      const equityCurveEl = document.getElementById('section-equity-curve') || document.getElementById('backtest-dashboard');
      if (equityCurveEl) {
        equityCurveEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 150);
  };

  const handleApplyAiStrategy = (aiData: any) => {
    if (aiData.mql5Code) {
      setEaSpec((prev) => ({
        ...prev,
        name: aiData.eaName || prev.name,
        conceptSummary: aiData.concept || prev.conceptSummary,
        mql5Code: aiData.mql5Code,
        mql4Code: aiData.mql4Code || prev.mql4Code,
      }));
    }

    if (aiData.salesHeadline || aiData.salesDescription) {
      setSalesPackage((prev) => ({
        ...prev,
        title: aiData.salesHeadline || prev.title,
        productOverview: aiData.salesDescription || prev.productOverview,
      }));
    }

    const newBacktest = runBacktest(buyerConfig);
    setBacktestResult(newBacktest);
    showToast(t.common.toastAiApplied);
  };

  const handleExportAll = () => {
    const isPro = Boolean(licenseInfo.isPro);
    const combinedData = {
      edition: isPro ? 'Pro_Edition' : 'Free_Edition',
      spec: eaSpec,
      backtest: backtestResult,
      sales: salesPackage,
      config: buyerConfig,
      mql5Code: isPro ? eaSpec.mql5Code : undefined,
      mql4Code: isPro ? eaSpec.mql4Code : undefined,
      exportedAt: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(combinedData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${eaSpec.name}_${isPro ? 'ProEdition' : 'FreeEdition'}_Package.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showToast(t.common.toastExported);
  };

  return (
    <div
      id="app-root"
      className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-cyan-500 selection:text-slate-950 w-full max-w-full overflow-x-hidden"
    >
      {/* Toast alert */}
      {toastMessage && (
        <div
          id="app-toast-alert"
          className="fixed bottom-5 right-5 z-50 bg-cyan-600 text-slate-950 px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-bold animate-in slide-in-from-bottom-5 border border-cyan-400"
        >
          <CheckCircle2 className="w-4 h-4 text-slate-950" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <Header
        onOpenAiModal={() => setIsAiModalOpen(true)}
        onExportAll={handleExportAll}
        onOpenUpgradeModal={handleOpenUpgradeModal}
        onOpenLicenseModal={() => setIsLicenseModalOpen(true)}
        onOpenShareModal={() => setIsShareModalOpen(true)}
        licenseInfo={licenseInfo}
        onActivateLicense={handleActivateLicense}
      />

      {/* Main Container */}
      <main id="main-content" className="w-full max-w-7xl mx-auto px-3 sm:px-4 lg:px-8 py-5 sm:py-6 space-y-6 overflow-x-hidden">
        {/* Navigation Quick Filter Tabs */}
        <div
          id="navigation-tabs-bar"
          className="w-full flex flex-wrap items-center justify-between gap-2.5 sm:gap-3 bg-slate-900/70 p-2 sm:p-2.5 rounded-xl border border-slate-800 shadow-md"
        >
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              id="nav-tab-all"
              onClick={() => setActiveSection('all')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                activeSection === 'all'
                  ? 'bg-slate-800 text-white border border-slate-700 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {t.common.allView}
            </button>
            <button
              id="nav-tab-backtest"
              onClick={() => setActiveSection('backtest')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeSection === 'backtest'
                  ? 'bg-slate-800 text-cyan-300 border border-slate-700 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.common.simulationNav} (PF {backtestResult.profitFactor})</span>
            </button>
            <button
              id="nav-tab-code"
              onClick={() => setActiveSection('code')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeSection === 'code'
                  ? 'bg-slate-800 text-cyan-300 border border-slate-700 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Code2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.common.codeNav}</span>
            </button>
            <button
              id="nav-tab-sales"
              onClick={() => setActiveSection('sales')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeSection === 'sales'
                  ? 'bg-slate-800 text-cyan-300 border border-slate-700 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.common.salesNav}</span>
            </button>
          </div>

          {licenseInfo.isPro ? (
            <button
              id="nav-license-button"
              type="button"
              onClick={() => setIsLicenseModalOpen(true)}
              className="flex items-center gap-1.5 text-xs text-amber-300 bg-amber-950/60 hover:bg-amber-950/90 border border-amber-500/50 px-3 py-1 rounded-lg transition cursor-pointer font-bold shadow-sm"
            >
              <Crown className="w-3.5 h-3.5 text-amber-400" />
              <span>PRO版 有効化中</span>
            </button>
          ) : (
            <button
              id="nav-upgrade-button"
              type="button"
              onClick={() => handleOpenUpgradeModal('GENERAL')}
              className="flex items-center gap-1.5 text-xs text-amber-300 bg-amber-950/40 hover:bg-amber-950/70 border border-amber-800/60 px-3 py-1 rounded-lg transition cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{t.common.proUnlockNav}</span>
            </button>
          )}
        </div>

        {/* 1. Buyer Configuration Card */}
        <BuyerConfigCard
          config={buyerConfig}
          onChange={(newCfg) => {
            setBuyerConfig(newCfg);
          }}
          onRunBacktest={handleExecuteBacktest}
          isRunning={isRunningBacktest}
          onOpenUpgradeModal={handleOpenUpgradeModal}
          isProUser={licenseInfo.isPro}
        />

        {/* 2. Backtest Dashboard */}
        {(activeSection === 'all' || activeSection === 'backtest') && (
          <BacktestDashboard
            result={backtestResult}
            config={buyerConfig}
            onOpenUpgradeModal={handleOpenUpgradeModal}
            isProUser={licenseInfo.isPro}
          />
        )}

        {/* 3. Source Code Panel & Error/Zero-divide Re-check */}
        {(activeSection === 'all' || activeSection === 'code') && (
          <SourceCodePanel
            eaSpec={eaSpec}
            config={buyerConfig}
            backtestResult={backtestResult}
            onOpenUpgradeModal={handleOpenUpgradeModal}
            isProUser={licenseInfo.isPro}
            onActivateLicense={handleActivateLicense}
          />
        )}

        {/* 4. Sales Package & Manual Panel */}
        {(activeSection === 'all' || activeSection === 'sales') && (
          <SalesPackagePanel salesPackage={salesPackage} />
        )}
      </main>

      {/* Upgrade Guidance Modal */}
      <UpgradeModal
        isOpen={isUpgradeModalOpen}
        onClose={() => setIsUpgradeModalOpen(false)}
        trigger={upgradeTrigger}
        onOpenLicenseModal={() => setIsLicenseModalOpen(true)}
        onActivateLicense={handleActivateLicense}
      />

      {/* PRO License Authentication Modal */}
      <LicenseModal
        isOpen={isLicenseModalOpen}
        onClose={() => setIsLicenseModalOpen(false)}
        licenseInfo={licenseInfo}
        onActivateSuccess={handleActivateLicense}
        onDeactivate={handleDeactivateLicense}
        onOpenUpgradeModal={() => handleOpenUpgradeModal('GENERAL')}
      />

      {/* Gemini AI Strategy Customizer Modal */}
      <AiAssistantModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        config={buyerConfig}
        onApplyAiStrategy={handleApplyAiStrategy}
      />

      {/* Realistic Quant Simulation Progress Modal */}
      <GenerationProgressModal
        isOpen={isGeneratingModalOpen}
        config={buyerConfig}
        targetResult={backtestResult}
        onComplete={handleGenerationComplete}
        onOpenUpgradeModal={handleOpenUpgradeModal}
        isProUser={licenseInfo.isPro}
      />
      {/* Share & Distribute Modal */}
      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}

