/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  BuyerConfig,
  CurrencyPair,
  Timeframe,
  ProfitFactorGoal,
  MaxDrawdownLimit,
  TradeFrequency,
  MaxPositions,
  StrategyPreset,
} from '../types';
import {
  Sliders,
  RefreshCw,
  Sparkles,
  Check,
  Lock,
  Calendar,
  Wallet,
  Scale,
  ArrowRight,
  ArrowDown,
  Play,
  Zap,
  Layers,
  AlertTriangle,
  Clock,
  Percent,
  Coins,
} from 'lucide-react';
import { UpgradeTrigger } from './UpgradeModal';
import { useLanguage } from '../i18n/LanguageContext';

interface BuyerConfigCardProps {
  config: BuyerConfig;
  onChange: (newConfig: BuyerConfig) => void;
  onRunBacktest: () => void;
  isRunning: boolean;
  onOpenUpgradeModal: (trigger: UpgradeTrigger) => void;
  isProUser?: boolean;
}

export const BuyerConfigCard: React.FC<BuyerConfigCardProps> = ({
  config,
  onChange,
  onRunBacktest,
  isRunning,
  onOpenUpgradeModal,
  isProUser = false,
}) => {
  const { language, t } = useLanguage();
  const isEn = language === 'en';
  const [freqCategoryFilter, setFreqCategoryFilter] = useState<'ALL' | 'SWING' | 'DAY' | 'SCALP' | 'SMART'>('ALL');

  const updateField = <K extends keyof BuyerConfig>(key: K, value: BuyerConfig[K]) => {
    onChange({
      ...config,
      [key]: value,
    });
  };

  // 1. 通貨ペア：無料版はEUR/USDのみ。他はクリックでアップグレードモーダルへ誘導
  const pairOptions: {
    value: CurrencyPair;
    label: string;
    desc: string;
    isProOnly?: boolean;
  }[] = [
    {
      value: 'EURUSD',
      label: isEn ? 'EUR/USD (Euro / US Dollar)' : 'EUR/USD (ユーロドル)',
      desc: isEn
        ? 'Highest market liquidity & smooth trend formation (Free Edition)'
        : '世界最大取引量・素直なトレンド形成（無料版対象）',
      isProOnly: false,
    },
    {
      value: 'USDJPY',
      label: isEn ? 'USD/JPY (US Dollar / Japanese Yen)' : 'USD/JPY (ドル円)',
      desc: isEn ? 'Tightest spread & very popular among retail traders' : 'スプレッド狭小・日本人トレーダー一番人気',
      isProOnly: true,
    },
    {
      value: 'GBPJPY',
      label: isEn ? 'GBP/JPY (Pound / Japanese Yen)' : 'GBP/JPY (ポンド円)',
      desc: isEn ? 'High volatility with strong explosive momentum' : '高ボラティリティ・トレンド爆発力重視',
      isProOnly: true,
    },
    {
      value: 'EURJPY',
      label: isEn ? 'EUR/JPY (Euro / Japanese Yen)' : 'EUR/JPY (ユーロ円)',
      desc: isEn ? 'Optimal for stable cross-currency swing trading' : '安定スイングトレード向け',
      isProOnly: true,
    },
    {
      value: 'XAUUSD',
      label: isEn ? 'XAU/USD (Gold)' : 'XAU/USD (ゴールド)',
      desc: isEn ? 'Ultra-high intraday range & quick profit velocity' : '高ボラティリティ・短時間での高利得',
      isProOnly: true,
    },
    {
      value: 'AUTO',
      label: isEn ? '🌟 Other (Auto / Multi-Pair)' : '🌟 その他 (お任せ / マルチ通貨)',
      desc: isEn
        ? 'Auto-selects optimal win-rate pair based on market regime'
        : '市場環境に応じた最適高勝率ペアを自動適用',
      isProOnly: true,
    },
  ];

  // 2. 時間足：無料版でもすべて選択可能（制限なし）
  const timeframeOptions: { value: Timeframe; label: string; badge?: string }[] = [
    { value: 'M5', label: isEn ? 'M5 (5-min)' : 'M5 (5分足)' },
    { value: 'M15', label: isEn ? 'M15 (15-min)' : 'M15 (15分足)' },
    { value: 'M30', label: isEn ? 'M30 (30-min)' : 'M30 (30分足)', badge: t.config.recommendedBadge },
    { value: 'H1', label: isEn ? 'H1 (1-hour)' : 'H1 (1時間足)', badge: t.config.stableBadge },
    { value: 'H4', label: isEn ? 'H4 (4-hour)' : 'H4 (4時間足)', badge: t.config.swingBadge },
    { value: 'D1', label: isEn ? 'D1 (Daily)' : 'D1 (日足)' },
    { value: 'AUTO', label: isEn ? '🌟 Other (Auto)' : '🌟 その他 (自動選定)', badge: isEn ? 'Auto' : '自動' },
  ];

  // 3. PF：無料版は「PF 1.2以上」の1種類のみ。他は鍵付きPro限定
  const pfOptions: {
    value: ProfitFactorGoal;
    label: string;
    desc: string;
    isProOnly?: boolean;
  }[] = [
    {
      value: '1.2+',
      label: isEn ? 'PF 1.2+ (Core Standard)' : 'PF 1.2以上 (基本水準)',
      desc: isEn
        ? 'Most resilient and robust for long-term real account execution (Free Edition)'
        : '実運用で最も破綻しにくく長期安定（無料版選択可能）',
      isProOnly: false,
    },
    {
      value: '1.5+',
      label: isEn ? 'PF 1.5+ (High-Yield Balance)' : 'PF 1.5以上 (高収益バランス)',
      desc: isEn ? 'High mathematical expectancy popular for commercial EA sales' : 'プロ販売用で人気の高い高期待値設計',
      isProOnly: true,
    },
    {
      value: '1.8+',
      label: isEn ? 'PF 1.8+ (Prime Performance)' : 'PF 1.8以上 (極上パフォーマンス)',
      desc: isEn ? 'High profit efficiency through strict entry selectivity' : '厳選エントリーによる高い利益効率',
      isProOnly: true,
    },
    {
      value: '2.0+',
      label: isEn ? 'PF 2.0+ (Premium Edge)' : 'PF 2.0以上 (プレミアム目標)',
      desc: isEn ? 'Pursuing the highest tier statistical market edge' : '最高峰のエッジを追求',
      isProOnly: true,
    },
    {
      value: 'AUTO',
      label: isEn ? '🌟 Auto (AI Optimization)' : '🌟 お任せ (自動最適化)',
      desc: isEn ? 'Targets high yields while preventing curve-fitting' : '過剰最適化を避けつつ高収益を狙う',
      isProOnly: true,
    },
  ];

  // 4. 最大ドローダウン：無料版は「最大DD 10%以下」の1種類のみ初期選択
  const ddOptions: {
    value: MaxDrawdownLimit;
    label: string;
    desc: string;
    isProOnly?: boolean;
  }[] = [
    {
      value: '10%',
      label: isEn ? 'Max DD <= 10% (Safe Standard)' : '最大DD 10%以下 (標準安全圏)',
      desc: isEn
        ? 'Free Edition default: balanced risk tolerance maintaining healthy profitability'
        : '無料版初期設定・十分な収益性を維持する適度なリスク許容度',
      isProOnly: false,
    },
    {
      value: '5%',
      label: isEn ? 'Max DD <= 5% (Target Achieved)' : '最大DD 5%以下 (指定目標クリア)',
      desc: isEn ? 'Low-drawdown defensive profile for hands-off safe trading' : '安心して放置できる低ドローダウン防衛水準',
      isProOnly: true,
    },
    {
      value: '3%',
      label: isEn ? 'Max DD <= 3% (Ultra Low Risk)' : '最大DD 3%以下 (極限の低リスク)',
      desc: isEn ? 'Capital defense top priority for large institutional accounts' : '資金防衛最優先・大口運用向け鉄壁設計',
      isProOnly: true,
    },
    {
      value: 'AUTO',
      label: isEn ? '🌟 Auto (Dynamic Risk Control)' : '🌟 お任せ (自動リスク調整)',
      desc: isEn ? 'Minimizes drawdown while securing adequate trade volume' : '取引数を確保しながらDDを最小化',
      isProOnly: true,
    },
  ];

  // 5. 希望取引回数・運用スタイル：全投資家タイプ向けにバランスよく設計（無料版でも全選択可能）
  const freqOptions: {
    value: TradeFrequency;
    label: string;
    desc: string;
    badge?: string;
    category: 'SWING' | 'DAY' | 'SCALP' | 'SMART';
    investorProfile: string;
  }[] = [
    {
      value: 'MONTHLY_2_4',
      label: isEn ? '2-4 times / month (Selective Swing)' : '月2〜4回 (超厳選スイング型)',
      desc: isEn ? 'Ultra-low frequency for busy professionals; minimizes spread drag & avoids choppy ranges' : '多忙な兼業投資家・大口向け。無駄な往復コストとレンジのダマシを極限まで排除',
      badge: isEn ? 'Conservative' : '大口・慎重派',
      category: 'SWING',
      investorProfile: isEn ? 'Long-Term / Capital Defense' : '資産防衛・大口運用',
    },
    {
      value: 'WEEKLY_1_2',
      label: isEn ? '1-2 times / week (Standard Swing)' : '週1〜2回 (ゆったりスイング型)',
      desc: isEn ? 'Pure trend-following capturing multi-day macro breakouts with high patience' : '明確なトレンド初動のみを狙う王道スイング。週末持ち越しを抑え手堅く利益確保',
      badge: isEn ? 'Swing' : 'スイング派',
      category: 'SWING',
      investorProfile: isEn ? 'Macro Breakout Follower' : '手堅いスイング・週末手仕舞い',
    },
    {
      value: 'WEEKLY_2_3',
      label: isEn ? '2-3 times / week (Balanced Swing & Day)' : '週2〜3回 (兼業サラリーマン・厳選バランス型)',
      desc: isEn ? 'Optimal balance for working traders: filters out choppy market days while securing 2-3 clean trend opportunities weekly' : '多忙な兼業投資家・サラリーマンの最も現実的でストレスのない黄金ペース。週1回だと少なく、毎日は見られない投資家にベストバランス',
      badge: isEn ? 'Working Trader' : '兼業・手堅い派',
      category: 'SWING',
      investorProfile: isEn ? 'Busy Office Worker' : '多忙な兼業投資家・本命バランス',
    },
    {
      value: 'WEEKLY_3_5',
      label: isEn ? '3-5 times / week (Day & Swing Hybrid)' : '週3〜5回 (王道デイトレ・スイング複合)',
      desc: isEn ? 'Best balanced entry profile across market sessions; steady opportunities' : '平日ほぼ毎日チャンスあり。過度な売買を避ける最も人気の黄金比率バランス',
      badge: isEn ? 'Most Popular' : '人気No.1',
      category: 'DAY',
      investorProfile: isEn ? 'Balanced Day Trader' : '王道運用・最も選ばれている比率',
    },
    {
      value: 'DAILY_1_2',
      label: isEn ? '1-2 times / day (Active Day Trader)' : '1日1〜2回 (アクティブ・デイトレ型)',
      desc: isEn ? 'Engages European and NY volatility windows with daily trade satisfaction' : '欧州・NY市場のボラティリティタイムに毎日手堅く約定。日次収支重視派',
      badge: isEn ? 'Day Trader' : 'デイトレ派',
      category: 'DAY',
      investorProfile: isEn ? 'Active Day Session' : '欧州・NY活発時間帯の順張り',
    },
    {
      value: 'DAILY_3_5',
      label: isEn ? '3-5+ times / day (High-Freq Scalping)' : '1日3〜5回以上 (高頻度スキャルピング型)',
      desc: isEn ? 'Fast intraday compound turnover eliminating overnight swap/gap risks' : '短時間決済で回転させ、ポジションの翌日持ち越しリスクを排除する短期派',
      badge: isEn ? 'Scalper' : 'スキャル派',
      category: 'SCALP',
      investorProfile: isEn ? 'High Turnover / No Overnight' : '即日決済・資金回転重視',
    },
    {
      value: 'AI_RECOMMENDED',
      label: isEn ? '🌟 Auto AI Allocation (Timeframe Adaptive)' : '🌟 AI自動最適配分 (時間足・相場適応)',
      desc: isEn ? 'Dynamically sets optimal trade pace matching selected pair & timeframe volatility' : '通貨ペア・時間足（5分足〜日足）の波形特性に最適な頻度をAIが全自動算出',
      badge: isEn ? 'Smart AI' : 'AI推奨',
      category: 'SMART',
      investorProfile: isEn ? 'Algorithmic Adaptive' : '時間軸・ボラティリティ連動',
    },
    {
      value: 'NO_SPEC',
      label: isEn ? 'Profit / PF Priority (Signal-First)' : '利益期待値・PF最優先 (制限なし)',
      desc: isEn ? 'Only executes when statistical edge is maximal, unbound by arbitrary target counts' : '取引数に縛られず、純粋に統計的優位性（エッジ）が高い相場のみで売買',
      badge: isEn ? 'Edge-Driven' : 'エッジ優先',
      category: 'SMART',
      investorProfile: isEn ? 'Statistical Edge Priority' : '期待値最大化・機会厳選',
    },
  ];

  // 6. バックテスト期間：無料版は3か月固定。他は上位版限定
  const periodOptions = [
    { value: '3MONTHS', label: isEn ? '3 Months' : '3か月', badge: t.config.freeRefBadge, isProOnly: false },
    { value: '1YEAR', label: isEn ? '1 Year' : '1年', badge: t.config.proOnlyBadge, isProOnly: true },
    { value: '3YEARS', label: isEn ? '3 Years' : '3年', badge: t.config.proOnlyBadge, isProOnly: true },
    { value: '5YEARS', label: isEn ? '5 Years' : '5年', badge: t.config.proOnlyBadge, isProOnly: true },
  ];

  // 9. 最大同時保有ポジション数：無料版は「1ポジション」のみ。上位版はポジション数を設定可能 (最大5, 最大10, 最大20, 20ポジション超, その他)
  const positionOptions: {
    value: MaxPositions;
    label: string;
    subLabel: string;
    isProOnly: boolean;
  }[] = [
    {
      value: '1',
      label: isEn ? '1 Position' : '1ポジション',
      subLabel: isEn ? 'Free Edition (Single Position)' : '単一ポジション・リスク最小限 (無料版)',
      isProOnly: false,
    },
    {
      value: 'LE_5',
      label: isEn ? 'Max 5' : '最大5ポジション',
      subLabel: isEn ? 'Small-Scale Scaling (Pro)' : '小規模分散エントリー (上位版)',
      isProOnly: true,
    },
    {
      value: 'LE_10',
      label: isEn ? 'Max 10' : '最大10ポジション',
      subLabel: isEn ? 'Zone Building (Pro)' : 'ゾーン構築・スイング分散 (上位版)',
      isProOnly: true,
    },
    {
      value: 'LE_20',
      label: isEn ? 'Max 20' : '最大20ポジション',
      subLabel: isEn ? 'Multi-Tier Scaling (Pro)' : '多層分散エントリー (上位版)',
      isProOnly: true,
    },
    {
      value: 'GE_20',
      label: isEn ? 'Over 20' : '20ポジション超',
      subLabel: isEn ? 'High-Density Scaling (Pro)' : '20ポジション超の多頻度 (上位版)',
      isProOnly: true,
    },
    {
      value: 'AUTO',
      label: isEn ? '🌟 Other' : '🌟 その他',
      subLabel: isEn ? 'Market Adaptive / Auto (Pro)' : '市場適応型・自動調整 (上位版)',
      isProOnly: true,
    },
  ];

  // 10. EAコアロジック・戦略プリセット
  const strategyOptions: {
    value: StrategyPreset;
    title: string;
    subTitle: string;
    desc: string;
    tag: string;
    badgeColor: string;
    isProOnly: boolean;
  }[] = [
    {
      value: 'AUTO',
      title: isEn ? '🌟 AI Auto Selection (Market Adaptive)' : '🌟 AI自律選定 (相場環境適応型)',
      subTitle: isEn ? 'AI Optimal Algorithm' : '推奨・最高期待値ロジック自動選定',
      desc: isEn
        ? 'Scans pair volatility and trend dynamics to automatically build the highest mathematical expectancy algorithm.'
        : '選択した通貨ペア・時間足の特徴をAIが解析し、最も期待値の高いロジックを自動で構築・最適化します。',
      tag: 'AI OPTIMAL',
      badgeColor: 'border-cyan-500/60 bg-cyan-950/80 text-cyan-300',
      isProOnly: false,
    },
    {
      value: 'GOGOJUNGLE_TREND',
      title: isEn ? 'Multi-EMA Swing & Pullback Breakout' : '王道マルチEMAスイング ＆ 反転確定ブレイク',
      subTitle: isEn ? 'Classic 10-Year Proven Trend Strategy' : '実績10年の王道トレンド追従 (安定スイング)',
      desc: isEn
        ? 'Aligns with 200 EMA & 50 EMA slope. Dips to 14 EMA with candlestick confirmation break. 1.0 ATR Break-Even defense.'
        : '大局200EMA＋50EMAの傾きと同調。短期EMAへの押し目から確定足ブレイクでエントリー。1.0 ATR建値保護で手堅く伸ばす。',
      tag: 'STABLE TREND',
      badgeColor: 'border-emerald-500/60 bg-emerald-950/80 text-emerald-300',
      isProOnly: false,
    },
    {
      value: 'YOUTUBE_MTF_BREAK',
      title: isEn ? 'Smart Money [SMC] & Donchian Liquidity Break' : 'スマートマネー [SMC] ＆ ドンチャン流動性ブレイク',
      subTitle: isEn ? 'Institutional Quant Large-Trend Harvest' : '大相場を根こそぎ刈り取るクオンツ仕様',
      desc: isEn
        ? 'Detects 20-bar liquidity breakout on bar close. ATR surge expansion filter & Chandelier trailing stop capture explosive runs.'
        : '過去20本高安値の流動性プール突破を実体終値で検知。ATR急拡大フィルターとシャンデリアトレールで大トレンドを追従。',
      tag: 'SMC BREAKOUT',
      badgeColor: 'border-amber-500/60 bg-amber-950/80 text-amber-300',
      isProOnly: true,
    },
    {
      value: 'VOLATILITY_EXPANSION',
      title: isEn ? 'TTM Squeeze & Bollinger Expansion Blast' : 'TTMスクイーズ ＆ ボリンジャー爆発初動',
      subTitle: isEn ? 'Energy Compression to Explosive Acceleration' : 'エネルギー充填からの高加速エントリー',
      desc: isEn
        ? 'Detects explosive eruption when Bollinger Bands fire out of Keltner Channel. Momentum confirmation with 1:2.0+ Risk-Reward.'
        : 'ボリンジャーバンドがケルトナーチャネル内に収縮した後の噴火（エクスパンション）初動を捉える。高リスクリワード（1:2超）。',
      tag: 'TTM SQUEEZE',
      badgeColor: 'border-purple-500/60 bg-purple-950/80 text-purple-300',
      isProOnly: true,
    },
    {
      value: 'SESSION_MEAN_REVERSION',
      title: isEn ? 'Session Anomaly & 2.5σ Mean Reversion' : 'セッションアノマリー ＆ 2.5σ平均回帰',
      subTitle: isEn ? 'Tokyo & Early European Box Scalping' : '東京・早朝ボックス圏スキャルピング',
      desc: isEn
        ? 'Trades extreme 2.5σ band overshoot + RSI reversal pin-bar during range sessions. 75%+ win rate with ultra-low drawdown.'
        : '東京・欧州早朝のボックス圏で2.5σ極限バンドタッチ＋RSI過熱＋ピンバー反転を検知。勝率75%超、最大DD極小。',
      tag: 'MEAN REVERSION',
      badgeColor: 'border-teal-500/60 bg-teal-950/80 text-teal-300',
      isProOnly: true,
    },
    {
      value: 'LONDON_BREAKOUT',
      title: isEn ? 'London Open & Tokyo Range Breakout' : 'ロンドン初動 ＆ 東京レンジ確定ブレイク',
      subTitle: isEn ? 'European Institutional Volume Anomaly' : '欧州勢参入時の出来高急増アノマリー',
      desc: isEn
        ? 'Identifies Asian session (Tokyo) High/Low range. Enters on London opening breakout with ATR volatility filter and 1:2.0+ Risk-Reward.'
        : '東京時間の高安値ボックスレンジを確定し、ロンドン開場直後の欧州大口参入ブレイクを確定足で捕捉。損益比1:2.0超の鉄壁アノマリー。',
      tag: 'LONDON BREAK',
      badgeColor: 'border-rose-500/60 bg-rose-950/80 text-rose-300',
      isProOnly: true,
    },
  ];

  return (
    <div
      id="buyer-config-card"
      className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-2xl space-y-5 sm:space-y-6 w-full"
    >
      {/* Card Header & Notice */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-start sm:items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base font-bold text-white">
                {t.config.title}
              </h2>
              <span className="text-[11px] font-semibold text-cyan-300 bg-cyan-950/80 border border-cyan-700/60 px-2.5 py-0.5 rounded-full">
                {t.config.freeBadge}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {t.config.description}
            </p>
          </div>
        </div>

        {/* Upgrade Banner Button */}
        <button
          id="config-header-upgrade-cta"
          onClick={() => onOpenUpgradeModal('GENERAL')}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-blue-950/70 border border-blue-600/50 hover:border-cyan-400 text-cyan-300 hover:text-white text-xs font-semibold transition cursor-pointer self-start sm:self-auto shrink-0 shadow-sm"
        >
          <Lock className="w-3.5 h-3.5 text-cyan-400" />
          <span>{t.common.proFeaturesBtn}</span>
          <ArrowRight className="w-3.5 h-3.5 ml-0.5 text-cyan-400" />
        </button>
      </div>

      {/* 2-Step Flow Guide: ユーザーがどこで何を押せばよいか一目でわかる案内 */}
      <div className="p-3.5 sm:p-4 rounded-xl sm:rounded-2xl bg-gradient-to-r from-cyan-950/90 via-slate-900 to-blue-950/90 border border-cyan-500/50 shadow-[0_0_20px_rgba(6,182,212,0.15)] flex flex-col sm:flex-row sm:items-center justify-between gap-3 w-full">
        <div className="flex items-start sm:items-center gap-2.5 sm:gap-3 min-w-0">
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300 font-black text-sm sm:text-base shrink-0 shadow-[0_0_12px_rgba(6,182,212,0.4)]">
            STEP
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5 sm:gap-2 flex-wrap">
              <span>【STEP 1】下のパラメータを選択 → 【STEP 2】最下部のボタンでEA生成</span>
              <span className="px-1.5 sm:px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 text-[9px] sm:text-[10px] font-mono border border-cyan-600 font-bold shrink-0">
                簡単2ステップ
              </span>
            </div>
            <p className="text-[11px] text-slate-300 mt-0.5 leading-snug">
              {isEn
                ? 'Select your desired currency pair and parameters below, then click the generate button at the bottom.'
                : 'ご希望の通貨ペアや目標PF・ロットを選ぶだけで、AIがリアルタイムに検証シミュレーションとEAコードを出力します。'}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            const btn = document.getElementById('btn-start-ea-generation');
            btn?.scrollIntoView({ behavior: 'smooth', block: 'center' });
            btn?.classList.add('ring-4', 'ring-cyan-300');
            setTimeout(() => btn?.classList.remove('ring-4', 'ring-cyan-300'), 2000);
          }}
          className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-md shadow-cyan-950 transition cursor-pointer shrink-0 self-stretch sm:self-auto"
        >
          <span>生成ボタンへスクロール</span>
          <ArrowDown className="w-3.5 h-3.5 text-slate-950 animate-bounce shrink-0" />
        </button>
      </div>

      {/* 🛡️ 自作EAと圧倒的な差をつける「カーブフィッティング対策＆プロ防衛機構」アピールバナー */}
      <div className="p-3.5 sm:p-4 rounded-xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-cyan-950/40 border border-amber-500/40 shadow-lg space-y-2.5">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-300 flex items-center justify-center text-xs font-bold">
              🛡️
            </span>
            <span className="text-xs sm:text-sm font-black text-white">
              【カーブフィッティング対策済】なぜ自作EAの9割はリアル口座で散るのか？
            </span>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 font-mono font-bold border border-amber-600/60">
            ANTI-OVERFITTING ENGINE
          </span>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          誰でも簡単なEAが自作できる時代だからこそ、差がつくのは<strong className="text-amber-300">「過剰最適化（過去の相場ノイズへの辻褄合わせ）の排除」</strong>です。過去データで無理やり右肩上がりに見せかけた自作EAは、未知の相場に入った瞬間に破綻します。
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 text-[11px]">
          <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 space-y-1">
            <div className="font-bold text-cyan-300 flex items-center gap-1.5">
              <span>① ウォークフォワード未知相場検証</span>
            </div>
            <p className="text-slate-400 text-[10px] leading-snug">
              学習データと未知データを完全分離。未来の未知相場でも再現する本質的エッジのみを抽出。
            </p>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 space-y-1">
            <div className="font-bold text-emerald-300 flex items-center gap-1.5">
              <span>② 動的ATRスプレッド急変ガード</span>
            </div>
            <p className="text-slate-400 text-[10px] leading-snug">
              指標発表や突発的なスプレッド拡大時でも、相場ボラティリティに即応して資金を守る適応制御。
            </p>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 space-y-1">
            <div className="font-bold text-amber-300 flex items-center gap-1.5">
              <span>③ ブローカー不問の約定ガード</span>
            </div>
            <p className="text-slate-400 text-[10px] leading-snug">
              自作EA初心者が必ず直面する「OrderSendエラー」やロット丸め問題をMQLコード側で全自動事前ガード。
            </p>
          </div>
        </div>
      </div>

      {/* 🚀 最先端クオンツ・コアロジック選択セクション */}
      <div id="section-strategy-preset" className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-cyan-800/60 shadow-xl space-y-3.5">
        <div className="flex items-center justify-between gap-2 flex-wrap pb-2.5 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-500/20 to-teal-500/20 text-cyan-300 border border-cyan-500/40 flex items-center justify-center text-sm font-bold shadow-inner">
              ⚡
            </span>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-sm sm:text-base font-black text-white">
                  【EAコア戦略・アルゴリズム選択】稼げるロジックの追求
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 font-mono font-bold border border-cyan-600">
                  4大戦略＋AI自律選定
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                目的や相場観に合わせて、完全に異なるインジケーター・売買判定ロジック・損益比を切り替えてEAコードを生成できます。
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {strategyOptions.map((st) => {
            const selected = (config.strategyPreset || 'AUTO') === st.value;
            const isPro = st.isProOnly && !isProUser;

            return (
              <button
                key={st.value}
                type="button"
                id={`strategy-option-${st.value}`}
                onClick={() => {
                  if (isPro) {
                    onOpenUpgradeModal('STRATEGY' as any);
                  } else {
                    updateField('strategyPreset', st.value);
                  }
                }}
                className={`p-3 rounded-xl text-left text-xs transition border cursor-pointer flex flex-col justify-between gap-2 ${
                  selected
                    ? 'bg-gradient-to-b from-cyan-950/90 to-slate-950 border-cyan-400 text-white font-semibold shadow-lg shadow-cyan-950/60 ring-1 ring-cyan-400'
                    : isPro
                    ? 'bg-slate-950/40 border-slate-800/80 text-slate-400 hover:border-slate-700'
                    : 'bg-slate-950/70 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-900/60'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center justify-between gap-1.5">
                    <span className={`text-[10px] px-2 py-0.5 rounded-md font-mono font-bold border ${st.badgeColor}`}>
                      {st.tag}
                    </span>
                    {isPro ? (
                      <span className="text-[10px] text-amber-400 flex items-center gap-1 font-bold bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800/60">
                        <Lock className="w-2.5 h-2.5" />
                        PRO
                      </span>
                    ) : selected ? (
                      <span className="text-[10px] text-cyan-300 font-bold flex items-center gap-1">
                        <Check className="w-3.5 h-3.5 text-cyan-400" />
                        選択中
                      </span>
                    ) : null}
                  </div>
                  <div className="font-bold text-white text-xs leading-snug">
                    {st.title}
                  </div>
                  <div className="text-[11px] text-cyan-300/90 font-medium">
                    {st.subTitle}
                  </div>
                </div>
                <p className="text-[10px] text-slate-400 leading-snug">
                  {st.desc}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid of Inputs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* 1. 通貨ペア */}
        <div id="section-currency-pair" className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <span>{t.config.pairTitle}</span>
              <span className="text-[10px] font-normal text-cyan-400 bg-cyan-950/60 px-1.5 py-0.2 rounded border border-cyan-800/60">
                {isEn ? '1 Pair' : '1ペア選択'}
              </span>
            </label>
            <span className="text-[11px] text-slate-400 font-medium">
              {isEn ? 'Current: ' : '現在: '}
              <strong className="text-cyan-300">{config.pair}</strong>
            </span>
          </div>

          <div className="grid grid-cols-1 gap-1.5">
            {pairOptions.map((opt) => {
              const selected = config.pair === opt.value;
              const isPro = opt.isProOnly && !isProUser;

              return (
                <button
                  key={opt.value}
                  type="button"
                  id={`pair-option-${opt.value}`}
                  onClick={() => {
                    if (isPro) {
                      onOpenUpgradeModal('PAIR');
                    } else {
                      updateField('pair', opt.value);
                    }
                  }}
                  className={`p-2.5 rounded-xl text-left text-xs transition border cursor-pointer flex items-center justify-between ${
                    selected
                      ? 'bg-cyan-950/70 border-cyan-500 text-white font-semibold shadow-md shadow-cyan-950/50'
                      : isPro
                      ? 'bg-slate-850/50 border-slate-800 text-slate-400 hover:bg-slate-800/80 hover:border-slate-700'
                      : 'bg-slate-800/60 border-slate-700 text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex-1 min-w-0 pr-2">
                    <div className="flex items-center gap-2">
                      <span className={selected ? 'text-cyan-300 font-bold' : ''}>
                        {opt.label}
                      </span>
                      {isPro && (
                        <span className="inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.2 rounded bg-slate-800 border border-slate-700 text-amber-300">
                          <Lock className="w-2.5 h-2.5" /> {t.config.proOnlyBadge}
                        </span>
                      )}
                      {opt.isProOnly && isProUser && (
                        <span className="px-1.5 py-0.2 rounded text-[9px] bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                          PRO開放
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate mt-0.5">
                      {opt.desc}
                    </div>
                  </div>

                  {selected ? (
                    <div className="w-5 h-5 rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300 shrink-0">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  ) : isPro ? (
                    <Lock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  ) : null}
                </button>
              );
            })}
          </div>

          {/* XAU/USD (ゴールド) 選択時のスプレッド＆高PIPS設計 ガイダンス */}
          {config.pair === 'XAUUSD' && (
            <div className="p-3.5 rounded-xl bg-gradient-to-r from-amber-950/70 via-slate-900 to-amber-950/50 border border-amber-500/60 shadow-lg space-y-2">
              <div className="flex items-center gap-2">
                <Coins className="w-4 h-4 text-amber-400 shrink-0" />
                <h4 className="text-xs font-black text-amber-200">
                  {isEn ? '🪙 XAU/USD (Gold) Adaptive High-PIPS Parameter Calibration Active' : '🪙 XAU/USD (ゴールド) 専用：高PIPS＆スプレッド自動最適化仕様'}
                </h4>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                {isEn
                  ? 'Gold volatility and spreads differ substantially from FX pairs (EURUSD). Parameters are calibrated in PIPS to prevent zero-trade backtest failures: XM Standard (~3.5-4.5 pips), TitanFX (~2.8-3.5 pips), Exness (~2.5-3.8 pips). Default InpMaxSpread is set to 10.0 pips ($1.00) with Break-Even Lock at 20.0 pips ($2.00) and Trailing Step at 25.0 pips ($2.50).'
                  : 'ゴールドは一般為替（EURUSD等）と明確にスプレッドやPIPS値、ボラティリティが異なります。スプレッド設定が低すぎるとテスターで取引ゼロになり重大な信用問題となるため、代表的ブローカー（XMスタンダード等 3.5〜4.5pips）に合わせ【InpMaxSpread = 10.0 pips】、建値ロック20.0pips（$2.00）、トレール幅25.0pips（$2.50）、SL 75〜120pipsへ適切に自動最適化されます。'}
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                <div className="p-2 rounded bg-slate-950/80 border border-amber-500/30 text-[10px]">
                  <div className="text-amber-400 font-bold">1. 代表口座別スプレッド対応</div>
                  <div className="text-slate-300">XMスタンダード(3.5〜4.5pips)、TitanFX(2.8〜3.5pips)、Exness(2.5〜3.8pips)を網羅し、取引ゼロを完全防止</div>
                </div>
                <div className="p-2 rounded bg-slate-950/80 border border-amber-500/30 text-[10px]">
                  <div className="text-amber-400 font-bold">2. 高PIPS設定による保護</div>
                  <div className="text-slate-300">為替の2〜3pipsではなく、建値20pips($2.00)・トレール25pips($2.50)で日常ノイズでの損切りを防止</div>
                </div>
                <div className="p-2 rounded bg-slate-950/80 border border-amber-500/30 text-[10px]">
                  <div className="text-amber-400 font-bold">3. ブローカー桁数自動判定</div>
                  <div className="text-slate-300">2桁(XM)・3桁(Exness)ブローカーの仕様差をMQL内部のGetPipPoint()関数で完全自動吸収</div>
                </div>
              </div>
            </div>
          )}

          <p className="text-[11px] text-slate-400 leading-tight">
            {t.config.pairLimitNotice}
          </p>
        </div>

        {/* 2. 時間足 (制限なし) */}
        <div id="section-timeframe" className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <span>{t.config.timeframeTitle}</span>
              <span className="text-[10px] font-normal text-emerald-400 bg-emerald-950/60 px-1.5 py-0.2 rounded border border-emerald-800/60">
                {isEn ? 'All Available' : '全足選択可能'}
              </span>
            </label>
            <span className="text-[11px] text-slate-400 font-medium">
              {isEn ? 'Current: ' : '現在: '}
              <strong className="text-emerald-300">{config.timeframe}</strong>
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
            {timeframeOptions.map((opt) => {
              const selected = config.timeframe === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  id={`timeframe-option-${opt.value}`}
                  onClick={() => updateField('timeframe', opt.value)}
                  className={`px-2.5 py-2 rounded-xl text-center text-xs transition border cursor-pointer ${
                    selected
                      ? 'bg-emerald-950/70 border-emerald-500 text-emerald-200 font-bold shadow-md'
                      : 'bg-slate-800/60 border-slate-700/70 text-slate-300 hover:bg-slate-800 hover:border-slate-600'
                  } ${opt.value === 'AUTO' ? 'col-span-2 sm:col-span-3' : ''}`}
                >
                  <div className="flex items-center justify-center gap-1">
                    <span>{opt.label}</span>
                    {opt.badge && opt.value !== 'AUTO' && (
                      <span className="text-[9px] px-1 py-0.2 bg-emerald-500/20 text-emerald-300 rounded font-normal">
                        {opt.badge}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          <p className="text-[11px] text-slate-400 leading-tight">
            {t.config.timeframeNotice}
          </p>
        </div>

        {/* 3. プロフィットファクター (PF) */}
        <div id="section-pf" className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <span>{t.config.pfTitle}</span>
            </label>
            <span className="text-[11px] text-slate-400 font-medium">
              {isEn ? 'Free: ' : '無料版: '}
              <strong className="text-cyan-300">PF 1.2+</strong>
            </span>
          </div>

          <div className="space-y-1.5">
            {pfOptions.map((opt) => {
              const selected = config.desiredPf === opt.value;
              const isPro = opt.isProOnly && !isProUser;

              return (
                <button
                  key={opt.value}
                  type="button"
                  id={`pf-option-${opt.value}`}
                  onClick={() => {
                    if (isPro) {
                      onOpenUpgradeModal('PF');
                    } else {
                      updateField('desiredPf', opt.value);
                    }
                  }}
                  className={`w-full p-2.5 rounded-xl text-left text-xs transition border cursor-pointer flex items-center justify-between ${
                    selected
                      ? 'bg-cyan-950/70 border-cyan-500 text-cyan-200 font-bold shadow-md'
                      : isPro
                      ? 'bg-slate-850/40 border-slate-800 text-slate-400 hover:bg-slate-800/80 hover:border-slate-700'
                      : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex-1 min-w-0 pr-2">
                    <div className="flex items-center gap-2">
                      <span className={selected ? 'text-cyan-300 font-bold' : ''}>
                        {opt.label}
                      </span>
                      {isPro && (
                        <span className="inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.2 rounded bg-slate-850 border border-slate-700 text-amber-300 font-normal">
                          <Lock className="w-2.5 h-2.5" /> {t.config.proOnlyBadge}
                        </span>
                      )}
                      {opt.isProOnly && isProUser && (
                        <span className="px-1.5 py-0.2 rounded text-[9px] bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                          PRO開放
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate mt-0.5">
                      {opt.desc}
                    </div>
                  </div>

                  {selected ? (
                    <div className="w-5 h-5 rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300 shrink-0">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  ) : isPro ? (
                    <Lock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  ) : null}
                </button>
              );
            })}
          </div>

          <p className="text-[11px] text-slate-400 leading-tight">
            {t.config.pfLimitNotice}
          </p>
        </div>

        {/* 4. 最大ドローダウン */}
        <div id="section-max-dd" className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <span>{t.config.ddTitle}</span>
            </label>
            <span className="text-[11px] text-slate-400 font-medium">
              {isEn ? 'Free: ' : '無料版: '}
              <strong className="text-cyan-300">{isEn ? '<= 10%' : '10%以下'}</strong>
            </span>
          </div>

          <div className="space-y-1.5">
            {ddOptions.map((opt) => {
              const selected = config.maxDrawdown === opt.value;
              const isPro = opt.isProOnly && !isProUser;

              return (
                <button
                  key={opt.value}
                  type="button"
                  id={`dd-option-${opt.value}`}
                  onClick={() => {
                    if (isPro) {
                      onOpenUpgradeModal('DD');
                    } else {
                      updateField('maxDrawdown', opt.value);
                    }
                  }}
                  className={`w-full p-2.5 rounded-xl text-left text-xs transition border cursor-pointer flex items-center justify-between ${
                    selected
                      ? 'bg-cyan-950/70 border-cyan-500 text-cyan-200 font-bold shadow-md'
                      : isPro
                      ? 'bg-slate-850/40 border-slate-800 text-slate-400 hover:bg-slate-800/80 hover:border-slate-700'
                      : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex-1 min-w-0 pr-2">
                    <div className="flex items-center gap-2">
                      <span className={selected ? 'text-cyan-300 font-bold' : ''}>
                        {opt.label}
                      </span>
                      {isPro && (
                        <span className="inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.2 rounded bg-slate-850 border border-slate-700 text-amber-300 font-normal">
                          <Lock className="w-2.5 h-2.5" /> {t.config.proOnlyBadge}
                        </span>
                      )}
                      {opt.isProOnly && isProUser && (
                        <span className="px-1.5 py-0.2 rounded text-[9px] bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                          PRO開放
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate mt-0.5">
                      {opt.desc}
                    </div>
                  </div>

                  {selected ? (
                    <div className="w-5 h-5 rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300 shrink-0">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  ) : isPro ? (
                    <Lock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  ) : null}
                </button>
              );
            })}
          </div>

          <p className="text-[11px] text-slate-400 leading-tight">
            {t.config.ddLimitNotice}
          </p>
        </div>

        {/* 5. 希望取引回数 (制限なし) - 多様な投資家タイプ向けバランス設計 */}
        <div id="section-frequency" className="space-y-2.5 md:col-span-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <span>{t.config.freqTitle}</span>
              <span className="text-[10px] font-normal text-emerald-400 bg-emerald-950/60 px-1.5 py-0.2 rounded border border-emerald-800/60">
                {isEn ? 'Balanced for All Investor Styles' : '多様な投資家タイプ向けバランス設計'}
              </span>
            </label>
            <span className="text-[11px] text-slate-400 font-medium">
              {isEn ? 'Current: ' : '現在: '}
              <strong className="text-emerald-300">
                {freqOptions.find((f) => f.value === config.frequency)?.label || (isEn ? 'Selected' : '選択中')}
              </strong>
            </span>
          </div>

          {/* 投資家スタイル別 クイック絞り込みフィルター */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
            <span className="text-slate-400 shrink-0 text-[10px] font-semibold">
              {isEn ? 'Filter by Style:' : 'スタイル絞込:'}
            </span>
            {[
              { id: 'ALL', label: isEn ? 'All Styles (8)' : 'すべて (全8種)' },
              { id: 'SWING', label: isEn ? '🛡️ Swing & Part-Time (3)' : '🛡️ 慎重・兼業スイング (3)' },
              { id: 'DAY', label: isEn ? '🎯 Day Trader (2)' : '🎯 王道デイトレ (2)' },
              { id: 'SCALP', label: isEn ? '⚡ Scalping (1)' : '⚡ 高頻度スキャル (1)' },
              { id: 'SMART', label: isEn ? '🌟 AI & Edge-First (2)' : '🌟 AI・エッジ優先 (2)' },
            ].map((tab) => {
              const isActive = freqCategoryFilter === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setFreqCategoryFilter(tab.id as any)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer border ${
                    isActive
                      ? 'bg-emerald-600 text-white border-emerald-500 shadow-sm'
                      : 'bg-slate-800/80 text-slate-300 border-slate-700/80 hover:bg-slate-700/80 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {freqOptions
              .filter((opt) => freqCategoryFilter === 'ALL' || opt.category === freqCategoryFilter)
              .map((opt) => {
                const selected = config.frequency === opt.value;
                return (
                  <button
                    key={opt.value}
                    type="button"
                    id={`freq-option-${opt.value}`}
                    onClick={() => updateField('frequency', opt.value)}
                    className={`p-2.5 rounded-xl text-left text-xs transition border cursor-pointer flex items-start justify-between ${
                      selected
                        ? 'bg-emerald-950/70 border-emerald-500 text-emerald-200 font-bold shadow-md shadow-emerald-950/60 ring-1 ring-emerald-500/40'
                        : 'bg-slate-800/60 border-slate-700/70 text-slate-300 hover:bg-slate-800 hover:border-slate-600'
                    }`}
                  >
                    <div className="min-w-0 flex-1 pr-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-semibold text-slate-100">{opt.label}</span>
                        {opt.badge && (
                          <span
                            className={`text-[9px] px-1.5 py-0.2 rounded font-bold shrink-0 ${
                              opt.value === 'WEEKLY_3_5'
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                : opt.value === 'WEEKLY_2_3'
                                ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40'
                                : opt.value === 'AI_RECOMMENDED'
                                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                                : selected
                                ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-500/40'
                                : 'bg-slate-700/70 text-slate-300 border border-slate-600/50'
                            }`}
                          >
                            {opt.badge}
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-emerald-400/90 font-medium mt-0.5">
                        👤 {opt.investorProfile}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-1 leading-snug">
                        {opt.desc}
                      </div>
                    </div>
                    {selected && (
                      <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5 ml-1" />
                    )}
                  </button>
                );
              })}
          </div>

          <p className="text-[11px] text-slate-400 leading-tight">
            {isEn
              ? 'All frequency settings are available for free testing. Each mode ensures appropriate risk-reward and avoids overtrading.'
              : '※多忙な兼業投資家（週2〜3回）から大口慎重派（月2〜4回）、アクティブ派（週3〜5回/日次）、AI自動配分まで全8種からバランスよく選択可能です。'}
          </p>
        </div>

        {/* 6. バックテスト期間 (無料版は3か月固定) */}
        <div id="section-period" className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.config.periodTitle}</span>
            </label>
            <span className="text-[11px] text-cyan-300 font-semibold">
              {isProUser ? 'PRO開放中 (長期検証)' : (isEn ? '[ 3 Months ] Free Edition' : '[ 3か月 ] 無料版')}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-1.5">
            {periodOptions.map((opt) => {
              const currentPeriod = config.testPeriod || '3MONTHS';
              const selected = currentPeriod === opt.value;
              const isPro = opt.isProOnly && !isProUser;

              return (
                <button
                  key={opt.value}
                  type="button"
                  id={`period-option-${opt.value}`}
                  onClick={() => {
                    if (isPro) {
                      onOpenUpgradeModal('PERIOD');
                    } else {
                      updateField('testPeriod', opt.value as any);
                    }
                  }}
                  className={`p-2.5 rounded-xl text-center text-xs transition border cursor-pointer ${
                    selected
                      ? 'bg-cyan-950/70 border-cyan-500 text-cyan-200 font-bold shadow-md'
                      : 'bg-slate-850/40 border-slate-800 text-slate-400 hover:bg-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-center gap-1.5">
                    <span>{opt.label}</span>
                    {isPro ? (
                      <span className="inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-amber-300 font-normal">
                        <Lock className="w-2.5 h-2.5" /> {t.config.proOnlyBadge}
                      </span>
                    ) : isProUser && opt.isProOnly ? (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-bold border border-amber-500/40">
                        PRO開放
                      </span>
                    ) : (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 font-normal">
                        {t.config.freeBadge}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          <p className="text-[11px] text-slate-400 leading-tight">
            {t.config.periodNotice}
          </p>
        </div>

        {/* 7. 運用予定資金 (無料版は10万円固定・PRO版で任意設定可能) */}
        <div id="section-capital" className="space-y-2 md:col-span-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Wallet className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.config.capitalTitle}</span>
              {isProUser ? (
                <span className="text-[10px] font-bold text-amber-300 bg-amber-950/80 border border-amber-500/50 px-2 py-0.2 rounded-full">
                  👑 PRO開放中
                </span>
              ) : (
                <span className="text-[10px] font-semibold text-cyan-300 bg-cyan-950/80 border border-cyan-700/60 px-2 py-0.2 rounded-full">
                  無料版: 10万円固定
                </span>
              )}
            </label>
            {!isProUser && (
              <button
                type="button"
                id="capital-upgrade-hint"
                onClick={() => onOpenUpgradeModal('CAPITAL')}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
              >
                {isEn ? 'Want custom capital? (Pro Edition)' : '資金を自由に設定するには？ (上位版)'}
              </button>
            )}
          </div>

          {isProUser ? (
            <div className="p-3.5 rounded-xl bg-slate-800/80 border border-cyan-500/40 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-300 font-semibold">運用基準資金を選択:</span>
                <span className="text-base font-black text-cyan-300 font-mono">
                  ¥{(config.capitalAmount || 100000).toLocaleString()} JPY
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-1.5">
                {[100000, 300000, 500000, 1000000, 3000000, 5000000, 10000000].map((amt) => {
                  const currentAmt = config.capitalAmount || 100000;
                  const isSel = currentAmt === amt;
                  const label =
                    amt >= 10000000
                      ? '1,000万円'
                      : amt >= 1000000
                      ? `${amt / 1000000}00万円`
                      : `${amt / 10000}万円`;
                  return (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => updateField('capitalAmount', amt)}
                      className={`py-1.5 px-2 rounded-lg text-xs font-mono font-bold transition border cursor-pointer text-center ${
                        isSel
                          ? 'bg-cyan-950 border-cyan-500 text-cyan-200 shadow-sm'
                          : 'bg-slate-900/80 border-slate-700 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>
              <p className="text-[11px] text-slate-400">
                ※PRO版では実際の運用資金規模に応じた正確な証拠金維持率・期待損益額をシミュレーションします。
              </p>
            </div>
          ) : (
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-baseline gap-2">
                  <span className="text-lg font-black text-white tracking-tight">
                    {t.config.capitalValue}
                  </span>
                  <span className="text-xs font-medium text-slate-400">
                    {isEn ? '(Base capital ¥100,000 JPY - Free Trial fixed)' : '(基準資金10万円・無料体験版固定)'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 mt-1">
                  {t.config.capitalDesc}
                </p>
              </div>

              <button
                type="button"
                id="capital-pro-button"
                onClick={() => onOpenUpgradeModal('CAPITAL')}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-750 text-slate-300 text-xs font-medium flex items-center gap-1.5 transition cursor-pointer self-stretch sm:self-auto justify-center"
              >
                <Lock className="w-3 h-3 text-amber-300" />
                <span>{t.config.capitalProHint}</span>
              </button>
            </div>
          )}
        </div>

        {/* 8. ロット数・資金管理 (無料版は0.01Lot固定・PRO版で自由設定可能) */}
        <div id="section-minimum-lot" className="space-y-2 md:col-span-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Scale className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.config.lotTitle}</span>
              {isProUser ? (
                <span className="text-[10px] font-bold text-amber-300 bg-amber-950/80 border border-amber-500/50 px-2 py-0.2 rounded-full">
                  👑 PRO開放中
                </span>
              ) : (
                <span className="text-[10px] font-semibold text-cyan-300 bg-cyan-950/80 border border-cyan-700/60 px-2 py-0.2 rounded-full">
                  無料版: 0.01 Lot固定
                </span>
              )}
            </label>
            {!isProUser && (
              <button
                type="button"
                id="lot-upgrade-hint"
                onClick={() => onOpenUpgradeModal('LOT')}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
              >
                {t.config.lotProHint}
              </button>
            )}
          </div>

          {isProUser ? (
            <div className="p-3.5 rounded-xl bg-slate-800/80 border border-cyan-500/40 space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => updateField('lotType', 'FIXED')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                      (config.lotType || 'FIXED') === 'FIXED'
                        ? 'bg-cyan-600 text-slate-950 shadow'
                        : 'bg-slate-900 text-slate-300 hover:bg-slate-850'
                    }`}
                  >
                    固定ロット方式
                  </button>
                  <button
                    type="button"
                    onClick={() => updateField('lotType', 'COMPOUND')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1 ${
                      config.lotType === 'COMPOUND'
                        ? 'bg-emerald-500 text-slate-950 shadow'
                        : 'bg-slate-900 text-slate-300 hover:bg-slate-850'
                    }`}
                  >
                    <Percent className="w-3 h-3" />
                    <span>複利リスク％方式</span>
                  </button>
                </div>
                <div className="text-xs font-mono font-bold text-cyan-300">
                  {config.lotType === 'COMPOUND'
                    ? `1トレード許容リスク: ${config.riskPercent || 2.0}%`
                    : `固定ロット数: ${config.lotSize || 0.01} Lot`}
                </div>
              </div>

              {/* 固定ロット選択肢 */}
              {(config.lotType || 'FIXED') === 'FIXED' ? (
                <div className="grid grid-cols-3 sm:grid-cols-7 gap-1.5">
                  {[0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 1.0].map((lt) => {
                    const currentLot = config.lotSize || 0.01;
                    const isSel = currentLot === lt;
                    return (
                      <button
                        key={lt}
                        type="button"
                        onClick={() => updateField('lotSize', lt)}
                        className={`py-1.5 px-2 rounded-lg text-xs font-mono font-bold transition border cursor-pointer text-center ${
                          isSel
                            ? 'bg-cyan-950 border-cyan-500 text-cyan-200 shadow-sm'
                            : 'bg-slate-900/80 border-slate-700 text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        {lt.toFixed(2)} Lot
                      </button>
                    );
                  })}
                </div>
              ) : (
                /* 複利リスク％選択肢 */
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { val: 1.0, label: '1.0% (堅実・低リスク)' },
                    { val: 2.0, label: '2.0% (標準バランス)' },
                    { val: 3.0, label: '3.0% (積極運用)' },
                    { val: 5.0, label: '5.0% (ハイリターン)' },
                  ].map((item) => {
                    const currentRisk = config.riskPercent || 2.0;
                    const isSel = currentRisk === item.val;
                    return (
                      <button
                        key={item.val}
                        type="button"
                        onClick={() => updateField('riskPercent', item.val)}
                        className={`p-2 rounded-lg text-xs font-medium transition border cursor-pointer text-left ${
                          isSel
                            ? 'bg-emerald-950 border-emerald-500 text-emerald-200 font-bold shadow-sm'
                            : 'bg-slate-900/80 border-slate-700 text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <div>{item.label}</div>
                      </button>
                    );
                  })}
                </div>
              )}

              <p className="text-[11px] text-slate-400">
                ※PRO版EAソースコード（MQL5/MQL4）内の初期パラメータ InpFixedLot / InpRiskPercent に自動反映されます。
              </p>
            </div>
          ) : (
            <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-baseline gap-2">
                  <span className="text-xs text-slate-400 font-semibold">{t.config.lotLabel}</span>
                  <span className="text-lg font-black text-cyan-300 tracking-tight">
                    {t.config.lotValue}
                  </span>
                  <span className="text-[10px] text-amber-300 bg-amber-950/60 border border-amber-800/60 px-1.5 py-0.5 rounded">
                    {t.config.lotFixedTag}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {t.config.lotDesc}
                </p>
                <p className="text-[11px] text-slate-400">
                  {t.config.lotSubNote}
                </p>
              </div>

              <button
                type="button"
                id="lot-pro-button"
                onClick={() => onOpenUpgradeModal('LOT')}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-750 text-slate-300 text-xs font-medium flex items-center gap-1.5 transition cursor-pointer self-stretch sm:self-auto justify-center shrink-0"
              >
                <Lock className="w-3 h-3 text-amber-300" />
                <span>{t.config.lotProButton}</span>
              </button>
            </div>
          )}
        </div>

        {/* 9. ポジション数 (無料版は1ポジションのみ・上位版で設定可能) */}
        <div id="section-max-positions" className="space-y-2 md:col-span-2">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.config.positionsTitle}</span>
              <span className="text-[10px] font-semibold text-cyan-300 bg-cyan-950/80 border border-cyan-700/60 px-2 py-0.2 rounded-full">
                {isEn ? 'Free: 1 Position' : '無料版: 1ポジション固定'}
              </span>
            </label>
            <button
              type="button"
              id="positions-upgrade-hint"
              onClick={() => onOpenUpgradeModal('MAX_POSITIONS')}
              className="text-[11px] text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
            >
              {isEn ? 'Configure max concurrent positions? (Pro Edition)' : '最大同時保有ポジション数を設定するには？ (上位版)'}
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
            {positionOptions.map((opt) => {
              const currentVal = config.maxPositions || '1';
              const selected = currentVal === opt.value;
              const isPro = opt.isProOnly && !isProUser;

              return (
                <button
                  key={opt.value}
                  type="button"
                  id={`position-option-${opt.value}`}
                  onClick={() => {
                    if (isPro) {
                      onOpenUpgradeModal('MAX_POSITIONS');
                    } else {
                      updateField('maxPositions', opt.value);
                    }
                  }}
                  className={`p-3 rounded-xl text-left text-xs transition border cursor-pointer flex flex-col justify-between h-full relative group ${
                    selected
                      ? 'bg-cyan-950/80 border-cyan-500 text-cyan-200 font-bold shadow-lg shadow-cyan-950/50 ring-1 ring-cyan-500/50'
                      : isPro
                      ? 'bg-slate-850/40 border-slate-800 text-slate-400 hover:bg-slate-800/80 hover:border-slate-700'
                      : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-start justify-between gap-1 w-full mb-1">
                    <span className={`text-sm font-bold ${selected ? 'text-cyan-300' : 'text-slate-200'}`}>
                      {opt.label}
                    </span>
                    {selected ? (
                      <div className="w-4 h-4 rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300 shrink-0">
                        <Check className="w-3 h-3" />
                      </div>
                    ) : isPro ? (
                      <div className="flex items-center gap-0.5 text-[9px] px-1.5 py-0.2 rounded bg-slate-900/90 border border-slate-750 text-amber-300 font-normal">
                        <Lock className="w-2.5 h-2.5" />
                        <span>{t.config.proOnlyBadge}</span>
                      </div>
                    ) : isProUser && opt.isProOnly ? (
                      <span className="text-[9px] font-bold text-amber-300 bg-amber-950/60 border border-amber-800/60 px-1 py-0.2 rounded">
                        PRO開放
                      </span>
                    ) : null}
                  </div>

                  <div className="text-[10px] text-slate-400 leading-tight">
                    {opt.subLabel}
                  </div>

                  {isPro && (
                    <div className="mt-2 pt-1.5 border-t border-slate-800/80 flex items-center gap-1 text-[10px] text-amber-400/90 group-hover:text-amber-300">
                      <Sparkles className="w-2.5 h-2.5" />
                      <span>{isEn ? 'Configure in Pro' : '上位版で設定可能'}</span>
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          <div className="p-3 rounded-xl bg-slate-850/50 border border-slate-800 space-y-1.5">
            <p className="text-[11px] text-slate-400 leading-tight">
              {t.config.positionsLimitNotice}
            </p>
            <div className="flex items-start gap-1.5 text-[11px] text-amber-300/90 pt-1 border-t border-slate-800">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-400" />
              <span>{t.config.futureFeaturesNote}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Primary Action Button - ユーザーが絶対に迷わない強調フレーム */}
      <div id="ea-generation-action-section" className="pt-6 border-t-2 border-cyan-500/40 flex flex-col items-center justify-center gap-4 w-full">
        {/* 指示サイン・バナー */}
        <div className="w-full max-w-2xl text-center space-y-1.5 p-3 sm:p-4 rounded-2xl bg-gradient-to-r from-cyan-950/90 via-slate-900 to-blue-950/90 border border-cyan-400/60 shadow-[0_0_25px_rgba(6,182,212,0.25)]">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-400 text-slate-950 font-black text-xs uppercase tracking-wider animate-pulse">
            <Sparkles className="w-3.5 h-3.5 fill-slate-950 shrink-0" />
            <span>【 STEP 2: 設定完了！ここを押してEA生成を開始 】</span>
          </div>
          <p className="text-xs text-cyan-200 leading-relaxed px-2">
            {isEn
              ? 'Click the large glowing button below to trigger automated backtest simulation & EA build.'
              : '設定した条件をもとに、AIがブラウザ上で自動的にバックテスト検証とMQL4/MQL5コードの生成を実行します。'}
          </p>
        </div>

        {/* 巨大な強調ボタン (スマホ画面でもPCでもカード幅いっぱいに自然にフィット) */}
        <div className="w-full max-w-2xl flex justify-center">
          <button
            id="btn-start-ea-generation"
            type="button"
            onClick={onRunBacktest}
            disabled={isRunning}
            className="w-full px-4 py-4 sm:px-10 sm:py-5 rounded-2xl bg-gradient-to-r from-emerald-400 via-cyan-400 to-teal-300 hover:from-emerald-300 hover:via-cyan-300 hover:to-teal-200 text-slate-950 font-black transition-all duration-200 shadow-[0_0_30px_rgba(6,182,212,0.5)] hover:shadow-[0_0_45px_rgba(6,182,212,0.8)] flex items-center justify-center gap-3 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98] border-2 border-white/90"
          >
            {isRunning ? (
              <>
                <RefreshCw className="w-5 h-5 sm:w-6 sm:h-6 animate-spin text-slate-950 shrink-0" />
                <span className="text-sm sm:text-base font-black tracking-wide">
                  {isEn ? 'Verifying Backtest Logic...' : 'バックテスト検証実行中...'}
                </span>
              </>
            ) : (
              <>
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-slate-950/20 flex items-center justify-center shrink-0">
                  <Play className="w-4 h-4 sm:w-5 sm:h-5 fill-slate-950 text-slate-950 group-hover:scale-110 transition-transform" />
                </div>
                <div className="flex flex-col items-start text-left min-w-0 flex-1">
                  <span className="text-sm xs:text-base sm:text-lg font-black tracking-tight leading-snug">
                    {isProUser ? 'PRO深層EA検証シミュレーションを開始' : '【ここをクリック】EA生成・検証を開始'}
                  </span>
                  <span className="text-[10px] sm:text-[11px] font-bold text-slate-800 tracking-normal leading-tight">
                    {isProUser ? '全ティック長期深層ストレステストを実行' : '無料版・EURUSD 3か月シミュレーション (約5分)'}
                  </span>
                </div>
                <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6 text-slate-950 group-hover:translate-x-1.5 transition-transform shrink-0" />
              </>
            )}
          </button>
        </div>

        {/* 検証時間の違いに関する重要な明記バナー（ユーザー要求：無料版でも明記） */}
        <div className="w-full max-w-2xl p-3.5 sm:p-4 rounded-xl bg-slate-950/90 border border-slate-700/80 text-left space-y-2 shadow-inner">
          <div className="flex items-center gap-2 text-cyan-300 font-bold text-xs">
            <Clock className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>【重要】無料版と上位PRO版の検証時間・品質設計の違いについて</span>
          </div>
          <div className="space-y-1.5 text-[11px] text-slate-300 leading-relaxed">
            <p>
              <strong className="text-cyan-400">● 無料配布版:</strong> 条件確認用の簡易シミュレーション（EUR/USD・3か月・約5分）を実施します。
            </p>
            <p>
              <strong className="text-amber-400">● 上位PRO版:</strong> 1年〜5年の長期全ティック・動的ATR・複数ポジション分散・過剰最適化排除を徹底検証（通常PCで30分以上かかる膨大な多次元計算量）。クラウド並列処理により、同一の厳密な過去時系列データから整合性の取れた確かな商業販売水準のバックテスト結果を出力します。
            </p>
          </div>
          {!isProUser && (
            <div className="pt-1.5 border-t border-slate-800 flex items-center justify-between">
              <span className="text-[10px] text-slate-400">
                ※Stripe決済後にメールで届く認証コードを入力することで上位版の全機能が開放されます。
              </span>
              <button
                type="button"
                onClick={() => onOpenUpgradeModal('SPEED')}
                className="inline-flex items-center gap-1 text-xs font-bold text-amber-400 hover:text-amber-300 underline cursor-pointer shrink-0 ml-2"
              >
                <Zap className="w-3 h-3 fill-amber-400 text-amber-400" />
                <span>上位版の仕様詳細</span>
              </button>
            </div>
          )}
        </div>

        <div className="flex flex-col items-center gap-1.5 text-center max-w-xl px-2">
          <p className="text-xs text-slate-400 flex items-center justify-center gap-1.5">
            <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>
              {isProUser
                ? 'PRO深層検証パイプライン（1〜5年全ティック走査・多通貨・ディープストレステスト）'
                : t.config.btnSubText}
            </span>
          </p>
        </div>
      </div>
    </div>
  );
};

