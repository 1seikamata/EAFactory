/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Key,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  X,
  Sparkles,
  Zap,
  CreditCard,
  LogOut,
  Mail,
  Copy,
  Clock,
  Layers,
} from 'lucide-react';
import { LicenseInfo } from '../types';
import { useLanguage } from '../i18n/LanguageContext';

interface LicenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  licenseInfo: LicenseInfo;
  onActivateSuccess: (license: LicenseInfo) => void;
  onDeactivate: () => void;
  onOpenUpgradeModal: () => void;
}

export const LicenseModal: React.FC<LicenseModalProps> = ({
  isOpen,
  onClose,
  licenseInfo,
  onActivateSuccess,
  onDeactivate,
  onOpenUpgradeModal,
}) => {
  const { language } = useLanguage();
  const isEn = language === 'en';

  const [emailInput, setEmailInput] = useState(licenseInfo.email || '');
  const [codeInput, setCodeInput] = useState(licenseInfo.code || '');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleVerify = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const email = emailInput.trim();
    const code = codeInput.trim().toUpperCase();

    if (!email || !code) {
      setErrorMessage(
        isEn
          ? 'Please enter both your registered email address and authentication code.'
          : '登録されたメールアドレスと認証コードの両方を入力してください。'
      );
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/license/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, code }),
      });
      const data = await res.json();

      if (!res.ok || !data.success) {
        setErrorMessage(
          data.error ||
            (isEn
              ? 'Verification failed. Please verify your email and authentication code.'
              : '認証に失敗しました。メールアドレスと認証コードをご確認ください。')
        );
        setIsLoading(false);
        return;
      }

      const verifiedLicense: LicenseInfo = {
        isPro: true,
        email: data.license.email,
        code: data.license.code,
        type: data.license.type,
        expiresAt: data.license.expiresAt,
        activatedAt: new Date().toISOString(),
      };

      setSuccessMessage(
        isEn
          ? `PRO version unlocked successfully! (${data.license.type === 'lifetime' ? 'Lifetime Perpetual' : 'Subscription'})`
          : `PRO版の認証に成功しました！（${data.license.type === 'lifetime' ? '買い切り永久版' : '月額サブスクリプション'}）`
      );

      setTimeout(() => {
        onActivateSuccess(verifiedLicense);
        onClose();
      }, 1000);
    } catch (err: any) {
      console.error('License verify network error:', err);
      setErrorMessage(
        isEn
          ? 'Network error. Please try again later.'
          : '通信エラーが発生しました。時間をおいて再度お試しください。'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleApplyPreset = (email: string, code: string) => {
    setEmailInput(email);
    setCodeInput(code);
    setErrorMessage(null);
    setSuccessMessage(null);
  };

  return (
    <div
      id="license-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn"
      onClick={onClose}
    >
      <div
        id="license-modal-container"
        className="relative w-full max-w-lg bg-slate-900 border border-cyan-500/40 rounded-2xl shadow-[0_0_50px_rgba(6,182,212,0.2)] overflow-hidden flex flex-col my-auto max-h-[95vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* 最上部アクセントグラデーション */}
        <div className="h-1.5 w-full bg-gradient-to-r from-cyan-500 via-blue-500 to-emerald-400" />

        {/* ヘッダー */}
        <div className="px-5 py-4 border-b border-slate-800 bg-slate-950/90 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shadow-md shadow-cyan-950">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/40 font-mono">
                  PRO ACTIVATION
                </span>
                {licenseInfo.isPro && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    有効化中
                  </span>
                )}
              </div>
              <h3 className="text-base font-bold text-white mt-0.5">
                {isEn ? 'PRO License Authentication' : 'PRO版 認証コード入力・ライセンス管理'}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* モーダル本文 */}
        <div className="p-5 space-y-4 overflow-y-auto max-h-[75vh]">
          {/* 既に有効化されている場合のステータスカード */}
          {licenseInfo.isPro ? (
            <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-950/40 to-slate-900 border border-emerald-500/40 space-y-3 shadow-inner">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  <span className="text-sm font-bold text-emerald-300">
                    {licenseInfo.type === 'lifetime'
                      ? '買い切り永久ライセンス（有効）'
                      : '月額サブスクリプション（契約中）'}
                  </span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/50 text-emerald-300 font-bold">
                  ACTIVE
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono bg-slate-950/70 p-3 rounded-lg border border-slate-800">
                <div>
                  <span className="text-[10px] text-slate-400 block">登録メールアドレス</span>
                  <span className="text-slate-200 font-semibold">{licenseInfo.email}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">認証コード</span>
                  <span className="text-cyan-300 font-bold">{licenseInfo.code}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">ライセンス形態</span>
                  <span className="text-slate-300">
                    {licenseInfo.type === 'lifetime' ? '買い切り（無期限・永久）' : '月額自動更新'}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">有効期限</span>
                  <span className="text-slate-300">
                    {licenseInfo.expiresAt
                      ? new Date(licenseInfo.expiresAt).toLocaleDateString()
                      : '永久（無期限開放）'}
                  </span>
                </div>
              </div>

              <div className="text-[11px] text-slate-300 bg-slate-900/90 p-2.5 rounded-lg border border-slate-800 space-y-1">
                <div className="font-bold text-cyan-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>PRO版機能がすべて開放されています</span>
                </div>
                <p className="text-slate-400 leading-relaxed text-[11px]">
                  全通貨ペア（USDJPY, GBPJPY, XAUUSD等）、長期1〜5年バックテスト、複利・固定ロット設定、複数ポジション保有、および深層ロジック検証をご利用いただけます。
                </p>
              </div>

              <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>ライセンス認証済みです。すべてのPRO機能をご利用いただけます。</span>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="w-full flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-400 hover:from-cyan-400 hover:to-teal-300 text-xs text-slate-950 font-black transition cursor-pointer shadow-md shadow-cyan-950/40"
              >
                <span>閉じる（PRO版の利用を続ける）</span>
              </button>
            </div>
          ) : (
            <>
              {/* ご案内バナー */}
              <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-300 space-y-1.5">
                <div className="flex items-center gap-2 text-cyan-300 font-bold">
                  <CreditCard className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Stripe決済で購入後、メールに送付された認証コードを入力</span>
                </div>
                <p className="text-slate-400 leading-relaxed text-[11px]">
                  買い切り版・月額サブスクリプションのいずれをご購入いただいた場合も、決済時に登録されたメールアドレス宛に届いた認証コードを入力することで即座にPRO版が開放されます。
                </p>
              </div>

              {/* 認証フォーム */}
              <form onSubmit={handleVerify} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-cyan-400" />
                    <span>登録メールアドレス</span>
                  </label>
                  <input
                    type="email"
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder="例: buyer@example.com"
                    required
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 focus:border-cyan-500 focus:outline-none text-slate-100 text-sm font-mono placeholder:text-slate-600 transition"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-cyan-400" />
                    <span>認証コード</span>
                  </label>
                  <input
                    type="text"
                    value={codeInput}
                    onChange={(e) => setCodeInput(e.target.value.toUpperCase())}
                    placeholder="例: PRO-LIFE-XXXX-XXXX または PRO-SUB-XXXX-XXXX"
                    required
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 focus:border-cyan-500 focus:outline-none text-cyan-300 text-sm font-mono tracking-wider placeholder:text-slate-600 transition uppercase"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    ※ハイフンを含めて大文字・小文字どちらでも入力可能です。
                  </span>
                </div>

                {/* エラー・成功メッセージ */}
                {errorMessage && (
                  <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-600/60 text-xs text-rose-300 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                {successMessage && (
                  <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-500/60 text-xs text-emerald-300 flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{successMessage}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-600 via-blue-600 to-emerald-500 hover:from-cyan-500 hover:to-emerald-400 text-slate-950 font-black text-sm tracking-wide shadow-lg shadow-cyan-950/50 transition cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                      <span>照合中...</span>
                    </>
                  ) : (
                    <>
                      <Key className="w-4 h-4" />
                      <span>認証してPRO版を開放する</span>
                    </>
                  )}
                </button>
              </form>

              {/* 開発・テスト用クイック入力ボタン（ユーザー様が即座に動作テストできるよう用意） */}
              <div className="p-3 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2">
                <div className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-400" />
                  <span>【動作確認テスト用】ワンクリック認証入力</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                  <button
                    type="button"
                    onClick={() => handleApplyPreset('test@example.com', 'PRO-LIFE-7777-8888')}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-cyan-500/50 text-slate-300 hover:text-cyan-300 flex flex-col items-start transition cursor-pointer text-left"
                  >
                    <span className="font-bold text-cyan-400">⚡ 買い切り版（永久）テスト</span>
                    <span className="text-[10px] text-slate-400 font-mono">test@example.com</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleApplyPreset('sub@example.com', 'PRO-SUB-2026-9999')}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-emerald-500/50 text-slate-300 hover:text-emerald-300 flex flex-col items-start transition cursor-pointer text-left"
                  >
                    <span className="font-bold text-emerald-400">⚡ サブスク版（30日）テスト</span>
                    <span className="text-[10px] text-slate-400 font-mono">sub@example.com</span>
                  </button>
                </div>
              </div>

              {/* まだ購入していない方向け案内 */}
              <div className="p-3 rounded-xl bg-blue-950/30 border border-blue-900/40 flex items-center justify-between gap-3">
                <div className="text-xs text-slate-300">
                  <span className="font-bold text-white block">まだ認証コードをお持ちでない方</span>
                  <span className="text-[11px] text-slate-400">
                    Stripe決済ページより買い切りまたはサブスクをご購入いただけます。
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenUpgradeModal();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 text-xs font-bold shrink-0 transition cursor-pointer"
                >
                  上位版案内を見る
                </button>
              </div>
            </>
          )}

          {/* 検証時間の違いについての重要な明記 */}
          <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
            <div className="font-bold text-slate-300 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span>【重要】無料版とPRO版の検証プロセスの違いについて</span>
            </div>
            <p className="leading-relaxed">
              <strong>無料版</strong>は条件確認用の簡易シミュレーション（EURUSD・3か月・約5分）を実施します。<br />
              <strong>上位PRO版</strong>は簡易スキップではなく、1〜5年の全ティックデータ・複数通貨ペア・複雑に絡み合う複数ロジックの動的干渉を徹底的に走査・深層検証（ディープテスト）するため、より高度で網羅的な検証時間をかけてプロ水準のEAを出力します。
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
