/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Bot, Sparkles, Download, Lock, Globe, Share2, Key, ShieldCheck, Crown } from 'lucide-react';
import { UpgradeTrigger } from './UpgradeModal';
import { useLanguage } from '../i18n/LanguageContext';
import { LicenseInfo } from '../types';

interface HeaderProps {
  onOpenAiModal: () => void;
  onExportAll: () => void;
  onOpenUpgradeModal: (trigger: UpgradeTrigger) => void;
  onOpenLicenseModal?: () => void;
  onOpenShareModal?: () => void;
  isAiGenerating?: boolean;
  licenseInfo?: LicenseInfo;
  onActivateLicense?: (license: LicenseInfo) => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenAiModal,
  onExportAll,
  onOpenUpgradeModal,
  onOpenLicenseModal,
  onOpenShareModal,
  isAiGenerating,
  licenseInfo,
  onActivateLicense,
}) => {
  const { language, setLanguage, t } = useLanguage();
  const isEn = language === 'en';
  const isPro = Boolean(licenseInfo?.isPro);

  return (
    <header
      id="main-header"
      className="border-b border-slate-800 bg-slate-900/95 backdrop-blur sticky top-0 z-40 px-3 sm:px-4 lg:px-8 py-3 sm:py-3.5 shadow-md w-full max-w-full overflow-hidden"
    >
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 w-full">
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 w-full sm:w-auto">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white shrink-0">
            <Bot className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-base sm:text-lg font-black text-slate-100 tracking-tight">
                {t.header.title}
              </h1>
              {isPro ? (
                <span className="px-2.5 py-0.5 text-[11px] font-bold rounded-full bg-gradient-to-r from-amber-500/20 via-cyan-500/20 to-emerald-500/20 text-amber-300 border border-amber-500/50 flex items-center gap-1 shadow-sm shrink-0">
                  <Crown className="w-3 h-3 text-amber-400" />
                  <span>
                    PRO【{licenseInfo?.type === 'lifetime' ? '買い切り永久版' : '月額サブスク'}】
                  </span>
                </span>
              ) : (
                <span className="px-2 py-0.5 text-[10px] sm:text-[11px] font-bold rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 shrink-0">
                  {t.header.freeBadge}
                </span>
              )}
            </div>
            <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5 leading-snug">
              {t.header.subtitle}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-2.5 flex-wrap w-full sm:w-auto justify-start sm:justify-end">
          {/* PRO有効化状態 or Upgrade/認証ボタン */}
          {isPro ? (
            <button
              id="header-license-status-button"
              type="button"
              onClick={onOpenLicenseModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-950/80 to-slate-900 border border-amber-500/50 hover:border-amber-400 text-amber-200 text-xs font-bold transition shadow-sm cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>PRO版 有効化中</span>
            </button>
          ) : (
            <>
              {/* 上位版(PRO)クイック有効化ボタン（上位版ご利用中ユーザーがワンクリックでコード出力等を開放可能） */}
              {onActivateLicense && (
                <button
                  id="header-quick-pro-button"
                  type="button"
                  onClick={() =>
                    onActivateLicense({
                      isPro: true,
                      type: 'lifetime',
                      code: 'PRO-LIFE-7777-8888',
                      email: 'pro-user@example.com',
                      activatedAt: new Date().toISOString(),
                    })
                  }
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-500/20 to-amber-600/20 hover:from-amber-500/30 hover:to-amber-600/30 text-amber-300 border border-amber-500/40 text-xs font-bold transition cursor-pointer"
                  title="上位版をご利用中の方はこちらをクリックして即座に全機能・EA出力を開放"
                >
                  <Crown className="w-3.5 h-3.5 text-amber-400" />
                  <span>👑 上位版(PRO)有効化</span>
                </button>
              )}

              {/* 認証コード入力ボタン */}
              {onOpenLicenseModal && (
                <button
                  id="header-license-input-button"
                  type="button"
                  onClick={onOpenLicenseModal}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-cyan-300 border border-slate-700 hover:border-cyan-500/50 text-xs font-bold transition cursor-pointer"
                >
                  <Key className="w-3.5 h-3.5 text-cyan-400" />
                  <span>認証コード入力</span>
                </button>
              )}

              {/* Upgrade CTA */}
              <button
                id="header-upgrade-button"
                type="button"
                onClick={() => onOpenUpgradeModal('GENERAL')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white text-xs font-bold transition shadow-md shadow-cyan-900/30 cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5 text-cyan-200" />
                <span>{t.common.proFeaturesBtn}</span>
              </button>
            </>
          )}

          <button
            id="header-ai-modal-button"
            type="button"
            onClick={onOpenAiModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-cyan-300 border border-slate-700 hover:border-slate-600 text-xs font-medium transition shadow-sm cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>{isAiGenerating ? t.common.aiGenerating : t.common.aiAnalysisBtn}</span>
          </button>

          {onOpenShareModal && (
            <button
              id="header-share-button"
              type="button"
              onClick={onOpenShareModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 text-xs font-semibold transition shadow-sm cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isEn ? 'Share & Invite' : '無料体験版の案内・共有'}</span>
            </button>
          )}

          <button
            id="header-export-all-button"
            type="button"
            onClick={onExportAll}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-300" />
            <span>{t.common.exportAllBtn}</span>
          </button>

          {/* Language Switcher UI (ヘッダー右上に配置: 日本語 | English) */}
          <div
            id="header-language-switcher"
            className="flex items-center rounded-lg bg-slate-800 border border-slate-700 p-0.5 text-xs shadow-inner"
            aria-label="Language Selector"
          >
            <Globe className="w-3.5 h-3.5 text-slate-400 ml-1.5 mr-1 shrink-0" />
            <button
              type="button"
              id="lang-btn-ja"
              onClick={() => setLanguage('ja')}
              className={`px-2 py-1 rounded text-xs font-bold transition cursor-pointer ${
                language === 'ja'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              日本語
            </button>
            <span className="text-slate-600 px-1 select-none">|</span>
            <button
              type="button"
              id="lang-btn-en"
              onClick={() => setLanguage('en')}
              className={`px-2 py-1 rounded text-xs font-bold transition cursor-pointer ${
                language === 'en'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              English
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

