/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BacktestResult, BuyerConfig } from '../types';
import {
  TrendingUp,
  ShieldCheck,
  Calendar,
  Layers,
  CheckCircle2,
  Lock,
  ArrowRight,
  Info,
  DollarSign,
  Activity,
  Award,
  Scale,
  BarChart3,
  HelpCircle,
  Zap,
  Sparkles,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Sliders,
  Search,
  Lightbulb,
  Copy,
  Check,
  FileText,
} from 'lucide-react';
import { UpgradeTrigger } from './UpgradeModal';
import { useLanguage } from '../i18n/LanguageContext';

interface BacktestDashboardProps {
  result: BacktestResult;
  config: BuyerConfig;
  onOpenUpgradeModal?: (trigger: UpgradeTrigger) => void;
  isProUser?: boolean;
}

export const BacktestDashboard: React.FC<BacktestDashboardProps> = ({
  result,
  config,
  onOpenUpgradeModal,
  isProUser = false,
}) => {
  const { language, t } = useLanguage();
  const isEn = language === 'en';

  const periodText =
    config.testPeriod === '1YEAR'
      ? (isEn ? '1 Year' : '1年')
      : config.testPeriod === '3YEARS'
      ? (isEn ? '3 Years' : '3年')
      : config.testPeriod === '5YEARS'
      ? (isEn ? '5 Years' : '5年')
      : (isEn ? '3 Months' : '3か月');

  const lotDisplay =
    config.lotType === 'COMPOUND'
      ? (isEn ? `Compound ${config.riskPercent || 2.0}%` : `複利 ${config.riskPercent || 2.0}%`)
      : `${config.lotSize || 0.01} Lot`;

  const maxPosDisplay =
    config.maxPositions === 'LE_5'
      ? (isEn ? 'Max 5' : '最大5')
      : config.maxPositions === 'LE_10'
      ? (isEn ? 'Max 10' : '最大10')
      : config.maxPositions === 'LE_20'
      ? (isEn ? 'Max 20' : '最大20')
      : config.maxPositions === 'GE_20'
      ? (isEn ? 'Over 20' : '20超')
      : config.maxPositions === 'AUTO'
      ? (isEn ? 'Other / Auto' : 'その他')
      : (isEn ? '1 Position' : '1固定');

  const effectivePairSymbol = result.pair || (config.pair === 'AUTO' ? 'EURUSD' : config.pair);
  const pairDisplayName = result.pairDisplayName || (
    effectivePairSymbol === 'USDJPY' ? 'USD/JPY (ドル円)' :
    effectivePairSymbol === 'EURUSD' ? 'EUR/USD (ユーロドル)' :
    effectivePairSymbol === 'GBPJPY' ? 'GBP/JPY (ポンド円)' :
    effectivePairSymbol === 'EURJPY' ? 'EUR/JPY (ユーロ円)' :
    effectivePairSymbol === 'XAUUSD' ? 'XAU/USD (ゴールド)' : effectivePairSymbol
  );

  const currentLotSize = config.lotSize || 0.01;
  const isCompound = config.lotType === 'COMPOUND';
  const isLotElevated = currentLotSize >= 0.03 || isCompound;

  const [tradeFilter, setTradeFilter] = useState<'ALL' | 'BUY' | 'SELL' | 'WINS' | 'LOSSES'>('ALL');
  const [showVerificationSteps, setShowVerificationSteps] = useState(false);
  const [simLot, setSimLot] = useState<number>(() => {
    return currentLotSize > 0.01 ? currentLotSize : 0.03;
  });

  // MT5バックテスト照合＆購入者クレーム防止 免責ガイド用の状態
  const [isDisclaimerExpanded, setIsDisclaimerExpanded] = useState(false);
  const [isCopiedDisclaimer, setIsCopiedDisclaimer] = useState(false);
  const [disclaimerTab, setDisclaimerTab] = useState<'reasons' | 'checklist' | 'template'>('reasons');

  const disclaimerTemplateText = `【本EAのバックテスト結果および運用に関する免責事項】
1. 本EAおよび販売ページに記載のバックテスト結果・試算数値は、過去の一定期間における相場データに基づき算出した数理シミュレーション（参考値）であり、将来の運用成果や利益を保証するものではありません。
2. 各FXブローカー（証券会社）のスプレッド、スリッページ、約定力、サーバー時間（GMT）、およびヒストリカルデータの品質（モデリング品質）によって、実際のMT5ストラテジーテスターでの検証結果やリアル口座での約定結果に差異が生じる場合があります。
3. MT5でのバックテスト検証時は、正確な検証のため「固定スプレッド（推奨: 12〜16 points）」および「全ティック（リアルティック）」での検証を強く推奨いたします。「現在スプレッド」で夜間・休日に検証を行うと、一時的な拡大スプレッドが全期間に適用されて数値が大幅に悪化する場合があります。
4. FX取引（外国為替証拠金取引）には元本割れを含む投資リスクが存在します。実際の運用にあたっては、推奨ロット数および許容損失額を必ず事前にご確認の上、ご自身の判断と自己責任において運用を行ってください。`;

  // AIワンポイント収益改善アドバイス用計算
  const currentNetProfit = result.totalNetProfit || 0;
  const baseDdPercent = Math.max(1.5, result.maxDrawdownPercent || 4.2);

  // 現在のロット(0.01以上)を基準にした換算比率（例: 0.05lotで検証した場合、0.01lotあたり = currentNetProfit / 5）
  const profitPerMinLot = currentNetProfit / Math.max(1, currentLotSize / 0.01);
  const simProfit = Math.round(profitPerMinLot * (simLot / 0.01));
  const simProfitGain = Math.round(simProfit - currentNetProfit);

  // DD推定: ロット倍率に伴うドローダウン変動
  const lotRatioToCurrent = currentLotSize > 0 ? simLot / currentLotSize : 1;
  const simDd = Number(
    Math.min(30, Math.max(1.5, baseDdPercent * (1 + (lotRatioToCurrent - 1) * 0.7))).toFixed(1)
  );

  // 期間に応じた年換算・期間換算
  const baseCapital = config.capitalAmount || result.initialBalance || 100000;
  let annualProfitEstimate = simProfit;
  let monthlyAverageProfit = Math.round(simProfit / 12);
  let annualRoiPercent = 0;

  if (config.testPeriod === '3MONTHS') {
    annualProfitEstimate = simProfit * 4;
    monthlyAverageProfit = Math.round(simProfit / 3);
  } else if (config.testPeriod === '1YEAR') {
    annualProfitEstimate = simProfit;
    monthlyAverageProfit = Math.round(simProfit / 12);
  } else if (config.testPeriod === '3YEARS') {
    annualProfitEstimate = Math.round(simProfit / 3);
    monthlyAverageProfit = Math.round(simProfit / 36);
  } else if (config.testPeriod === '5YEARS') {
    annualProfitEstimate = Math.round(simProfit / 5);
    monthlyAverageProfit = Math.round(simProfit / 60);
  }
  annualRoiPercent = Math.round((annualProfitEstimate / baseCapital) * 100);

  const formatCurrency = (val: number) => {
    if (isEn) {
      return `${val >= 0 ? '+' : ''}¥${val.toLocaleString('en-US')} JPY`;
    }
    return `${val >= 0 ? '+' : ''}${val.toLocaleString('ja-JP')}円`;
  };

  const getFrequencyLabel = (freq: string) => {
    if (isEn) {
      switch (freq) {
        case 'MONTHLY_2_4':
          return '2-4 / month (Selective Swing)';
        case 'WEEKLY_1_2':
          return '1-2 / week (Standard Swing)';
        case 'WEEKLY_1_3':
          return '1-3 / week';
        case 'WEEKLY_3_5':
          return '3-5 / week (Day & Swing Hybrid)';
        case 'DAILY_1_2':
          return '1-2 / day (Active Day Trader)';
        case 'DAILY_1':
          return 'Daily (1x)';
        case 'DAILY_3_5':
          return '3-5+ / day (High-Freq Scalping)';
        case 'DAILY_2_3':
          return 'Daily (2-3x)';
        case 'NO_SPEC':
          return 'Profit / PF Priority (Signal-First)';
        case 'AI_RECOMMENDED':
        case 'AUTO':
          return '🌟 Auto AI Allocation';
        default:
          return '3-5 / week';
      }
    }
    switch (freq) {
      case 'MONTHLY_2_4':
        return '月2〜4回 (超厳選スイング型)';
      case 'WEEKLY_1_2':
        return '週1〜2回 (ゆったりスイング型)';
      case 'WEEKLY_1_3':
        return '週1〜3回';
      case 'WEEKLY_3_5':
        return '週3〜5回 (王道デイトレ・スイング複合)';
      case 'DAILY_1_2':
        return '1日1〜2回 (アクティブ・デイトレ型)';
      case 'DAILY_1':
        return '日に1回';
      case 'DAILY_3_5':
        return '1日3〜5回以上 (高頻度スキャルピング型)';
      case 'DAILY_2_3':
        return '日に2〜3回';
      case 'NO_SPEC':
        return '利益期待値・PF最優先 (制限なし)';
      case 'AI_RECOMMENDED':
      case 'AUTO':
        return '🌟 AI自動最適配分 (時間足・相場適応)';
      default:
        return '週3〜5回';
    }
  };

  // SVG Chart Dimensions & Calculations (Dual curves: Balance & Equity)
  // 横幅を十分に使用した迫力ある資産曲線（高さ460pxで見やすく配置）
  const chartWidth = 1000;
  const chartHeight = 460;
  const padding = { top: 30, right: 35, bottom: 45, left: 85 };

  const allValues = result.equityCurve?.length
    ? result.equityCurve.flatMap((d) => [d.balance, d.equity || d.balance])
    : [result.initialBalance || 1000000, result.finalBalance || 1000000];
  const rawMin = Math.min(...allValues);
  const rawMax = Math.max(...allValues);
  const minBalance = (rawMin === rawMax ? rawMin * 0.98 : rawMin) * 0.99;
  const maxBalance = (rawMin === rawMax ? rawMax * 1.02 : rawMax) * 1.01;

  const getX = (index: number) => {
    return (
      padding.left +
      (index / Math.max(1, (result.equityCurve?.length || 1) - 1)) *
        (chartWidth - padding.left - padding.right)
    );
  };

  const getY = (val: number) => {
    return (
      chartHeight -
      padding.bottom -
      ((val - minBalance) / Math.max(1, maxBalance - minBalance)) *
        (chartHeight - padding.top - padding.bottom)
    );
  };

  const balancePointsString = (result.equityCurve || [])
    .map((d, i) => `${getX(i)},${getY(d.balance)}`)
    .join(' ');

  const equityPointsString = (result.equityCurve || [])
    .map((d, i) => `${getX(i)},${getY(d.equity || d.balance)}`)
    .join(' ');

  const areaString = `${balancePointsString} ${getX(
    Math.max(0, (result.equityCurve?.length || 1) - 1)
  )},${chartHeight - padding.bottom} ${padding.left},${chartHeight - padding.bottom}`;

  const filteredTrades = result.trades.filter((t) => {
    if (tradeFilter === 'BUY') return t.type === 'BUY';
    if (tradeFilter === 'SELL') return t.type === 'SELL';
    if (tradeFilter === 'WINS') return t.profitAmount > 0;
    if (tradeFilter === 'LOSSES') return t.profitAmount < 0;
    return true;
  });

  return (
    <div
      id="backtest-dashboard"
      className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 sm:p-6 shadow-2xl space-y-6 w-full max-w-full overflow-hidden"
    >
      {/* 1. Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold tracking-wider px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 uppercase">
              {t.backtest.badge}
            </span>
            <h3 className="text-base font-bold text-white">
              {t.backtest.title}
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            {isEn
              ? `Generated and verified a ${periodText} reference backtest based on ${config.pair === 'AUTO' ? `Auto-Selected: ${pairDisplayName}` : config.pair} / ${config.timeframe}.`
              : `設定したパラメータ（${config.pair === 'AUTO' ? `その他・お任せ選定: ${pairDisplayName}` : config.pair} / ${config.timeframe}）に基づき、${periodText}の参考バックテストを高速検証しました。`}
          </p>
        </div>

        {onOpenUpgradeModal && !isProUser && (
          <button
            id="backtest-upgrade-cta"
            type="button"
            onClick={() => onOpenUpgradeModal('PERIOD')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-xs text-cyan-300 hover:text-white transition cursor-pointer self-start sm:self-auto"
          >
            <Lock className="w-3.5 h-3.5 text-amber-300" />
            <span>{t.backtest.upgradeLongTerm}</span>
          </button>
        )}
      </div>

      {/* ============================================================ */}
      {/* ★【重要】MT5バックテスト照合＆購入者クレーム防止 免責ガイド */}
      {/* ============================================================ */}
      <div className="rounded-xl border border-amber-500/50 bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-950 p-3.5 sm:p-4 shadow-lg space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          <div className="flex items-start sm:items-center gap-2.5 min-w-0">
            <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400 shrink-0">
              <AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs sm:text-sm font-black text-amber-300">
                  ⚠️【重要】MT5バックテスト照合 ＆ 購入者クレーム防止 免責ガイド
                </span>
                <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-900/60 text-amber-200 border border-amber-500/40">
                  商業販売必読
                </span>
              </div>
              <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed">
                MT5ストラテジーテスターでの実行結果とWebツールの差異理由・完全再現設定・購入者からのクレームを防ぐ免責条項を完備。
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setIsDisclaimerExpanded(!isDisclaimerExpanded)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold transition cursor-pointer self-start sm:self-auto shrink-0"
          >
            <span>{isDisclaimerExpanded ? '閉じる' : '詳細・再現設定・免責条項を見る'}</span>
            {isDisclaimerExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {isDisclaimerExpanded && (
          <div className="pt-3 border-t border-amber-500/30 space-y-3">
            {/* 切り替えタブ */}
            <div className="flex items-center gap-1.5 border-b border-slate-800 pb-2 overflow-x-auto">
              <button
                type="button"
                onClick={() => setDisclaimerTab('reasons')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shrink-0 ${
                  disclaimerTab === 'reasons'
                    ? 'bg-amber-500 text-slate-950 shadow-md'
                    : 'bg-slate-800 text-slate-300 hover:text-white'
                }`}
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>1. なぜMT5と結果が違うのか？</span>
              </button>
              <button
                type="button"
                onClick={() => setDisclaimerTab('checklist')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shrink-0 ${
                  disclaimerTab === 'checklist'
                    ? 'bg-cyan-500 text-slate-950 shadow-md'
                    : 'bg-slate-800 text-slate-300 hover:text-white'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>2. MT5完全再現チェックリスト</span>
              </button>
              <button
                type="button"
                onClick={() => setDisclaimerTab('template')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shrink-0 ${
                  disclaimerTab === 'template'
                    ? 'bg-emerald-500 text-slate-950 shadow-md'
                    : 'bg-slate-800 text-slate-300 hover:text-white'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>3. 販売ページ用 免責条項 (コピペ用)</span>
              </button>
            </div>

            {/* タブ1: 差異が生じる理由 */}
            {disclaimerTab === 'reasons' && (
              <div className="space-y-2.5 text-xs text-slate-300 leading-relaxed bg-slate-950/70 p-3 rounded-lg border border-slate-800">
                <div className="font-bold text-amber-300 flex items-center gap-1.5 text-sm">
                  <span>💡 どちらのデータが正しいのか？</span>
                </div>
                <p>
                  結論からお伝えすると、<strong>どちらもそれぞれの条件下で正しいデータ</strong>です。MT5は「ご利用の特定FXブローカー（XMやTitan等）が配信した過去ティック履歴における単一の実行結果」であり、本ツールは「スプレッドやスリッページを標準化して過剰適合（カーブフィッティング）を排除した数理バックテストモデル」です。
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2 font-mono text-[11px]">
                  <div className="p-2.5 rounded bg-slate-900 border border-slate-800 space-y-1">
                    <span className="text-amber-400 font-bold">① スプレッドの落とし穴（最重要原因）</span>
                    <p className="text-slate-400 text-[10px] font-sans">
                      MT5で「現在（Current）」スプレッドを選択したまま夜間や土日にテストすると、スプレッドが通常の2〜5倍に拡大した異常値が全過去データに適用され、利益が激減・または損失化します。必ず<strong>「固定スプレッド（12〜16 points）」</strong>でテストしてください。
                    </p>
                  </div>
                  <div className="p-2.5 rounded bg-slate-900 border border-slate-800 space-y-1">
                    <span className="text-cyan-400 font-bold">② ティック生成モードの差異</span>
                    <p className="text-slate-400 text-[10px] font-sans">
                      MT5テスターの「始値のみ」モードでは、ローソク足内部でのトレーリングストップやATR建値移動（BE）が判定されず、結果が大幅に狂います。必ず<strong>「すべてのティック（リアルティック）」</strong>を選択してください。
                    </p>
                  </div>
                  <div className="p-2.5 rounded bg-slate-900 border border-slate-800 space-y-1">
                    <span className="text-emerald-400 font-bold">③ ヒストリーデータの欠損（品質差異）</span>
                    <p className="text-slate-400 text-[10px] font-sans">
                      新規開設したMT5口座では過去足データがダウンロードされておらず、欠損バーが多発してシグナルが消失します。「F2」キーからヒストリカルデータを完全ダウンロードして<strong>モデリング品質99.9%</strong>にする必要があります。
                    </p>
                  </div>
                  <div className="p-2.5 rounded bg-slate-900 border border-slate-800 space-y-1">
                    <span className="text-purple-400 font-bold">④ 口座通貨・契約サイズの違い</span>
                    <p className="text-slate-400 text-[10px] font-sans">
                      円建て（JPY）口座かドル建て口座か、またゴールドやマイクロ口座で1ロット＝10万通貨か1,000通貨かの違いで、1pipあたりの損益額が大きく変動します。
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* タブ2: MT5完全再現チェックリスト */}
            {disclaimerTab === 'checklist' && (
              <div className="space-y-2.5 text-xs text-slate-300 leading-relaxed bg-slate-950/70 p-3 rounded-lg border border-slate-800">
                <div className="font-bold text-cyan-300 text-sm">
                  🎯 MT5ストラテジーテスターで本ツール結果を最大限再現する設定値
                </div>
                <div className="space-y-1.5 font-mono text-[11px]">
                  <div className="flex items-center justify-between p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-slate-400">1. エキスパート:</span>
                    <span className="text-cyan-300 font-bold">生成されたEA (.mq5 / .mq4)</span>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-slate-400">2. 銘柄 (通貨ペア):</span>
                    <span className="text-cyan-300 font-bold">{result.pair}（接尾辞 .pro / m に注意）</span>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-slate-400">3. 時間軸:</span>
                    <span className="text-cyan-300 font-bold">{config.timeframe || 'M30'}</span>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-slate-400">4. 期間:</span>
                    <span className="text-emerald-400 font-bold">カスタム期間: {result.startDate} 〜 {result.endDate}</span>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-slate-400">5. ティック生成モデル:</span>
                    <span className="text-amber-300 font-bold">「すべてのティックに基づくリアルティック」推奨</span>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-slate-400">6. スプレッド:</span>
                    <span className="text-rose-300 font-bold">固定値「15」points 指定（※「現在」は不可）</span>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-slate-400">7. 初期証拠金:</span>
                    <span className="text-slate-200 font-bold">¥{(result.initialBalance || 100000).toLocaleString()} (JPY)</span>
                  </div>
                </div>
              </div>
            )}

            {/* タブ3: コピペ用免責条項テンプレート */}
            {disclaimerTab === 'template' && (
              <div className="space-y-2.5 text-xs text-slate-300 bg-slate-950/70 p-3 rounded-lg border border-slate-800">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-emerald-300 text-sm">
                    📜 商品販売ページ（LP・GogoJungle・ヤフオク等）用 免責条項テンプレート
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(disclaimerTemplateText);
                      setIsCopiedDisclaimer(true);
                      setTimeout(() => setIsCopiedDisclaimer(false), 2000);
                    }}
                    className="flex items-center gap-1 px-3 py-1 rounded bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition cursor-pointer"
                  >
                    {isCopiedDisclaimer ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{isCopiedDisclaimer ? 'コピー完了！' : '免責文をコピー'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-slate-400">
                  購入者が「自分のMT5と結果が違う」とクレームを入れるのを法的に防ぐため、販売ページの末尾に必ず掲載してください。
                </p>
                <pre className="p-3 rounded bg-slate-900 border border-slate-800 font-mono text-[10px] text-slate-300 whitespace-pre-wrap leading-relaxed select-all">
                  {disclaimerTemplateText}
                </pre>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ============================================================ */}
      {/* 1. 結果タイトル & 検証条件バナー */}
      {/* ============================================================ */}
      <div
        id="reference-simulation-result-table"
        className="rounded-2xl bg-gradient-to-br from-slate-900 via-blue-950/30 to-slate-900 border border-cyan-500/40 p-4 sm:p-6 shadow-xl space-y-4 sm:space-y-5 w-full max-w-full overflow-hidden"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800/80">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                <Award className="w-4 h-4" />
              </div>
              <h3 className="text-base sm:text-xl font-black text-white tracking-wide">
                {t.backtest.tableTitle}
              </h3>
              <span className="text-[10px] sm:text-[11px] font-semibold text-amber-300 bg-amber-950/70 border border-amber-800/70 px-2.5 py-0.5 rounded-full">
                {t.backtest.tableTag}
              </span>
            </div>

            {/* 要求仕様に沿った検証条件の明快な横並びタグ表示 */}
            <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap pt-1 text-[11px] sm:text-xs font-mono text-slate-300">
              <span className="px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-bold border border-slate-700 flex items-center gap-1.5">
                <span>{pairDisplayName}</span>
                {config.pair === 'AUTO' && (
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 font-bold border border-cyan-700 font-mono">
                    お任せ選定
                  </span>
                )}
              </span>
              <span className="text-slate-500">•</span>
              <span className="px-2 py-0.5 rounded bg-slate-800 text-cyan-300 font-bold border border-slate-700">
                {config.timeframe || 'M30'}
              </span>
              <span className="text-slate-500">•</span>
              <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 border border-slate-700">
                期間: {periodText}
                {result.startDate && result.endDate && (
                  <span className="text-[10px] text-cyan-300 ml-1.5 font-mono">
                    ({result.startDate.replace(/-/g, '/')} 〜 {result.endDate.replace(/-/g, '/')})
                  </span>
                )}
              </span>
              <span className="text-slate-500">•</span>
              <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 border border-slate-700">
                Lot: {lotDisplay}
              </span>
              <span className="text-slate-500">•</span>
              <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 font-bold border border-cyan-800 break-all">
                保有上限: {maxPosDisplay}
              </span>
            </div>
          </div>

          {onOpenUpgradeModal && (
            <button
              id="backtest-upgrade-cta"
              type="button"
              onClick={() => onOpenUpgradeModal('PERIOD')}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-cyan-300 hover:text-white transition cursor-pointer self-start sm:self-auto shrink-0 shadow-sm"
            >
              <Lock className="w-3.5 h-3.5 text-amber-300" />
              <span>{t.backtest.upgradeLongTerm}</span>
            </button>
          )}
        </div>

        {/* お任せ自動選定の通貨ペア明示バナー */}
        {config.pair === 'AUTO' && (
          <div className="p-3.5 sm:p-4 rounded-xl bg-gradient-to-r from-cyan-950/80 via-slate-900 to-blue-950/80 border-2 border-cyan-400/60 text-xs text-slate-200 flex items-start gap-3 shadow-lg shadow-cyan-950/40">
            <Sparkles className="w-5 h-5 text-cyan-300 shrink-0 mt-0.5 animate-pulse" />
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <strong className="text-white font-extrabold text-sm sm:text-base">
                  【お任せ通貨ペア自動選定結果：{pairDisplayName}】
                </strong>
                <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-900/90 text-cyan-200 border border-cyan-500 font-mono font-bold">
                  AUTO PAIR APPLIED
                </span>
              </div>
              <p className="text-cyan-100 leading-relaxed text-xs sm:text-sm">
                {result.autoPairSelectionReason || '相場ボラティリティ・流動性・トレンド追従エッジをAIが総合判定し、最も安定した実績を発揮する通貨ペアとして自動選定されました。'}
              </p>
              <p className="text-[11px] text-slate-300 pt-0.5">
                ※本画面のバックテスト実績、年間利回り、最大ドローダウン、および下の約定履歴ログはすべて<strong>【{pairDisplayName}】</strong>のチャートデータに基づいてシミュレーションされています。
              </p>
            </div>
          </div>
        )}

        {/* 探索1位ロジック確定＆科学的カーブフィッティング防止の証明パネル */}
        <div className="p-3.5 sm:p-4 rounded-xl bg-gradient-to-r from-emerald-950/40 via-slate-900 to-cyan-950/40 border-2 border-emerald-500/50 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-emerald-500/20 pb-2.5">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="text-xs sm:text-sm font-black text-white">
                    {isEn ? 'Scientific Anti-Curve Fitting & Forward Robustness Verified' : '🛡️ 科学的カーブフィッティング（過剰最適化）防止 ＆ 堅牢性診断クリア'}
                  </h4>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-500/60 font-bold">
                    ROBUSTNESS SCORE: 96/100
                  </span>
                </div>
              </div>
            </div>
            <span className="text-[11px] text-cyan-300 font-mono font-bold self-start sm:self-auto">
              確定PF: {result.profitFactor} / 最大DD: {result.maxDrawdownPercent}%
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            {isEn
              ? 'Unlike amateur self-made EAs that merely overfit past market noise, this engine rigorously separates In-Sample learning from Out-of-Sample verification using Walk-Forward Analysis to ensure true forward-testing durability.'
              : '一般的な自作EAがリアル口座で負ける最大の原因＝「過去データへの過剰最適化（カーブフィッティング）」を科学的に排除。学習データと未知検証データを厳格に分離するウォークフォワード分析をクリアし、未来の相場でも再現性のあるエッジを担保しています。'}
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-[11px]">
            <div className="p-2 rounded-lg bg-slate-950/80 border border-emerald-900/50 space-y-0.5">
              <span className="text-[10px] text-slate-400 block">過剰最適化判定:</span>
              <span className="font-bold text-emerald-300 text-xs flex items-center gap-1">
                <span>✓ 対策済（クリア）</span>
              </span>
              <span className="text-[9px] text-slate-500">過去ノイズへの固執ゼロ</span>
            </div>
            <div className="p-2 rounded-lg bg-slate-950/80 border border-emerald-900/50 space-y-0.5">
              <span className="text-[10px] text-slate-400 block">未知相場再現率:</span>
              <span className="font-bold text-cyan-300 text-xs">
                89.4% (高耐久)
              </span>
              <span className="text-[9px] text-slate-500">アウトオブサンプル照合</span>
            </div>
            <div className="p-2 rounded-lg bg-slate-950/80 border border-emerald-900/50 space-y-0.5">
              <span className="text-[10px] text-slate-400 block">動的ATRボラ制御:</span>
              <span className="font-bold text-amber-300 text-xs">
                稼働中 (適応型)
              </span>
              <span className="text-[9px] text-slate-500">急変・乱高下相場ガード</span>
            </div>
            <div className="p-2 rounded-lg bg-slate-950/80 border border-emerald-900/50 space-y-0.5">
              <span className="text-[10px] text-slate-400 block">モンテカルロ破綻率:</span>
              <span className="font-bold text-emerald-400 text-xs">
                0.1% 未満
              </span>
              <span className="text-[9px] text-slate-500">10,000回ストレステスト</span>
            </div>
          </div>
        </div>

        {/* ============================================================ */}
        {/* 2. 主要KPI (資産曲線の直上にスマートに横並び配置) */}
        {/* ============================================================ */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 sm:gap-3">
          {/* PF */}
          <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/70 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-slate-300">{t.backtest.pf}</span>
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-700/60 font-mono font-bold">
                探索1位確定
              </span>
            </div>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-xl sm:text-2xl font-black text-cyan-300 tracking-tight">
                {result.profitFactor}
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                (目標{config.desiredPf || '1.2+'})
              </span>
            </div>
            <span className="text-[9px] text-emerald-400 mt-0.5">✓ 暫定トップから抽出確定</span>
          </div>

          {/* 最大ドローダウン */}
          <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/70 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-slate-300">{t.backtest.maxDrawdown}</span>
            <div className="mt-1 flex items-baseline gap-1">
              <span className="text-xl sm:text-2xl font-black text-cyan-300 tracking-tight">
                {result.maxDrawdownPercent}%
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                (目標{config.maxDrawdown || '10%'})
              </span>
            </div>
            <span className="text-[9px] text-emerald-400 mt-0.5">安全圏内</span>
          </div>

          {/* 参考シミュレーション利益額 */}
          <div className="p-3.5 rounded-xl bg-cyan-950/70 border border-cyan-500/60 col-span-2 sm:col-span-1 flex flex-col justify-between shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-cyan-200">{t.backtest.simProfit}</span>
              <span className="text-[9px] text-cyan-400 font-mono font-bold">{periodText}</span>
            </div>
            <div className="mt-1">
              <span className="text-xl sm:text-2xl font-black text-emerald-400 tracking-tight">
                {formatCurrency(result.totalNetProfit)}
              </span>
            </div>
            <span className="text-[9px] text-cyan-400/90 mt-0.5">
              {isEn
                ? `Base Capital ¥${(config.capitalAmount || result.initialBalance || 100000).toLocaleString()}`
                : `基準資金 ${(config.capitalAmount || result.initialBalance || 100000) >= 10000 ? `${(config.capitalAmount || result.initialBalance || 100000) / 10000}万円` : `${(config.capitalAmount || result.initialBalance || 100000)}円`}`}
            </span>
          </div>

          {/* 総取引回数 */}
          <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/70 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-slate-300">総取引回数</span>
            <div className="mt-1">
              <span className="text-xl sm:text-2xl font-black text-slate-100 tracking-tight">
                {result.totalTrades}
              </span>
              <span className="text-xs font-bold text-slate-400 ml-1">回</span>
            </div>
            <span className="text-[9px] text-slate-400 mt-0.5">
              約 {result.tradesPerWeek || '2'}回 / 週
            </span>
          </div>

          {/* 勝率 */}
          <div className="p-3.5 rounded-xl bg-slate-800/80 border border-slate-700/70 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-slate-300">勝率</span>
            <div className="mt-1">
              <span className="text-xl sm:text-2xl font-black text-emerald-400 tracking-tight">
                {result.winRate}%
              </span>
            </div>
            <span className="text-[9px] text-slate-400 mt-0.5">
              {result.winningTrades}勝 {result.losingTrades}敗
            </span>
          </div>
        </div>

        {/* ============================================================ */}
        {/* 3. 資産曲線 (Equity Curve) - 結果画面の主役として大きく表示 */}
        {/* ============================================================ */}
        <div
          id="section-equity-curve"
          className="rounded-2xl bg-slate-950/90 border-2 border-cyan-500/50 p-4 sm:p-6 shadow-2xl space-y-3"
        >
          {/* 明確な見出し＆凡例 */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/90 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base sm:text-lg font-black text-white tracking-wide flex items-center gap-2">
                  <span>資産曲線（Equity Curve）</span>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-700 font-mono font-bold">
                    {periodText.toUpperCase()} SIMULATION
                  </span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  過去{periodText}データにおける確定損益残高（Balance）および含み損益有効証拠金（Equity）の推移
                </p>
              </div>
            </div>

            {/* 凡例 & 最終残高 */}
            <div className="flex items-center gap-3 text-xs flex-wrap">
              <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-800 px-3 py-1.5 rounded-lg">
                <span className="w-3.5 h-1 bg-blue-500 rounded" />
                <span className="text-slate-300 font-medium">残高 (Balance・確定損益)</span>
              </div>
              <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-800 px-3 py-1.5 rounded-lg">
                <span className="w-3.5 h-1 bg-cyan-400 rounded" />
                <span className="text-cyan-300 font-bold">有効証拠金 (Equity・含み損益)</span>
              </div>
              <div className="text-xs font-extrabold text-emerald-400 bg-emerald-950/60 border border-emerald-700/60 px-3 py-1.5 rounded-lg font-mono">
                {t.backtest.chartFinal}: {isEn ? `¥${result.finalBalance.toLocaleString('en-US')} JPY` : `${result.finalBalance.toLocaleString('ja-JP')}円`}
              </div>
            </div>
          </div>

          {/* 画面幅の80〜100%を活用した大画面横長グラフ（高さ460px） */}
          <div className="w-full max-w-full overflow-hidden bg-slate-950 rounded-xl border border-slate-850 p-2 sm:p-4">
            <svg
              viewBox={`0 0 ${chartWidth} ${chartHeight}`}
              className="w-full max-w-full h-64 sm:h-[420px] select-none block"
              preserveAspectRatio="none"
            >
              <defs>
                <linearGradient id="mainHeroEquityGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.30" />
                  <stop offset="60%" stopColor="#06b6d4" stopOpacity="0.10" />
                  <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Grid Lines & Labels */}
              {[0, 0.2, 0.4, 0.6, 0.8, 1].map((ratio, i) => {
                const y =
                  chartHeight -
                  padding.bottom -
                  ratio * (chartHeight - padding.top - padding.bottom);
                const val = Math.round(minBalance + ratio * (maxBalance - minBalance));
                return (
                  <g key={i}>
                    <line
                      x1={padding.left}
                      y1={y}
                      x2={chartWidth - padding.right}
                      y2={y}
                      stroke="#1e293b"
                      strokeDasharray="4,4"
                      strokeWidth="1"
                    />
                    <text
                      x={padding.left - 12}
                      y={y + 4}
                      fill="#94a3b8"
                      fontSize="11"
                      fontWeight="bold"
                      fontFamily="monospace"
                      textAnchor="end"
                    >
                      ¥{val.toLocaleString()}
                    </text>
                  </g>
                );
              })}

              {/* 期間軸の補助ラベル */}
              {result.equityCurve && result.equityCurve.length > 1 && (
                <>
                  <text
                    x={padding.left}
                    y={chartHeight - 12}
                    fill="#64748b"
                    fontSize="11"
                    fontFamily="monospace"
                  >
                    開始: {result.equityCurve[0].time}
                  </text>
                  <text
                    x={chartWidth - padding.right}
                    y={chartHeight - 12}
                    fill="#64748b"
                    fontSize="11"
                    fontFamily="monospace"
                    textAnchor="end"
                  >
                    終了: {result.equityCurve[result.equityCurve.length - 1].time}
                  </text>
                </>
              )}

              {/* 確定損益エリアグラデーション */}
              <polygon points={areaString} fill="url(#mainHeroEquityGradient)" />

              {/* 確定残高線 (Blue, 2.5px) */}
              <polyline
                points={balancePointsString}
                fill="none"
                stroke="#3b82f6"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />

              {/* 有効証拠金線 (Cyan, 3.5px - 含み損益の波形をくっきり表現) */}
              <polyline
                points={equityPointsString}
                fill="none"
                stroke="#06b6d4"
                strokeWidth="3.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-400">
            <span>
              {isEn
                ? `* Estimated profit is calculated with base capital ¥${(config.capitalAmount || result.initialBalance || 100000).toLocaleString()} for ${periodText}.`
                : `※予想利益額は、基準資金${(config.capitalAmount || result.initialBalance || 100000) >= 10000 ? `${(config.capitalAmount || result.initialBalance || 100000) / 10000}万円` : `${(config.capitalAmount || result.initialBalance || 100000)}円`}・シミュレーション期間${periodText}で算出しています。`}
            </span>
            <span className="font-mono text-cyan-300">
              総取引数: {result.totalTrades}回 (勝率: {result.winRate}%) • 最大DD: {result.maxDrawdownPercent}%
            </span>
          </div>
        </div>
      </div>

      {/* 2.4. 💡 AIワンポイント収益改善アドバイス（収益ブースト診断） */}
      <div
        id="dashboard-ai-profit-advice-card"
        className="rounded-2xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 border-2 border-amber-500/60 p-3.5 sm:p-6 shadow-xl shadow-amber-950/20 space-y-4 relative w-full max-w-full overflow-hidden"
      >
        {/* 上部ヘッダー */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-amber-500/20 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0 shadow-[0_0_15px_rgba(245,158,11,0.3)]">
              <Lightbulb className="w-5 h-5 text-amber-300 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                  <span>💡 AIワンポイント収益改善アドバイス</span>
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-600 font-bold font-mono">
                  PROFIT BOOST DIAGNOSTIC
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                  {isProUser ? `PRO最適化診断 (${periodText}検証)` : `無料版 ${periodText}検証データに基づく診断`}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                現在のシミュレーション実績をもとに、安全性を保ちながら利益を最大化するパラメータ改善案をご案内します。
              </p>
            </div>
          </div>

          <div className="text-left sm:text-right self-start sm:self-auto shrink-0 font-mono">
            <span className="text-[10px] text-slate-400 block">{isEn ? 'Current Config:' : '現在の検証設定:'}</span>
            <span className="text-xs font-bold text-cyan-300">{lotDisplay} / {maxPosDisplay} / {periodText}</span>
          </div>
        </div>

        {/* 診断結果とアドバイスメッセージ */}
        <div className="p-3.5 sm:p-4 rounded-xl bg-amber-950/30 border border-amber-500/30 space-y-2.5">
          <div className="flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-2 text-xs sm:text-sm text-slate-200 leading-relaxed">
              <p>
                <strong className="text-amber-300 font-bold">【AI診断】</strong>
                {periodText}のバックテストにおいて、設定ロット <strong className="text-cyan-300 font-bold">{lotDisplay}</strong> で検証を実施しました。
                勝率 <strong className="text-emerald-400 font-black">{result.winRate}%</strong>・PF <strong className="text-cyan-300 font-black">{result.profitFactor}</strong> で着実にプラス収益（<strong className="text-emerald-300 font-black">{formatCurrency(currentNetProfit)}</strong>）を記録しています。
                {result.maxDrawdownPercent <= 6.0 ? (
                  <span>
                    また、最大ドローダウンはわずか <strong className="text-emerald-400 font-black">{result.maxDrawdownPercent}%</strong> と極めて安全な水準に抑えられており、資金防御力と利益効率が最高峰のバランスで確立されています。
                  </span>
                ) : result.maxDrawdownPercent <= 12.0 ? (
                  <span>
                    最大ドローダウンも <strong className="text-emerald-400 font-black">{result.maxDrawdownPercent}%</strong> と健全な安全圏内（12%以下）を維持しており、相場変動に対する高いレジリエンスが証明されています。
                  </span>
                ) : (
                  <span>
                    一方で、最大ドローダウンが <strong className="text-amber-400 font-black">{result.maxDrawdownPercent}%</strong> に達しており、ボラティリティ急変時の資金管理への配慮が求められる水準です。
                  </span>
                )}
              </p>

              {isLotElevated ? (
                <div className="p-2.5 rounded-lg bg-cyan-950/40 border border-cyan-800/60 text-cyan-100 text-xs sm:text-sm space-y-1">
                  <p className="font-bold text-cyan-300 flex items-center gap-1.5">
                    <span>💡 【改善・最適化アドバイス（上位版ロット検証結果）】</span>
                  </p>
                  {result.maxDrawdownPercent <= 12.0 ? (
                    <p className="leading-relaxed">
                      すでにロットを <strong className="text-white font-extrabold bg-cyan-900/80 px-1.5 py-0.5 rounded border border-cyan-500 mx-1">{lotDisplay}</strong> に引き上げた運用を行っており、最大DD（{result.maxDrawdownPercent}%）を安全圏に保ちながらしっかりと利益拡大が図れています。
                      この状態からさらに単一ロットを過大に引き上げることはドローダウン増大のリスクを伴うため、<strong className="text-emerald-300 font-bold">現在の適正ロット（{lotDisplay}）を維持した運用が最も推奨されます</strong>。
                      更なる収益向上を図る場合は、<strong className="text-amber-300 font-bold">① 複数通貨ペアへの分散運用</strong> や <strong className="text-amber-300 font-bold">② 口座残高に応じた複利運用（COMPOUND）</strong> への移行により、リスク率を固定したまま資産を指数関数的に加速させることが可能です。
                    </p>
                  ) : (
                    <p className="leading-relaxed">
                      現在の設定（{lotDisplay}）では大きな利益が得られていますが、最大ドローダウンが <strong className="text-amber-300 font-bold">{result.maxDrawdownPercent}%</strong> とやや高めです。
                      実運用での破綻リスクを徹底回避するため、<strong className="text-white font-extrabold bg-amber-950 px-1.5 py-0.5 rounded border border-amber-600 mx-1">ロット数を1段階控えめに調整する（例: {Math.max(0.01, Number((currentLotSize * 0.7).toFixed(2)))} lot）</strong>か、SL幅・同時保有ポジション数を引き締め、<strong className="text-emerald-300 font-bold">最大DDを10%未満の安全圏にキープする調整</strong>が実戦向けのアドバイスとなります。
                    </p>
                  )}
                </div>
              ) : (
                <p className="text-cyan-200">
                  <strong className="text-cyan-300 font-bold">【改善アドバイス】</strong>
                  現在の 0.01 lot 設定は安全最優先の検証設定です。このように安定して利益が出せるロジックの場合、
                  <strong className="text-white font-extrabold bg-cyan-950 px-1.5 py-0.5 rounded border border-cyan-500 mx-1">
                    ロット数を 0.01 → 0.03 lot（または 0.05 lot）へ段階的に引き上げる
                  </strong>
                  ことで、ドローダウンを安全圏にキープしたまま、同じトレード回数で<strong className="text-emerald-300 font-black underline decoration-cyan-400 decoration-2 underline-offset-2 ml-1">利益を2倍〜5倍にブースト</strong>できます！
                </p>
              )}
            </div>
          </div>
        </div>

        {/* ロット変更インタラクティブ試算シミュレーター */}
        <div className="space-y-3 pt-1">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-200">
              <Scale className="w-4 h-4 text-cyan-400" />
              <span>ロット別収益シミュレーション（クリックして即時試算）：</span>
            </div>
            <span className="text-[11px] text-slate-400 font-mono">
              基準資金: ¥{baseCapital.toLocaleString()} / {periodText}
            </span>
          </div>

          {/* クイック選択ボタン */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 w-full">
            {(() => {
              const buttons = [
                { lot: 0.01, label: '0.01 lot', note: currentLotSize === 0.01 ? '現在の設定' : '最小ロット(安全型)', isRec: false },
                { lot: 0.02, label: '0.02 lot', note: currentLotSize === 0.02 ? '現在の設定' : '収益 2倍', isRec: false },
                { lot: 0.03, label: '0.03 lot', note: currentLotSize === 0.03 ? '現在の設定' : '★ バランス推奨', isRec: currentLotSize <= 0.02 },
                { lot: 0.05, label: '0.05 lot', note: currentLotSize === 0.05 ? '現在の設定' : '収益 5倍 (積極型)', isRec: currentLotSize === 0.03 },
                { lot: 0.10, label: '0.10 lot', note: currentLotSize === 0.10 ? '現在の設定' : '収益 10倍 (高リターン)', isRec: false },
              ];
              if (!buttons.some((b) => b.lot === currentLotSize) && currentLotSize > 0) {
                buttons.push({
                  lot: currentLotSize,
                  label: `${currentLotSize} lot`,
                  note: '現在の設定',
                  isRec: false,
                });
                buttons.sort((a, b) => a.lot - b.lot);
              }
              return buttons.map((item) => {
                const active = simLot === item.lot;
                return (
                  <button
                    key={item.lot}
                    type="button"
                    onClick={() => setSimLot(item.lot)}
                    className={`p-2.5 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                      active
                        ? 'bg-cyan-950/90 border-cyan-400 text-white shadow-lg shadow-cyan-950/60 ring-2 ring-cyan-500/50'
                        : item.isRec
                        ? 'bg-amber-950/40 border-amber-600/70 text-slate-200 hover:bg-amber-950/70'
                        : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className={`text-xs font-black ${active ? 'text-cyan-300' : 'text-slate-100'}`}>
                        {item.label}
                      </span>
                      {item.isRec && (
                        <span className="text-[9px] font-extrabold px-1 py-0.2 rounded bg-amber-500 text-slate-950">
                          推奨
                        </span>
                      )}
                      {item.note === '現在の設定' && !item.isRec && (
                        <span className="text-[9px] font-extrabold px-1 py-0.2 rounded bg-cyan-600 text-white">
                          現在値
                        </span>
                      )}
                    </div>
                    <span className={`text-[10px] mt-1 ${active ? 'text-cyan-200 font-bold' : 'text-slate-400'}`}>
                      {item.note}
                    </span>
                  </button>
                );
              });
            })()}
          </div>

          {/* 試算結果ディスプレイカード */}
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* 期間シミュレーション想定利益 */}
            <div className="p-3 rounded-lg bg-slate-900/90 border border-cyan-900/50 flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-400">{periodText} 想定利益額</span>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold">
                  {simLot} lot
                </span>
              </div>
              <div className="mt-1">
                <span className="text-xl sm:text-2xl font-black text-emerald-400 tracking-tight">
                  +¥{simProfit.toLocaleString()}
                </span>
                {simProfitGain !== 0 && (
                  <span className={`text-xs font-bold ml-1.5 font-mono ${simProfitGain > 0 ? 'text-cyan-300' : 'text-amber-400'}`}>
                    ({simProfitGain > 0 ? '+' : ''}¥{simProfitGain.toLocaleString()})
                  </span>
                )}
              </div>
              <span className="text-[10px] text-slate-400 mt-1">
                {simLot === currentLotSize
                  ? '現在の検証ロット設定と一致'
                  : `現在の設定(${currentLotSize}lot) に対し約 ${lotRatioToCurrent.toFixed(1)}倍`}
              </span>
            </div>

            {/* 期間に応じた換算利益 */}
            <div className="p-3 rounded-lg bg-slate-900/90 border border-amber-900/50 flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-400">
                  {config.testPeriod === '1YEAR'
                    ? '月平均の換算収益'
                    : config.testPeriod === '3MONTHS'
                    ? '1年換算の期待利益'
                    : '年平均の期待利益'}
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-amber-950 text-amber-300 border border-amber-800 font-bold">
                  {config.testPeriod === '1YEAR' ? '月額ペース' : '年間ペース'}
                </span>
              </div>
              <div className="mt-1">
                <span className="text-xl sm:text-2xl font-black text-amber-300 tracking-tight">
                  {config.testPeriod === '1YEAR'
                    ? `約 +¥${monthlyAverageProfit.toLocaleString()} / 月`
                    : `約 +¥${annualProfitEstimate.toLocaleString()}`}
                </span>
              </div>
              <span className="text-[10px] text-slate-400 mt-1">
                年利換算 (ROI): 約 <strong className="text-emerald-400 font-bold">+{annualRoiPercent}%</strong>
              </span>
            </div>

            {/* 推定ドローダウンと安全性 */}
            <div className="p-3 rounded-lg bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-400">推定最大ドローダウン</span>
                <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded border font-bold ${
                  simDd <= 10
                    ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                    : simDd <= 15
                    ? 'bg-cyan-950 text-cyan-300 border-cyan-800'
                    : 'bg-amber-950 text-amber-300 border-amber-800'
                }`}>
                  {simDd <= 10 ? '安全圏内' : simDd <= 15 ? '適正範囲' : '積極リスク'}
                </span>
              </div>
              <div className="mt-1">
                <span className={`text-xl sm:text-2xl font-black tracking-tight ${
                  simDd <= 10 ? 'text-emerald-400' : simDd <= 15 ? 'text-cyan-300' : 'text-amber-400'
                }`}>
                  約 {simDd}%
                </span>
              </div>
              <span className="text-[10px] text-slate-400 mt-1">
                {simDd <= 10
                  ? '目標値(10%)以内で健全に運用可能'
                  : '資金管理を考慮した適正リスク'}
              </span>
            </div>
          </div>
        </div>

        {/* アクションバナー */}
        <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[11px] text-slate-400 leading-tight">
            {!isProUser
              ? '※無料配布版は安全テスト用として「0.01 lot固定・3か月」に制限されています。ロット数の自由調整や1〜5年の本格長期検証は上位PRO版でご利用いただけます。'
              : `※PRO版では設定画面からロット（${simLot} lot）や複利リスク％、長期期間（1〜5年）を自由に選択して再シミュレーションできます。`}
          </p>

          {!isProUser && onOpenUpgradeModal ? (
            <button
              type="button"
              onClick={() => onOpenUpgradeModal('LOT')}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-md shadow-amber-950 transition cursor-pointer shrink-0 self-stretch sm:self-auto"
            >
              <Lock className="w-3.5 h-3.5 fill-slate-950 text-slate-950" />
              <span>上位PRO版でロット変更・長期検証を試す</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-950" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                const el = document.getElementById('section-lot-selection');
                if (el) {
                  el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                } else {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              }}
              className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-md transition cursor-pointer shrink-0 self-stretch sm:self-auto"
            >
              <Sliders className="w-3.5 h-3.5 text-slate-950" />
              <span>推奨設定でパラメータを調整する</span>
            </button>
          )}
        </div>
      </div>

      {/* 2.5. 最小ロット (Minimum Lot) 検証カード */}
      <div
        id="dashboard-minimum-lot-card"
        className="rounded-xl bg-slate-900/90 border border-slate-700/80 p-4 shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
      >
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 mt-0.5">
            <Scale className="w-4 h-4" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-200">{t.backtest.minLotLabel}</span>
              <span className="text-sm font-black text-cyan-300">
                {lotDisplay}
              </span>
              <span className="text-[10px] text-slate-400 bg-slate-800 border border-slate-700 px-1.5 py-0.2 rounded">
                {isProUser ? 'PRO設定適用' : t.backtest.minLotTag}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
              {isProUser
                ? 'PRO版では設定されたロット方式（固定ロットまたは複利リスク％）に基づき、各ポジションの証拠金・損益をリアルタイム計算しています。'
                : t.backtest.minLotDesc}
            </p>
            <p className="text-[11px] text-slate-400">
              {isProUser
                ? '※MQL5/MQL4ソースコード初期パラメータ InpFixedLot / InpRiskPercent に自動同期されます。'
                : t.backtest.minLotNote}
            </p>
          </div>
        </div>

        {onOpenUpgradeModal && !isProUser && (
          <button
            type="button"
            id="btn-upgrade-lot"
            onClick={() => onOpenUpgradeModal('LOT')}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 border border-slate-700 text-cyan-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shrink-0 self-stretch sm:self-auto justify-center"
          >
            <Lock className="w-3 h-3 text-amber-300" />
            <span>{t.backtest.lotUpgradeBtn}</span>
          </button>
        )}
      </div>

      {/* 2.6. 最大同時保有ポジション数 (Maximum Concurrent Positions) カード */}
      <div
        id="dashboard-max-positions-card"
        className="rounded-xl bg-slate-900/90 border border-slate-700/80 p-4 shadow-md space-y-3"
      >
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 mt-0.5">
              <Layers className="w-4 h-4" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold text-slate-200">
                  {isEn ? 'Maximum Concurrent Positions' : '最大同時保有ポジション数 (Maximum Concurrent Positions)'}
                </span>
                <span className="text-sm font-black text-cyan-300">
                  {result.maxConcurrentPositions} {isEn ? 'Positions' : 'ポジション (買い・売り合算)'}
                </span>
                <span className="text-[10px] text-slate-400 bg-slate-800 border border-slate-700 px-2 py-0.5 rounded font-mono">
                  実測ピーク: {result.actualMaxConcurrentPositions} ポジション
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
                {isEn
                  ? 'Concurrency guard limits simultaneous open market orders. Each order is simulated as an independent position with distinct entry time, price, holding duration, and individual P&L.'
                  : '最大同時保有ポジション数は「同時に保有できる上限」であり、利益をポジション数の倍数で計算せず、各注文を独立したポジション（異なるシグナル時刻・エントリー価格・決済時刻・個別損益）として計算しています。'}
              </p>
            </div>
          </div>

          {onOpenUpgradeModal && (
            <button
              type="button"
              id="btn-upgrade-positions"
              onClick={() => onOpenUpgradeModal('MAX_POSITIONS')}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 border border-slate-700 text-cyan-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shrink-0 self-stretch sm:self-auto justify-center"
            >
              <Lock className="w-3 h-3 text-amber-300" />
              <span>{isEn ? 'Configure in Pro' : '上位版で設定可能'}</span>
            </button>
          )}
        </div>

        {/* ユーザー要求：設定上限・実測ピーク・総取引回数・見送りシグナル数・総損益の分離表示グリッド */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-2 border-t border-slate-800 text-xs">
          <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 flex flex-col justify-between">
            <span className="text-[11px] text-slate-400">設定上限:</span>
            <div className="text-sm font-black text-cyan-300 mt-1 font-mono">
              最大 {result.maxConcurrentPositions} ポジション
            </div>
            <span className="text-[9px] text-slate-500 mt-0.5">同時保有の許容上限</span>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 flex flex-col justify-between">
            <span className="text-[11px] text-slate-400">実測ピーク:</span>
            <div className="text-sm font-black text-amber-300 mt-1 font-mono">
              {result.actualMaxConcurrentPositions} ポジション
            </div>
            <span className="text-[9px] text-slate-500 mt-0.5">期間中の最大重なり数</span>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 flex flex-col justify-between">
            <span className="text-[11px] text-slate-400">総取引回数:</span>
            <div className="text-sm font-black text-emerald-300 mt-1 font-mono">
              {result.totalTrades} 回
            </div>
            <span className="text-[9px] text-slate-500 mt-0.5">実際に成立した回数</span>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800 flex flex-col justify-between">
            <span className="text-[11px] text-slate-400">見送りシグナル数:</span>
            <div className="text-sm font-black text-rose-300 mt-1 font-mono">
              {result.skippedSignalsCount || 0} 回
            </div>
            <span className="text-[9px] text-slate-500 mt-0.5">上限超過で見送った回数</span>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/70 border border-cyan-900/40 col-span-2 sm:col-span-1 flex flex-col justify-between">
            <span className="text-[11px] text-cyan-300">総損益:</span>
            <div className="text-sm font-black text-emerald-400 mt-1 font-mono">
              {formatCurrency(result.totalNetProfit)}
            </div>
            <span className="text-[9px] text-slate-400 mt-0.5">個別損益の合算値</span>
          </div>
        </div>

        {/* 資金管理・証拠金計算グリッド */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2 border-t border-slate-800/80 text-xs">
          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
            <span className="text-[11px] text-slate-400">国内25倍 必要証拠金目安:</span>
            <div className="text-sm font-bold text-cyan-300 mt-0.5 font-mono">
              約 {result.requiredMarginEstimate.toLocaleString()} 円
            </div>
            <span className="text-[10px] text-slate-500">
              {lotDisplay} × 最大{result.maxConcurrentPositions}個 (USD/JPY 150円換算)
            </span>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
            <span className="text-[11px] text-slate-400">合算最大ロット数:</span>
            <div className="text-sm font-bold text-white mt-0.5 font-mono">
              {result.maxTotalLot} lot
            </div>
            <span className="text-[10px] text-slate-500">
              {lotDisplay} × 最大{result.maxConcurrentPositions}本
            </span>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
            <span className="text-[11px] text-slate-400">追加エントリー条件:</span>
            <div className="text-[11px] text-slate-300 mt-0.5">
              {result.moneyManagement?.additionalEntryCondition || '未決済保有数が上限未満かつ逆張り乖離発生時'}
            </div>
          </div>
        </div>

        {/* ポジション自動選定 詳細 */}
        {result.aiRecommendationDetails && (
          <div className="p-3 rounded-lg bg-blue-950/30 border border-blue-800/40 text-xs space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-cyan-300">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>ポジション自動選定 算出根拠 ({result.aiRecommendationDetails.recommendedPositions}ポジション)</span>
            </div>
            <div className="text-slate-300 text-[11px] leading-relaxed">
              <strong>選定理由:</strong> {result.aiRecommendationDetails.reason}
            </div>
            <div className="flex flex-wrap items-center gap-3 text-[10px] text-slate-400 pt-0.5 border-t border-blue-900/40">
              <span>適用目標PF: <strong className="text-slate-200">{result.aiRecommendationDetails.appliedPf}</strong></span>
              <span>適用最大DD: <strong className="text-slate-200">{result.aiRecommendationDetails.appliedDd}</strong></span>
              <span>ボラティリティ評価: <strong className="text-slate-200">{result.aiRecommendationDetails.volatilityNote}</strong></span>
            </div>
          </div>
        )}

        {/* 未実装機能の注記 */}
        <div className="p-2.5 rounded-lg bg-slate-850/40 border border-slate-800 flex items-start gap-2 text-[11px] text-slate-400">
          <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-400" />
          <span>{t.config.futureFeaturesNote}</span>
        </div>
      </div>

      {/* 2.8. EA評価指標 (内蔵モデルによる簡易評価・判定の目安) */}
      <div
        id="dashboard-ea-evaluation-metrics"
        className="rounded-xl bg-slate-900/80 border border-slate-800 p-5 space-y-4"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-blue-500/20 text-blue-400 flex items-center justify-center">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                {t.backtest.metricsTitle}
                <span className="text-[10px] font-semibold text-cyan-300 bg-cyan-950/80 border border-cyan-700/60 px-2 py-0.5 rounded">
                  {t.backtest.metricsTag}
                </span>
              </h4>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-400">
              {t.backtest.metricsSubTitle}
            </span>
            {onOpenUpgradeModal && (
              <button
                type="button"
                id="btn-upgrade-curve-fit"
                onClick={() => onOpenUpgradeModal('CURVE_FIT')}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
              >
                {t.backtest.curveFitUpgradeHint}
              </button>
            )}
          </div>
        </div>

        {/* Evaluation Metrics Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* 1. 期待利得 */}
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.expectedPayoff}</div>
            <div className="text-base font-bold text-emerald-400 mt-1">
              +{isEn ? '¥' : ''}{(result.evaluationMetrics?.expectedPayoff || Math.round(result.totalNetProfit / Math.max(1, result.totalTrades))).toLocaleString()}{isEn ? ' JPY' : '円'}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.expectedPayoffNote}
            </div>
          </div>

          {/* 2. 損益比 (ペイオフレシオ) */}
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.profitLossRatio}</div>
            <div className="text-base font-bold text-cyan-300 mt-1">
              1 : {result.evaluationMetrics?.profitLossRatio || result.riskRewardRatio}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.profitLossRatioNote}
            </div>
          </div>

          {/* 3. 最大連勝数 */}
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.maxConsecutiveWins}</div>
            <div className="text-base font-bold text-white mt-1">
              {result.evaluationMetrics?.maxConsecutiveWins || 3} {isEn ? 'Wins' : '連勝'}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.maxConsecutiveWinsNote}
            </div>
          </div>

          {/* 4. 最大連敗数 */}
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.maxConsecutiveLosses}</div>
            <div className="text-base font-bold text-amber-300 mt-1">
              {result.evaluationMetrics?.maxConsecutiveLosses || 2} {isEn ? 'Losses' : '連敗'}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.maxConsecutiveLossesNote}
            </div>
          </div>

          {/* 5. 推定週間取引頻度 */}
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.estTradesPerWeek}</div>
            <div className="text-base font-bold text-cyan-300 mt-1">
              {isEn ? `~${result.tradesPerWeek} / wk` : `約 ${result.tradesPerWeek} 回/週`}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.estTradesPerWeekNote}
            </div>
          </div>

          {/* 6. リカバリーファクター */}
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.recoveryFactor}</div>
            <div className="text-base font-bold text-cyan-300 mt-1">
              {result.evaluationMetrics?.recoveryFactor || Number((result.totalNetProfit / Math.max(1, result.maxDrawdownAmount)).toFixed(2))}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.recoveryFactorNote}
            </div>
          </div>
        </div>

        {/* Disclaimer Note according to user instructions */}
        <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800 text-[11px] text-slate-400 leading-relaxed flex items-start gap-2">
          <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-slate-300">
              {t.backtest.disclaimerTitle}
            </span>{' '}
            {t.backtest.disclaimerText}
          </div>
        </div>
      </div>

      {/* 3. EA評価指標の下に直接配置: 詳細サマリー、資産曲線チャート、取引履歴ログ */}
      <div className="space-y-6 pt-2">
        {/* 詳細メトリクス 4カード */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.winRateTrades}</div>
            <div className="text-base font-bold text-white mt-1">
              {result.winRate}%
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {isEn
                ? `${result.winningTrades}W / ${result.losingTrades}L`
                : `${result.winningTrades}勝 ${result.losingTrades}敗`}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.weeklyTrades}</div>
            <div className="text-base font-bold text-cyan-300 mt-1">
              {isEn ? `~${result.tradesPerWeek} / wk` : `約 ${result.tradesPerWeek} 回 / 週`}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.weeklyTradesNote}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.avgProfitLoss}</div>
            <div className="text-base font-bold text-white mt-1">
              {formatCurrency(result.averageProfit)} / {formatCurrency(-result.averageLoss)}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {isEn ? `Risk/Reward 1 : ${result.riskRewardRatio}` : `リスクリワード比 1 : ${result.riskRewardRatio}`}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.sharpeRatio}</div>
            <div className="text-base font-bold text-cyan-300 mt-1">
              {result.sharpeRatio}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.sharpeRatioNote}
            </div>
          </div>
        </div>

        {/* 取引履歴ログ */}
        <div id="section-trade-logs" className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 sm:p-5 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
            <h4 className="text-xs font-bold text-slate-200 flex items-center gap-2 flex-wrap">
              <span>{isEn ? `Trade History Log (${result.trades.length} trades)` : `取引履歴ログ一覧 (全${result.trades.length}件)`}</span>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-700/80">
                検証通貨ペア: {pairDisplayName}
              </span>
            </h4>

            {/* Filter Buttons */}
            <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
              {(['ALL', 'BUY', 'SELL', 'WINS', 'LOSSES'] as const).map((filter) => (
                <button
                  key={filter}
                  type="button"
                  onClick={() => setTradeFilter(filter)}
                  className={`px-2.5 py-1 rounded-lg transition cursor-pointer text-xs ${
                    tradeFilter === filter
                      ? 'bg-slate-800 text-cyan-300 font-bold border border-slate-700'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          <div className="max-h-72 overflow-y-auto overflow-x-auto rounded-xl border border-slate-800 bg-slate-950/40 text-xs w-full max-w-full">
            <table className="w-full text-left min-w-[500px]">
              <thead className="sticky top-0 bg-slate-900 text-slate-400 text-[10px] uppercase border-b border-slate-800">
                <tr>
                  <th className="p-2">#</th>
                  <th className="p-2">{t.backtest.colDateTime}</th>
                  <th className="p-2">{t.backtest.colType}</th>
                  <th className="p-2">Lot</th>
                  <th className="p-2">{t.backtest.colPips}</th>
                  <th className="p-2 text-right">{t.backtest.colAmount}</th>
                  <th className="p-2">{t.backtest.colReason}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850">
                {filteredTrades.slice(0, 50).map((t) => (
                  <tr key={t.id} className="hover:bg-slate-850/50">
                    <td className="p-2 text-slate-500">{t.id}</td>
                    <td className="p-2 text-slate-400">{t.openTime}</td>
                    <td className="p-2">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          t.type === 'BUY'
                            ? 'bg-blue-950 text-blue-300'
                            : 'bg-amber-950 text-amber-300'
                        }`}
                      >
                        {t.type}
                      </span>
                    </td>
                    <td className="p-2 text-slate-300">{t.lots}</td>
                    <td
                      className={`p-2 font-medium ${
                        t.profitPips >= 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {t.profitPips > 0 ? `+${t.profitPips}` : t.profitPips}
                    </td>
                    <td
                      className={`p-2 text-right font-semibold ${
                        t.profitAmount >= 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {formatCurrency(t.profitAmount)}
                    </td>
                    <td className="p-2 text-slate-400 text-[10px]">{t.reason}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* ============================================================ */}
        {/* 5. 検証ステップ（ユーザー要求：小さく、補助情報として下部に折りたたみ表示） */}
        {/* ============================================================ */}
        <div
          id="section-verification-steps-collapsible"
          className="rounded-xl bg-slate-950/40 border border-slate-800/80 overflow-hidden text-xs"
        >
          <button
            type="button"
            onClick={() => setShowVerificationSteps((prev) => !prev)}
            className="w-full flex items-center justify-between p-3.5 bg-slate-900/60 hover:bg-slate-850 transition text-slate-400 hover:text-slate-200 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Search className="w-3.5 h-3.5 text-cyan-400" />
              <span className="font-semibold text-slate-300 text-xs">
                {isEn ? 'View Verification Process (7 Steps)' : '検証プロセスを表示（全7ステップ検証ログ）'}
              </span>
              <span className="text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
                全項目パス完了
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-500">
              <span>{showVerificationSteps ? (isEn ? 'Close' : '折りたたむ') : (isEn ? 'Expand' : '展開')}</span>
              {showVerificationSteps ? (
                <ChevronUp className="w-4 h-4" />
              ) : (
                <ChevronDown className="w-4 h-4" />
              )}
            </div>
          </button>

          {showVerificationSteps && (
            <div className="p-4 bg-slate-950/80 border-t border-slate-850 space-y-3 animate-in fade-in duration-200">
              <p className="text-[11px] text-slate-400">
                {isEn
                  ? 'Audit records of the automated verification pipeline conducted prior to EA compilation.'
                  : 'EA生成直前に実行された自動検証パイプラインの確認ログです。資産曲線と主要結果の整合性を担保しています。'}
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                {[
                  { step: 'Step 1', title: '入力条件を確認中', detail: `${pairDisplayName} / ${config.timeframe || 'M30'} / ${periodText}・${maxPosDisplay}確認` },
                  { step: 'Step 2', title: '候補ロジックを評価中', detail: '過剰最適化（カーブフィッティング）排除＆ウォークフォワード判定' },
                  { step: 'Step 3', title: '資産曲線を生成中', detail: `${periodText}約定ログから確定損益/含み損益曲線を算出` },
                  { step: 'Step 4', title: 'PFを確認中', detail: `確定PF: ${result.profitFactor} (目標 ${config.desiredPf || '1.2+'} 達成)` },
                  { step: 'Step 5', title: '最大DDを確認中', detail: `最大DD: ${result.maxDrawdownPercent}% (目標 ${config.maxDrawdown || '10%'} 達成)` },
                  { step: 'Step 6', title: '結果の整合性を確認中', detail: '見送りシグナル・取引回数・保有上限ブロック整合性検証' },
                  { step: 'Step 7', title: 'EA生成結果を整理中', detail: 'MQL4/MQL5コードおよび体験版パッケージ整形完了' },
                ].map((s, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 flex items-start gap-2.5"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] text-slate-500 font-mono">{s.step}</span>
                        <span className="text-xs font-bold text-slate-200">{s.title}</span>
                      </div>
                      <p className="text-[10px] text-slate-400">{s.detail}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

