/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Share2, Copy, Check, Globe, QrCode, ExternalLink, Sparkles, CheckCircle2, ShieldCheck, X } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose }) => {
  const { language } = useLanguage();
  const isEn = language === 'en';

  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedPromo, setCopiedPromo] = useState(false);

  if (!isOpen) return null;

  // 体験版案内用URL（現在のホストまたはAI Studioの公開URL）
  const shareUrl = typeof window !== 'undefined' ? window.location.href : 'https://ais-pre-h2jxkmssycmxlztngejdte-914604712544.asia-east1.run.app';

  // 告知・案内用テンプレート文
  const promoTextJa = `【完全無料・ブラウザ完結】簡単EA作成ツール EA Maker Zero（無料体験版・初期資金10万円スタート）
MT5の面倒な環境構築やストラテジーテスター不要！ブラウザ上で瞬時に高精度バックテスト・堅牢EA（MQL4/MQL5）を自動生成できます。
過剰最適化を排除したスイングロジック＆1,000回以上の内部照合検証済み！

▼ 無料体験版のお試しはこちらから
${shareUrl}
#FX自動売買 #EA #メタトレーダー #MQL5 #投資 #FX`;

  const promoTextEn = `[100% Free] EA Maker Zero - Easy EA Generator (Free Trial - ¥100k Starting Capital)
No MT5 complex setup required! Generate robust trading robots (MQL4/MQL5) with institutional multi-timeframe logic and instant browser backtesting.

Try the Free Trial here:
${shareUrl}
#Forex #TradingRobot #MQL5 #AlgorithmicTrading`;

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2500);
    } catch {
      // fallback
    }
  };

  const handleCopyPromo = async () => {
    try {
      await navigator.clipboard.writeText(isEn ? promoTextEn : promoTextJa);
      setCopiedPromo(true);
      setTimeout(() => setCopiedPromo(false), 2500);
    } catch {
      // fallback
    }
  };

  return (
    <div
      id="share-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="share-modal-container"
        className="relative w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4.5 bg-gradient-to-r from-slate-900 via-cyan-950/40 to-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shadow-md">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                {isEn ? 'Share Free Trial Edition' : '無料体験版の共有・案内URL'}
                <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
                  {isEn ? 'Trial Ready' : '無料体験対応'}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                {isEn
                  ? 'Easily share this free trial EA generator tool with your users, followers, or community'
                  : 'SNSやメルマガ、ブログ、公式LINE等で無料体験版ツールを案内・共有できます'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-sm max-h-[80vh] overflow-y-auto">
          {/* 1. 無料体験版URLコピー欄 */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-200 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-cyan-400" />
                {isEn ? 'Direct Web App URL' : '無料体験版の直接アクセスURL'}
              </span>
              <span className="text-[10px] text-cyan-400 font-mono">
                {isEn ? 'Share via SNS, LINE, Blog' : 'SNS・公式LINE・ブログ等で案内可能'}
              </span>
            </label>
            <div className="flex items-center gap-2">
              <div className="flex-1 bg-slate-950/90 border border-slate-700/80 rounded-xl px-3 py-2 text-xs font-mono text-cyan-200 select-all truncate shadow-inner">
                {shareUrl}
              </div>
              <button
                type="button"
                onClick={handleCopyUrl}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 text-xs font-bold transition shadow-md shadow-cyan-950/50 shrink-0 cursor-pointer"
              >
                {copiedUrl ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>{isEn ? 'Copied!' : 'コピー完了'}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>{isEn ? 'Copy URL' : 'URLをコピー'}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Googleログイン要求・アクセス権限についての注意と対策 */}
          <div className="p-3.5 rounded-xl bg-amber-950/40 border border-amber-500/50 text-xs space-y-2">
            <div className="flex items-center gap-2 text-amber-300 font-bold">
              <ExternalLink className="w-4 h-4 text-amber-400 shrink-0" />
              <span>【重要】「Googleログインを求められて開けない」場合の解決手順</span>
            </div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              現在AI Studioプレビュー環境（Cloud Run）の保護設定により、リンク先を一般公開（誰でもアクセス可能）にするには
              <strong>画面右上の「Share（共有）」または「Deploy / Publish」設定</strong>を確認する必要があります。
            </p>
            <div className="bg-slate-900/90 p-2.5 rounded-lg border border-slate-800 text-[11px] text-slate-300 space-y-1">
              <div className="text-amber-200 font-semibold">▼ 一般ユーザーにログインなしで見せる方法：</div>
              <ol className="list-decimal list-inside space-y-0.5 text-slate-400">
                <li>AI Studio画面右上にある<strong>「Share」ボタン</strong>をクリック</li>
                <li>Access設定を<strong>「Anyone with the link（リンクを知っている全員）」</strong>に変更</li>
                <li>または<strong>GitHub連携・Vercel / Cloudflare Pages / Render</strong>等へ1クリック無料デプロイすると、誰でもログイン不要で完全公開されます</li>
              </ol>
            </div>
          </div>

          {/* 2. おすすめの案内・集客方法ガイド */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-4 space-y-3">
            <div className="text-xs font-bold text-slate-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>{isEn ? 'Recommended Trial Sharing Methods' : '無料体験版のおすすめ案内・活用方法'}</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800/80 space-y-1">
                <span className="font-bold text-cyan-300 block">① X (Twitter)・SNS投稿</span>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  「資金10万円スタート・初期設定不要で試せる無料体験版EA作成ツール」としてURLを記載して紹介。
                </p>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800/80 space-y-1">
                <span className="font-bold text-emerald-300 block">② 公式LINE / メルマガ登録特典</span>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  無料登録特典としてこの無料体験版ツールURLを案内し、その後Pro版（製品版）への案内へと繋げるステップ配信に最適。
                </p>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800/80 space-y-1">
                <span className="font-bold text-amber-300 block">③ ブログ・Noteでの埋め込み/紹介</span>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  「MT5なしで即座に検証できるEAジェネレーター」としてレビュー記事を執筆し、リンクを配置。
                </p>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800/80 space-y-1">
                <span className="font-bold text-purple-300 block">④ GogoJungle等の商品説明欄</span>
                <p className="text-slate-400 text-[11px] leading-relaxed">
                  「まずは無料体験版でストラテジーの挙動をお試しいただけます」と購入検討者向け体験デモとして案内。
                </p>
              </div>
            </div>
          </div>

          {/* 3. ワンクリックで使える案内告知文テンプレート */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-200">
                {isEn ? 'Social Post / Promotion Text Template' : 'コピペで使える体験版案内文テンプレート'}
              </label>
              <button
                type="button"
                onClick={handleCopyPromo}
                className="flex items-center gap-1 text-[11px] font-bold text-cyan-400 hover:text-cyan-300 transition cursor-pointer"
              >
                {copiedPromo ? (
                  <>
                    <Check className="w-3 h-3" />
                    <span>{isEn ? 'Copied' : 'コピーしました'}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>{isEn ? 'Copy Promo Text' : '告知文をコピー'}</span>
                  </>
                )}
              </button>
            </div>
            <div className="p-3 bg-slate-950/90 border border-slate-800 rounded-xl text-[11px] font-mono text-slate-300 leading-relaxed max-h-32 overflow-y-auto whitespace-pre-wrap select-all">
              {isEn ? promoTextEn : promoTextJa}
            </div>
          </div>

          {/* 無料版の仕様メモ */}
          <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-800/40 text-[11px] text-cyan-200/90 flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <p className="font-bold text-cyan-300">
                {isEn ? 'Free Edition Current Setting:' : '現在の無料版の設定:'}
              </p>
              <p className="text-cyan-400/90">
                {isEn
                  ? 'Base Capital: ¥100,000 JPY | Test Period: 3 Months | Minimum Lot: 0.01 lot | 1 Position Only'
                  : '基準資金: 100,000円（10万円） | 検証期間: 3か月 | 最小ロット: 0.01 lot | 1ポジション固定'}
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-950/90 border-t border-slate-800 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition cursor-pointer"
          >
            {isEn ? 'Close' : '閉じる'}
          </button>
        </div>
      </div>
    </div>
  );
};
