/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Sparkles,
  Lock,
  Check,
  ArrowRight,
  X,
  ShieldCheck,
  Zap,
  Layers,
  Coins,
  CalendarCheck,
  Key,
  CreditCard,
  Clock,
  Crown,
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { LicenseInfo } from '../types';

export type UpgradeTrigger =
  | 'PAIR'
  | 'PF'
  | 'DD'
  | 'PERIOD'
  | 'CAPITAL'
  | 'LOT'
  | 'MAX_POSITIONS'
  | 'CURVE_FIT'
  | 'CODE'
  | 'SPEED'
  | 'GENERAL';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  trigger?: UpgradeTrigger;
  onOpenLicenseModal?: () => void;
  onActivateLicense?: (license: LicenseInfo) => void;
}

export const UpgradeModal: React.FC<UpgradeModalProps> = ({
  isOpen,
  onClose,
  trigger = 'GENERAL',
  onOpenLicenseModal,
  onActivateLicense,
}) => {
  const { language, t } = useLanguage();
  const isEn = language === 'en';

  const [selectedPlan, setSelectedPlan] = useState<'lifetime' | 'subscription'>('lifetime');
  const [buyerEmail, setBuyerEmail] = useState('');
  const [isProcessingStripe, setIsProcessingStripe] = useState(false);
  const [stripeSuccessNote, setStripeSuccessNote] = useState<string | null>(null);
  const [issuedLicense, setIssuedLicense] = useState<LicenseInfo | null>(null);

  if (!isOpen) return null;

  // Specific guidance text and CTA based on trigger
  let title = t.upgradeModal.title;
  let bannerMessage = t.upgradeModal.bannerDefault;
  let ctaText = t.upgradeModal.ctaDefault;

  if (trigger === 'PAIR') {
    title = t.upgradeModal.triggerPairTitle;
    bannerMessage = t.upgradeModal.triggerPairMsg;
    ctaText = t.upgradeModal.ctaDefault;
  } else if (trigger === 'PF') {
    title = t.upgradeModal.triggerPfTitle;
    bannerMessage = t.upgradeModal.triggerPfMsg;
    ctaText = isEn ? 'Unlock Higher PF Conditions' : 'PF条件を拡張する';
  } else if (trigger === 'DD') {
    title = t.upgradeModal.triggerDdTitle;
    bannerMessage = t.upgradeModal.triggerDdMsg;
    ctaText = isEn ? 'Unlock Lower Drawdown Conditions' : 'より低リスクな条件を開放';
  } else if (trigger === 'PERIOD') {
    title = t.upgradeModal.triggerPeriodTitle;
    bannerMessage = t.upgradeModal.triggerPeriodMsg;
    ctaText = isEn ? 'Unlock Multi-Year Walk-Forward' : '長期検証機能を開放する';
  } else if (trigger === 'CAPITAL') {
    title = t.upgradeModal.triggerCapitalTitle;
    bannerMessage = t.upgradeModal.triggerCapitalMsg;
    ctaText = isEn ? 'Customize Account Margin' : '資金設定をカスタマイズする';
  } else if (trigger === 'LOT') {
    title = t.upgradeModal.triggerLotTitle;
    bannerMessage = t.upgradeModal.triggerLotMsg;
    ctaText = isEn ? 'Unlock Custom Lot & Compounding' : 'ロット設定を拡張する';
  } else if (trigger === 'MAX_POSITIONS') {
    title = t.upgradeModal.triggerMaxPositionsTitle;
    bannerMessage = t.upgradeModal.triggerMaxPositionsMsg;
    ctaText = t.upgradeModal.triggerMaxPositionsCta;
  } else if (trigger === 'CURVE_FIT') {
    title = t.upgradeModal.triggerCurveFitTitle;
    bannerMessage = t.upgradeModal.triggerCurveFitMsg;
    ctaText = isEn ? 'Unlock Curve Fitting Diagnostics' : 'カーブフィッティング検証を開放';
  } else if (trigger === 'CODE') {
    title = t.upgradeModal.triggerCodeTitle;
    bannerMessage = t.upgradeModal.triggerCodeMsg;
    ctaText = t.upgradeModal.triggerCodeCta;
  } else if (trigger === 'SPEED') {
    title = t.upgradeModal.triggerSpeedTitle;
    bannerMessage = t.upgradeModal.triggerSpeedMsg;
    ctaText = t.upgradeModal.triggerSpeedCta;
  }

  const proFeatures = [
    {
      icon: Clock,
      title: isEn ? 'Multi-Dimensional Deep Verification' : '多次元深層検証エンジン（ディープテスト）',
      desc: isEn
        ? 'Unlike the simplified test in free edition, PRO runs comprehensive walk-forward testing with 1-5 years tick data and intertwined multi-layer logic to eliminate curve-fitting.'
        : '無料版の簡易条件確認とは異なり、1〜5年の全ティックデータ・多通貨・複雑に絡み合う複数ロジックの動的相互作用を深層解析するため、十分な検証時間をかけて本物のプロ仕様EAを構築します。',
    },
    {
      icon: Layers,
      title: t.upgradeModal.feature1Title,
      desc: t.upgradeModal.feature1Desc,
    },
    {
      icon: Zap,
      title: t.upgradeModal.feature2Title,
      desc: t.upgradeModal.feature2Desc,
    },
    {
      icon: ShieldCheck,
      title: t.upgradeModal.feature3Title,
      desc: t.upgradeModal.feature3Desc,
    },
    {
      icon: CalendarCheck,
      title: t.upgradeModal.feature4Title,
      desc: t.upgradeModal.feature4Desc,
    },
    {
      icon: Coins,
      title: t.upgradeModal.feature5Title,
      desc: t.upgradeModal.feature5Desc,
    },
    {
      icon: Sparkles,
      title: t.upgradeModal.feature6Title,
      desc: t.upgradeModal.feature6Desc,
    },
  ];

  const handleStripeCheckout = async () => {
    setIsProcessingStripe(true);
    setStripeSuccessNote(null);

    try {
      const res = await fetch('/api/stripe/create-checkout-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planType: selectedPlan,
          email: buyerEmail || 'buyer@example.com',
        }),
      });

      const data = await res.json();
      if (data.success) {
        if (data.mode === 'simulation' && data.license) {
          const lic: LicenseInfo = {
            isPro: true,
            email: data.license.email,
            code: data.license.code,
            type: data.license.type,
            expiresAt: data.license.expiresAt,
            activatedAt: new Date().toISOString(),
          };
          setIssuedLicense(lic);
          setStripeSuccessNote(
            `【決済完了シミュレーション】認証コード「${data.license.code}」が発行されました！下の「今すぐPRO版を有効化する」ボタンを押すと、即座にEAソースコード出力を含む全機能が開放されます。`
          );
        } else if (data.checkoutUrl) {
          window.location.href = data.checkoutUrl;
        }
      }
    } catch (err) {
      console.error('Stripe checkout error:', err);
    } finally {
      setIsProcessingStripe(false);
    }
  };

  return (
    <div
      id="upgrade-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="upgrade-modal-container"
        className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-slate-900 via-blue-950/50 to-slate-900 border-b border-slate-800 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold tracking-wider px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 uppercase">
                  {t.upgradeModal.badge}
                </span>
                <span className="text-xs text-slate-400">{t.upgradeModal.exclusive}</span>
              </div>
              <h3 className="text-base font-bold text-white mt-0.5">{title}</h3>
            </div>
          </div>
          <button
            id="upgrade-modal-close-button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition cursor-pointer"
            aria-label={t.upgradeModal.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Specific Banner */}
          <div className="p-4 rounded-xl bg-blue-950/50 border border-blue-500/40 flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-300 flex items-center justify-center shrink-0 mt-0.5">
              <Lock className="w-3.5 h-3.5" />
            </div>
            <div>
              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-medium">
                {bannerMessage}
              </p>
            </div>
          </div>

          {/* プラン選択（買い切り vs 月額サブスクリプション） */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-cyan-400" />
                <span>Stripe決済プランの選択</span>
              </h4>
              <span className="text-[10px] text-slate-400">※決済後に登録メール宛へ認証コードが即時送付されます</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* 買い切り永久プラン */}
              <div
                onClick={() => setSelectedPlan('lifetime')}
                className={`p-4 rounded-xl border transition cursor-pointer flex flex-col justify-between ${
                  selectedPlan === 'lifetime'
                    ? 'bg-gradient-to-br from-cyan-950/70 via-slate-900 to-blue-950/70 border-cyan-500 shadow-md shadow-cyan-950/50'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-cyan-300">買い切り永久ライセンス</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                      一番人気
                    </span>
                  </div>
                  <div className="text-lg font-black text-white mt-1">一括払い</div>
                  <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                    一度の購入で無期限にPRO機能を利用可能。全通貨ペア、長期検証、コード出力などを永久に開放。
                  </p>
                </div>
                <div className="mt-3 pt-2.5 border-t border-slate-800/80 text-[10px] text-emerald-400 font-medium flex items-center gap-1">
                  <Check className="w-3 h-3 shrink-0" />
                  <span>生涯アップデート対応・追加料金なし</span>
                </div>
              </div>

              {/* 月額サブスクリプション */}
              <div
                onClick={() => setSelectedPlan('subscription')}
                className={`p-4 rounded-xl border transition cursor-pointer flex flex-col justify-between ${
                  selectedPlan === 'subscription'
                    ? 'bg-gradient-to-br from-emerald-950/70 via-slate-900 to-blue-950/70 border-emerald-500 shadow-md shadow-emerald-950/50'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-300">月額サブスクリプション</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                      初期費用を抑える
                    </span>
                  </div>
                  <div className="text-lg font-black text-white mt-1">月額課金</div>
                  <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                    必要な期間だけ気軽にPRO機能を利用可能。いつでも解約可能・最新アルゴリズム随時配信。
                  </p>
                </div>
                <div className="mt-3 pt-2.5 border-t border-slate-800/80 text-[10px] text-emerald-400 font-medium flex items-center gap-1">
                  <Check className="w-3 h-3 shrink-0" />
                  <span>いつでも解約・再開可能</span>
                </div>
              </div>
            </div>

            {/* 決済成功シミュレーションメッセージ */}
            {stripeSuccessNote && (
              <div className="p-3.5 rounded-xl bg-emerald-950/70 border border-emerald-500/60 text-xs text-emerald-200 leading-relaxed shadow-sm space-y-2.5">
                <div>{stripeSuccessNote}</div>
                {issuedLicense && onActivateLicense && (
                  <button
                    type="button"
                    onClick={() => {
                      onActivateLicense(issuedLicense);
                      onClose();
                    }}
                    className="w-full py-2 px-3 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-md"
                  >
                    <Crown className="w-4 h-4 fill-slate-950" />
                    <span>今すぐPRO版を有効化してEAソースコードを出力する</span>
                  </button>
                )}
              </div>
            )}

            {/* 即座にPRO版を動作確認できるクイック開放ボタン */}
            {onActivateLicense && (
              <div className="p-3 rounded-xl bg-slate-950/80 border border-amber-500/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5 text-xs">
                <div className="space-y-0.5">
                  <div className="font-bold text-amber-300 flex items-center gap-1">
                    <Crown className="w-3.5 h-3.5 text-amber-400" />
                    <span>【テスト用】ワンクリック即時PRO版有効化</span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    決済前でもEAソースコード出力を含むすべてのPRO機能を即座にお試しいただけます。
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onActivateLicense({
                      isPro: true,
                      type: 'lifetime',
                      code: 'PRO-LIFE-7777-8888',
                      email: 'pro-user@example.com',
                      activatedAt: new Date().toISOString(),
                    });
                    onClose();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs shrink-0 transition cursor-pointer shadow-md flex items-center gap-1"
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>PRO版を即座に開放</span>
                </button>
              </div>
            )}
          </div>

          {/* Comparison / Pro Features Grid */}
          <div>
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.upgradeModal.featuresHeader}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {proFeatures.map((item, idx) => {
                const IconComponent = item.icon;
                return (
                  <div
                    key={idx}
                    className="p-3 rounded-lg bg-slate-800/60 border border-slate-700/60 flex items-start gap-2.5"
                  >
                    <div className="w-7 h-7 rounded-md bg-cyan-500/10 border border-cyan-500/25 flex items-center justify-center text-cyan-400 shrink-0">
                      <IconComponent className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-slate-200">
                        {item.title}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                        {item.desc}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 検証時間の違いに関する明確な注記 */}
          <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/40 text-xs text-slate-300 space-y-1.5">
            <div className="flex items-center gap-1.5 text-slate-200 font-bold">
              <Clock className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>検証時間と品質保証の違いについて（無料版 vs PRO版）</span>
            </div>
            <p className="text-[11px] pl-5.5 text-slate-400 leading-relaxed">
              無料版は条件確認用の簡易シミュレーション（EURUSD・3か月・約5分）を実施します。<br />
              上位PRO版は、1〜5年の全ティックデータ、多通貨ペア、複雑に絡み合う複数ロジックの動的相互作用を深層解析するため、十分な検証時間をかけてカーブフィッティングを徹底排除した本物のプロ仕様EAを構築します。
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-900 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* すでに認証コードをお持ちの方用リンク */}
          <button
            type="button"
            onClick={() => {
              onClose();
              if (onOpenLicenseModal) onOpenLicenseModal();
            }}
            className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-750 text-cyan-300 border border-slate-700 hover:border-cyan-500/50 text-xs font-bold transition cursor-pointer"
          >
            <Key className="w-3.5 h-3.5" />
            <span>すでに購入済みの方（認証コード入力）</span>
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              id="upgrade-modal-dismiss-button"
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition cursor-pointer"
            >
              {t.upgradeModal.continueFree}
            </button>
            <button
              id="upgrade-modal-cta-button"
              onClick={handleStripeCheckout}
              disabled={isProcessingStripe}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-500 hover:from-blue-500 hover:to-cyan-400 text-white text-xs font-bold shadow-lg shadow-cyan-900/40 transition cursor-pointer disabled:opacity-50"
            >
              {isProcessingStripe ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Stripe処理中...</span>
                </>
              ) : (
                <>
                  <span>Stripe決済で購入（認証コード発行）</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

