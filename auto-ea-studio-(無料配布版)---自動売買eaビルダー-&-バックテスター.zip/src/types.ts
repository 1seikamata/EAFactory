/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Language = 'ja' | 'en';

export type CurrencyPair = 'USDJPY' | 'EURUSD' | 'GBPJPY' | 'EURJPY' | 'XAUUSD' | 'AUTO';
export type Timeframe = 'M5' | 'M15' | 'M30' | 'H1' | 'H4' | 'D1' | 'AUTO';
export type ProfitFactorGoal = '1.2+' | '1.5+' | '1.8+' | '2.0+' | 'AUTO';
export type MaxDrawdownLimit = '3%' | '5%' | '10%' | 'AUTO';
export type TradeFrequency =
  | 'MONTHLY_2_4'
  | 'WEEKLY_1_2'
  | 'WEEKLY_2_3'
  | 'WEEKLY_1_3'
  | 'WEEKLY_3_5'
  | 'DAILY_1_2'
  | 'DAILY_1'
  | 'DAILY_3_5'
  | 'DAILY_2_3'
  | 'NO_SPEC'
  | 'AI_RECOMMENDED'
  | 'AUTO';

export type MaxPositions = '1' | 'LE_5' | 'LE_10' | 'LE_20' | 'GE_20' | 'AUTO';

export type StrategyPreset =
  | 'GOGOJUNGLE_TREND'
  | 'YOUTUBE_MTF_BREAK'
  | 'VOLATILITY_EXPANSION'
  | 'SESSION_MEAN_REVERSION'
  | 'LONDON_BREAKOUT'
  | 'AUTO';

export interface BuyerConfig {
  pair: CurrencyPair;
  timeframe: Timeframe;
  desiredPf: ProfitFactorGoal;
  maxDrawdown: MaxDrawdownLimit;
  frequency: TradeFrequency;
  strategyPreset: StrategyPreset;
  maxPositions?: MaxPositions;
  customNotes?: string;
  testPeriod?: '3MONTHS' | '1YEAR' | '3YEARS' | '5YEARS';
  capitalAmount?: number;
  lotType?: 'FIXED' | 'COMPOUND';
  lotSize?: number;
  riskPercent?: number;
}

export interface TradeRecord {
  id: number;
  openTime: string;
  closeTime: string;
  type: 'BUY' | 'SELL';
  openPrice: number;
  closePrice: number;
  lots: number;
  profitPips: number;
  profitAmount: number;
  balanceAfter: number;
  concurrentPositionsAtOpen?: number;
  reason: 'TP' | 'SL' | 'TRAILING' | 'SIGNAL_CLOSE';
}

export interface MonthlyPerformance {
  yearMonth: string;
  profitAmount: number;
  profitPercent: number;
  tradeCount: number;
  winRate: number;
}

export interface BacktestResult {
  initialBalance: number;
  finalBalance: number;
  totalNetProfit: number;
  netProfitPercent: number;
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  profitFactor: number;
  maxDrawdownPercent: number;
  maxDrawdownAmount: number;
  tradesPerWeek: number;
  averageProfit: number;
  averageLoss: number;
  riskRewardRatio: number;
  sharpeRatio: number;
  periodDays: number;
  periodLabel: string;
  startDate?: string;
  endDate?: string;
  baseCapital: number;
  minimumLot: number;
  pair: CurrencyPair; // 実際に検証された通貨ペア
  pairDisplayName: string; // 表示用通貨ペア名 (例: EUR/USD (ユーロドル))
  autoPairSelectionReason?: string; // お任せ自動選定の理由
  // 最大同時保有ポジション数 & 証拠金指標
  maxConcurrentPositions: number;
  actualMaxConcurrentPositions: number;
  skippedSignalsCount: number; // 上限到達により見送られたシグナル数
  totalSignalsCount: number; // 期間中に検知された市場シグナル総数
  requiredMarginEstimate: number; // 必要証拠金の目安 (円)
  maxTotalLot: number; // 最大合算ロット
  // 高度な資金管理条件
  moneyManagement: {
    maxConcurrentPositions: number;
    lotPerTrade: number;
    maxTotalLot: number;
    requiredMarginEstimate: number;
    additionalEntryCondition: string; // 追加エントリー条件
    forceStopCondition: string; // 強制停止条件
  };
  // AI推奨詳細 (AI推奨選択時のみ)
  aiRecommendationDetails?: {
    recommendedPositions: number;
    reason: string;
    appliedPf: string;
    appliedDd: string;
    volatilityNote: string;
  };
  // EA評価指標 (内蔵モデルによる簡易評価・参考指標)
  evaluationMetrics: {
    expectedPayoff: number; // 期待利得 (1トレードあたりの平均損益・円) [内蔵モデル参考値]
    profitLossRatio: number; // 損益比 (平均利益/平均損失) [内蔵モデル参考値]
    maxConsecutiveWins: number; // 最大連勝数 (簡易評価)
    maxConsecutiveLosses: number; // 最大連敗数 (簡易評価)
    tradeFrequencyWeekly: number; // 推定週間取引回数 (目安)
    recoveryFactor: number; // リカバリーファクター (純利益 / 最大DD額) [参考評価]
  };
  equityCurve: { time: string; balance: number; equity: number; drawdown: number }[];
  monthlyData: MonthlyPerformance[];
  trades: TradeRecord[];
}

export interface CodeSafetyCheck {
  id: string;
  name: string;
  passed: boolean;
  description: string;
  codeSnippet: string;
}

export interface EASpec {
  name: string;
  version: string;
  author: string;
  targetPair: string;
  targetTimeframe: string;
  conceptSummary: string;
  parameters: {
    name: string;
    type: string;
    defaultValue: string | number | boolean;
    description: string;
    userAdjustable: boolean;
  }[];
  mql5Code: string;
  mql4Code: string;
  safetyChecks: CodeSafetyCheck[];
}

export interface SalesPackage {
  title: string;
  subTitle: string;
  catchyPoints: string[];
  productOverview: string;
  recommendedEnvironment: {
    broker: string;
    leverage: string;
    minDeposit: string;
    recommendedDeposit: string;
    vpsRecommended: boolean;
  };
  parameterManual: {
    group: string;
    items: { name: string; description: string; defaultValue: string; note: string }[];
  }[];
  riskDisclaimer: string;
  faqList: { question: string; answer: string }[];
}

export type LicenseType = 'lifetime' | 'subscription';

export interface LicenseInfo {
  isPro: boolean;
  email?: string;
  code?: string;
  type?: LicenseType;
  expiresAt?: string | null;
  activatedAt?: string;
}
