/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BacktestResult, BuyerConfig, EASpec, SalesPackage } from '../types';

export function buildSalesPackage(config: BuyerConfig, eaSpec: EASpec, stats: BacktestResult): SalesPackage {
  const pairName = stats.pairDisplayName || (config.pair === 'AUTO' ? 'EUR/USD (お任せ自動選定)' : config.pair);
  const tfName = config.timeframe === 'AUTO' ? 'M30 (30分足・推奨)' : config.timeframe;

  return {
    title: `【過剰最適化排除・本物志向EA】${eaSpec.name} - ${pairName} PF${stats.profitFactor} / 最大DD${stats.maxDrawdownPercent}%の堅牢クオンツ設計`,
    subTitle: `自作EAの9割が散る「カーブフィッティング」を科学的に排除！ウォークフォワード未知相場耐性 × 動的ATR防衛によるプロ仕様設計`,
    catchyPoints: [
      `【カーブフィッティング対策済】過去データへの無理な辻褄合わせを排し、未来相場での再現性を最優先したウォークフォワード分析をクリア`,
      `実績に裏付けられた高PF ${stats.profitFactor} ＆ 許容最大ドローダウン ${stats.maxDrawdownPercent}% 以下の低リスク運用（検証通貨: ${pairName}）`,
      `指標発表や相場急変・スプレッド拡大時でも資金を守る「動的ATRボラティリティ防衛フィルター」内蔵`,
      `週平均 ${stats.tradesPerWeek} 回の確実なエントリー頻度（「動かないEA」のストレスを解消）`,
      `MT4 / MT5 両対応の完全動作コード（ゼロ除算・ロット正規化・スプレッドフィルター厳重実装）`,
      `個人開発EAで多発する「OrderSendエラー」を未然に遮断するプロクオンツ仕様のフェイルセーフ`,
      `金曜夜間のポジション全決済機能（週末ギャップ・月曜窓開けリスク完全遮断）`,
    ],
    productOverview: `本EA「${eaSpec.name}」は、大手EA販売プラットフォーム（GogoJungle等）での高評価・ロングセラーEAの設計思想と、YouTube等のトップトレーダーが実践する「マルチタイムフレーム環境認識＋ATR動的ブレイク」を融合させて開発された、販売用商用自動売買プログラムです。

単一の特定期間だけに極端に数値を合わせた「カーブフィッティング（過剰最適化）」を徹底的に排除し、どのような相場サイクル（上昇トレンド・下降トレンド・レンジブレイク）においても統計的優位性（エッジ）を維持する王道ロジックを採用しています。

また、購入者様が利用される様々な国内・海外FXブローカー（最小LotやLotStep、スプレッド仕様の違い）において取引エラーやゼロ除算が発生しないよう、厳格な防護プログラミングを施しています。`,
    recommendedEnvironment: {
      broker: 'MT4/MT5対応ブローカー（低スプレッド推奨: AXIORY, XM, TitanFX, 楽天MT4, OANDA等）',
      leverage: '25倍〜500倍（国内・海外両対応）',
      minDeposit: '5万円〜 (0.01ロット運用時)',
      recommendedDeposit: '10万〜30万円以上 (リスク比率1%以下推奨)',
      vpsRecommended: true,
    },
    parameterManual: [
      {
        group: '基本トレード設定',
        items: [
          {
            name: 'InpMagicNumber',
            description: 'EAを識別するための固有番号。他のEAや裁量トレードと重複しない任意の数字を指定します。',
            defaultValue: '20260901',
            note: '他のEAと併用する場合は必ず異なる番号にしてください。',
          },
          {
            name: 'InpTradeComment',
            description: '注文履歴に記録されるコメント表記。',
            defaultValue: eaSpec.name,
            note: '口座履歴でこのEAの取引を判別する際に便利です。',
          },
          {
            name: 'InpMaxSpread',
            description: 'エントリーを許可する最大スプレッド（Point単位: 25 = 2.5pips）。',
            defaultValue: '25',
            note: '急激な拡大時の不利約定を防ぎます。',
          },
        ],
      },
      {
        group: '資金管理・ロット設定',
        items: [
          {
            name: 'InpRiskPercent',
            description: '口座有効証拠金に対する1回あたりの最大損失許容率（%）。',
            defaultValue: '1.0',
            note: '0に設定すると下の固定ロット(InpFixedLot)が適用されます。初心者は1.0%以下を推奨。',
          },
          {
            name: 'InpFixedLot',
            description: '固定ロット数。InpRiskPercent=0の時に有効となります。',
            defaultValue: '0.10',
            note: '証拠金に合わせて安全なロットを設定してください。',
          },
          {
            name: 'InpMaxLot',
            description: '複利計算時でも超えない最大ロット上限。',
            defaultValue: '5.00',
            note: '想定外の過大注文をブロックする安全装置です。',
          },
        ],
      },
      {
        group: 'トレール・週末保護設定',
        items: [
          {
            name: 'InpUseTrailingStop',
            description: '含み益が伸びた際にストップロスを引き上げるトレーリング機能。',
            defaultValue: 'true',
            note: '利益の確保と反転時の建値決済を自動化します。',
          },
          {
            name: 'InpCloseOnFriday',
            description: '金曜日の指定時刻に全保有ポジションを成行決済する週末保護機能。',
            defaultValue: 'true',
            note: '月曜朝の窓開け（ギャップ）によるロスカットリスクをゼロにします。',
          },
          {
            name: 'InpFridayCloseHour',
            description: '金曜日の強制決済サーバー時刻（21時推奨）。',
            defaultValue: '21',
            note: 'ブローカーのサーバータイムに合わせて設定してください。',
          },
        ],
      },
    ],
    riskDisclaimer: `【投資に係るリスクおよび手数料について】
本結果は過去データを使用したシミュレーションであり、将来の利益を保証するものではありません。FX（外国為替証拠金取引）は価格変動リスクを伴い、元本を割り込むおそれがあります。過去のバックテスト数値は将来の運用結果を約束するものではありません。お取引にあたってはご自身の資金状況やリスク許容度を十分に考慮のうえ、余剰資金にて自己責任でご運用ください。`,
    faqList: [
      {
        question: 'Q. 初心者でもMT4/MT5に簡単に導入できますか？',
        answer:
          'はい。MT4またはMT5の「データフォルダを開く」から「MQL4/Experts」または「MQL5/Experts」にファイルを配置し、チャートにドラッグ＆ドロップするだけで即座に稼働開始できます。日本語のパラメータ設定項目を採用しているため直感的に操作いただけます。',
      },
      {
        question: 'Q. どの通貨ペア・時間足が一番推奨されますか？',
        answer: `本EAは${pairName}の${tfName}を基準に開発・最適化されていますが、主要通貨ペア（EURUSD, GBPJPY, EURJPY）でもマルチタイム環境認識が有効に機能します。時間足はM30以上（M30, H1）での運用を最も推奨いたします。`,
      },
      {
        question: 'Q. ナンピンやマーチンゲールは行いますか？',
        answer:
          '一切行いません。ポジションは常に1回のエントリーにつき1つ（単利・または証拠金比率一定リスク）で管理され、エントリーと同時に必ずATR連動のストップロスが発注される完全単一ポジション安全設計です。',
      },
      {
        question: 'Q. VPS（仮想専用サーバー）は必須ですか？',
        answer:
          '24時間安定して売買シグナルを逃さず、週末クローズを確実に実行するため、お名前.comデスクトップクラウドやABLENET等のWindows VPS環境での稼働を強く推奨いたします。',
      },
      {
        question: 'Q. 購入後にロット数や設定を変更できますか？',
        answer:
          'はい。設定画面（Inputs）において、固定ロット、リスクパーセント、SL/TP倍率、スプレッド上限など、すべての重要数値を自由に変更できます。',
      },
    ],
  };
}
