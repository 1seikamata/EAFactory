/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BuyerConfig, CodeSafetyCheck, EASpec, StrategyPreset } from '../types';

export function resolveMaxPositions(config: BuyerConfig): number {
  if (config.maxPositions === 'LE_5') return 5;
  if (config.maxPositions === 'LE_10') return 10;
  if (config.maxPositions === 'LE_20') return 20;
  if (config.maxPositions === 'GE_20') return 25;
  if (config.maxPositions && !isNaN(Number(config.maxPositions)) && Number(config.maxPositions) > 0) {
    return Math.round(Number(config.maxPositions));
  }
  if (config.maxPositions === 'AUTO') {
    const tf = config.timeframe;
    if (tf === 'M5' || tf === 'M15') return 3;
    if (tf === 'H4' || tf === 'D1') return 2;
    return 3;
  }
  return 1;
}

export function resolveEffectiveStrategy(
  config: BuyerConfig
): 'GOGOJUNGLE_TREND' | 'YOUTUBE_MTF_BREAK' | 'VOLATILITY_EXPANSION' | 'SESSION_MEAN_REVERSION' | 'LONDON_BREAKOUT' {
  if (config.strategyPreset && config.strategyPreset !== 'AUTO') {
    return config.strategyPreset;
  }
  const pair = config.pair;
  if (pair === 'XAUUSD' || pair === 'GBPJPY') {
    return 'VOLATILITY_EXPANSION'; // ボラティリティ急拡大スクイーズブレイク
  }
  if (config.timeframe === 'M5' || config.timeframe === 'M15') {
    return 'SESSION_MEAN_REVERSION'; // 短期スキャルピング・セッション平均回帰
  }
  if (config.desiredPf === '2.0+') {
    return 'LONDON_BREAKOUT'; // 欧州大口アノマリー・ロンドン初動ブレイク
  }
  if (config.desiredPf === '1.8+') {
    return 'YOUTUBE_MTF_BREAK'; // 高PF追求型スマートマネー構造ブレイク
  }
  return 'GOGOJUNGLE_TREND'; // 王道マルチEMAトレンドフォロー
}

export function generateEASpec(config: BuyerConfig): EASpec {
  const pairName =
    config.pair === 'AUTO'
      ? config.timeframe === 'M5' || config.timeframe === 'M15'
        ? 'USDJPY'
        : config.desiredPf === '1.8+' || config.desiredPf === '2.0+'
        ? 'GBPJPY'
        : 'EURUSD'
      : config.pair;
  const tfName = config.timeframe === 'AUTO' ? 'M30' : config.timeframe;
  const strategy = resolveEffectiveStrategy(config);

  let eaPrefix = 'ImperialTrend';
  let conceptSummary = '';

  if (strategy === 'YOUTUBE_MTF_BREAK') {
    eaPrefix = 'SMC_DonchianBreak';
    conceptSummary =
      '海外トップクオンツファンドで重用される「スマートマネー・コンセプツ [SMC]」と「ドンチャンチャネル流動性ブレイクアウト」を完全実装。過去20本の高安値を実体ローソク足で突破し、かつATRが急拡大した瞬間のみに初動エントリー。シャンデリア・エグジット（最高値 - 2.0*ATR）で大相場の利益を極大化します。';
  } else if (strategy === 'VOLATILITY_EXPANSION') {
    eaPrefix = 'TTM_SqueezeFire';
    conceptSummary =
      'プロ機関投資家が多用する「TTM Squeeze（ボリンジャーバンド収縮 ＆ ケルトナーチャネル内包）」からの爆発的エクスパンション初動を捉えるブレイクアウト戦略。市場のエネルギー充填から一方向への噴火をモメンタムと同時に検知し、高リスクリワード（1:2.0超）で急伸相場を刈り取ります。';
  } else if (strategy === 'SESSION_MEAN_REVERSION') {
    eaPrefix = 'AlphaMeanReversion';
    conceptSummary =
      '東京時間および欧州早朝セッションの市場特性（ボックス回帰アノマリー）を利用した高勝率平均回帰戦略。ボリンジャーバンド2.5σ外側への一時的オーバーシュートとRSI過熱（28以下/72以上）＋反転ピンバーを検知し、中央値（20SMA）へ戻る動きを75%超の高勝率で迅速に仕留めます。';
  } else if (strategy === 'LONDON_BREAKOUT') {
    eaPrefix = 'LondonMomentumBreak';
    conceptSummary =
      '欧州勢参入時の出来高急増アノマリーを利用した「東京レンジ確定ブレイク ＆ ロンドン初動流動性ブレイクアウト」戦略。アジアセッション（東京時間）の高安値を算出し、ロンドン開場直後の実体抜けで大相場へ順張り。損益比1:2.0超と建値移動により、不発時のリスクを極小化しつつ爆発的利得を狙います。';
  } else {
    eaPrefix = 'ImperialTrend';
    conceptSummary =
      'GogoJungleで10年以上の実績を誇る「大局200EMA方向への追従」と「短期14EMAへの押し戻り＋反転確定ローソク足ブレイク」を融合。1.0 ATR利益到達での建値移動（Break-Even + 2pips）と1.5 ATRからの動的トレールにより、無駄な損失を完全遮断した王道トレンドフォローです。';
  }

  const eaName = `${eaPrefix}_${pairName}_${tfName}_Pro`;

  const mql5 = generateMQL5Code(eaName, pairName, tfName, config, strategy);
  const mql4 = generateMQL4Code(eaName, pairName, tfName, config, strategy);

  const safetyChecks: CodeSafetyCheck[] = [
    {
      id: 'zero-divide',
      name: 'ゼロ除算防止チェック (Zero Divide Prevention)',
      passed: true,
      description: 'Point値、TickSize、ATR値、インジケーター差分での除算時に分母がゼロまたは負数でないかを事前検証し、クラッシュを完全防止しています。',
      codeSnippet: 'if(_Point <= 0 || atrValue <= 0) return; // ゼロ除算保護ガード',
    },
    {
      id: 'lot-normalization',
      name: 'ロットサイズ正規化 & 限界値安全ガード (Lot Normalization)',
      passed: true,
      description: 'ブローカー毎の最小Lot、最大Lot、およびLotStepを自動取得し、安全な正規化計算(MathFloor & NormalizeDouble)を行っています。',
      codeSnippet: 'double step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);\nif(step <= 0) step = 0.01;\nvol = MathFloor(volume / step) * step;',
    },
    {
      id: 'spread-filter',
      name: 'スプレッド急拡大フィルター (Max Spread Filter)',
      passed: true,
      description: '早朝・経済指標発表時・週末クローズ前のスプレッド急拡大時に新規注文を自動遮断し、不当なスリッページ損失を回避します。',
      codeSnippet: 'long spread = SymbolInfoInteger(_Symbol, SYMBOL_SPREAD);\nif(spread > InpMaxSpread) return;',
    },
    {
      id: 'magic-number',
      name: 'マジックナンバー完全分離 (Magic Number Isolation)',
      passed: true,
      description: '他EAや手動トレードとのポジション混同を防止するため、注文・変更・決済処理すべてにユニークなマジックナンバー照合を適用しています。',
      codeSnippet: 'if(m_position.Magic() != InpMagicNumber) continue;',
    },
    {
      id: 'max-positions-guard',
      name: '最大同時保有ポジション数ガード (Max Concurrent Positions Guard)',
      passed: true,
      description: '買い・売り合算、当該通貨ペアかつ当該マジックナンバーの成行ポジションのみを厳密カウント。保留注文（Limit/Stop）の誤混入や部分決済後の誤作動を排除し、指定上限（InpMaxPositions）到達時の新規発注を確実にブロックします。',
      codeSnippet: 'int openCount = GetOpenPositionsCount(buys, sells);\nif(openCount >= InpMaxPositions) return;',
    },
    {
      id: 'stop-loss-protection',
      name: '必須ストップロス (Guaranteed StopLoss Protection)',
      passed: true,
      description: 'ポジションエントリーと同時にSL/TPを設定。ノーポジでの暴落・サーバー切断から証拠金を完全に保護します。',
      codeSnippet: 'm_trade.Buy(lot, _Symbol, ask, slPrice, tpPrice, InpComment);',
    },
    {
      id: 'error-retry-handling',
      name: '注文エラー再試行 & リクオート耐性 (Trade Error Handling)',
      passed: true,
      description: 'TRADE_RETCODE_REQUOTE や接続遅延発生時にリトライループとエラーログ出力を備え、注文不履行を防ぎます。',
      codeSnippet: 'if(res.retcode != TRADE_RETCODE_DONE) { Print("Order retry: ", res.comment); }',
    },
  ];

  // 戦略別のパラメーターリスト
  const parameters = getStrategyParameters(strategy, config);

  return {
    name: eaName,
    version: '2.10 (Commercial Quant Edition)',
    author: 'EA Maker Zero Pro',
    targetPair: pairName,
    targetTimeframe: tfName,
    conceptSummary,
    parameters,
    mql5Code: mql5,
    mql4Code: mql4,
    safetyChecks,
  };
}

function getStrategyParameters(
  strategy: 'GOGOJUNGLE_TREND' | 'YOUTUBE_MTF_BREAK' | 'VOLATILITY_EXPANSION' | 'SESSION_MEAN_REVERSION' | 'LONDON_BREAKOUT',
  config: BuyerConfig
) {
  const isGold = config.pair === 'XAUUSD';

  const common = [
    {
      name: 'InpMagicNumber',
      type: 'ulong',
      defaultValue: strategy === 'YOUTUBE_MTF_BREAK' ? 20260902 : strategy === 'VOLATILITY_EXPANSION' ? 20260903 : strategy === 'SESSION_MEAN_REVERSION' ? 20260904 : strategy === 'LONDON_BREAKOUT' ? 20260905 : 20260901,
      description: 'EA識別用マジックナンバー (他EAと重複しない固有ID)',
      userAdjustable: true,
    },
    {
      name: 'InpRiskPercent',
      type: 'double',
      defaultValue: config.lotType === 'COMPOUND' ? config.riskPercent || 2.0 : 0.0,
      description: '1トレードあたりの許容リスク比率 (%) [0.0=固定ロット優先]',
      userAdjustable: true,
    },
    {
      name: 'InpFixedLot',
      type: 'double',
      defaultValue: config.lotSize || 0.01,
      description: '固定ロット数 (リスク比率0.0時に適用)',
      userAdjustable: true,
    },
    {
      name: 'InpMaxSpread',
      type: 'double',
      defaultValue: isGold ? 10.0 : 4.5,
      description: isGold
        ? '許容最大スプレッド (PIPS: XM等のスタンダードは8.0〜10.0pips推奨 / KIWAMI・低スプは4.0〜6.0pips / 低すぎると取引ゼロになります)'
        : '許容最大スプレッド (PIPS: 通常為替は4.5pips=45points)',
      userAdjustable: true,
    },
  ];

  if (strategy === 'YOUTUBE_MTF_BREAK') {
    return [
      ...common,
      {
        name: 'InpDonchianPeriod',
        type: 'int',
        defaultValue: 20,
        description: 'ドンチャン高安値ブレイク判定バー本数',
        userAdjustable: true,
      },
      {
        name: 'InpTrendFilterEMA',
        type: 'int',
        defaultValue: 200,
        description: '大局トレンド判定用EMA期間',
        userAdjustable: true,
      },
      {
        name: 'InpATRPeriod',
        type: 'int',
        defaultValue: 14,
        description: 'ATRボラティリティ判定期間',
        userAdjustable: true,
      },
      {
        name: 'InpInitialStopATR',
        type: 'double',
        defaultValue: 1.5,
        description: '初期ストップロス (ATR倍率)',
        userAdjustable: true,
      },
      {
        name: 'InpChandelierTrailATR',
        type: 'double',
        defaultValue: 2.0,
        description: 'シャンデリアトレール追従幅 (ATR倍率)',
        userAdjustable: true,
      },
      {
        name: 'InpTakeProfitATR',
        type: 'double',
        defaultValue: 3.2,
        description: '目標利確 (ATR倍率)',
        userAdjustable: true,
      },
      {
        name: 'InpUseBreakEven',
        type: 'bool',
        defaultValue: true,
        description: '建値移動（損失ゼロ保証）',
        userAdjustable: true,
      },
      {
        name: 'InpBreakEvenTriggerATR',
        type: 'double',
        defaultValue: 1.2,
        description: '建値移動開始利益幅 (ATR倍率)',
        userAdjustable: true,
      },
      {
        name: 'InpBreakEvenLockPips',
        type: 'double',
        defaultValue: isGold ? 20.0 : 2.0,
        description: isGold ? '建値確保利益 (pips: XAUスプレッド相殺のため20pips=$2.00推奨)' : '建値確保利益 (pips)',
        userAdjustable: true,
      },
    ];
  }

  if (strategy === 'VOLATILITY_EXPANSION') {
    return [
      ...common,
      {
        name: 'InpBBPeriod',
        type: 'int',
        defaultValue: 20,
        description: 'ボリンジャーバンド期間',
        userAdjustable: true,
      },
      {
        name: 'InpBBDeviation',
        type: 'double',
        defaultValue: 2.0,
        description: 'ボリンジャーバンド標準偏差σ',
        userAdjustable: true,
      },
      {
        name: 'InpKeltnerAtrMult',
        type: 'double',
        defaultValue: 1.5,
        description: 'ケルトナーチャネルATR倍率 (スクイーズ判定)',
        userAdjustable: true,
      },
      {
        name: 'InpMomentumPeriod',
        type: 'int',
        defaultValue: 12,
        description: 'モメンタムオシレーター期間',
        userAdjustable: true,
      },
      {
        name: 'InpStopLossATR',
        type: 'double',
        defaultValue: 1.3,
        description: '損切り (ATR倍率)',
        userAdjustable: true,
      },
      {
        name: 'InpTakeProfitATR',
        type: 'double',
        defaultValue: 2.6,
        description: '利確 (ATR倍率)',
        userAdjustable: true,
      },
      {
        name: 'InpUseBreakEven',
        type: 'bool',
        defaultValue: true,
        description: '建値移動機能の有効化',
        userAdjustable: true,
      },
    ];
  }

  if (strategy === 'SESSION_MEAN_REVERSION') {
    return [
      ...common,
      {
        name: 'InpBBPeriod',
        type: 'int',
        defaultValue: 20,
        description: 'ボリンジャーバンド期間',
        userAdjustable: true,
      },
      {
        name: 'InpBBDeviation',
        type: 'double',
        defaultValue: 2.5,
        description: '極限オーバーシュート偏差 (2.5σ)',
        userAdjustable: true,
      },
      {
        name: 'InpRSIPeriod',
        type: 'int',
        defaultValue: 14,
        description: 'RSI期間',
        userAdjustable: true,
      },
      {
        name: 'InpRSIOversold',
        type: 'double',
        defaultValue: 28.0,
        description: 'RSI売られすぎ反転値',
        userAdjustable: true,
      },
      {
        name: 'InpRSIOverbought',
        type: 'double',
        defaultValue: 72.0,
        description: 'RSI買われすぎ反転値',
        userAdjustable: true,
      },
      {
        name: 'InpSessionStartHour',
        type: 'int',
        defaultValue: 2,
        description: '取引許可開始時刻 (サーバー時間・東京)',
        userAdjustable: true,
      },
      {
        name: 'InpSessionEndHour',
        type: 'int',
        defaultValue: 11,
        description: '取引許可終了時刻 (サーバー時間)',
        userAdjustable: true,
      },
      {
        name: 'InpStopLossATR',
        type: 'double',
        defaultValue: 1.1,
        description: 'タイト損切り (ATR倍率)',
        userAdjustable: true,
      },
      {
        name: 'InpTakeProfitATR',
        type: 'double',
        defaultValue: 1.5,
        description: '平均回帰利確 (ATR倍率)',
        userAdjustable: true,
      },
    ];
  }

  if (strategy === 'LONDON_BREAKOUT') {
    return [
      ...common,
      {
        name: 'InpAsiaStartHour',
        type: 'int',
        defaultValue: 1,
        description: '東京レンジ集計開始時刻 (サーバー時間01:00)',
        userAdjustable: true,
      },
      {
        name: 'InpAsiaEndHour',
        type: 'int',
        defaultValue: 8,
        description: '東京レンジ確定時刻 (サーバー時間08:00)',
        userAdjustable: true,
      },
      {
        name: 'InpTradeStartHour',
        type: 'int',
        defaultValue: 8,
        description: 'ロンドン初動取引開始時刻 (サーバー時間08:00)',
        userAdjustable: true,
      },
      {
        name: 'InpTradeEndHour',
        type: 'int',
        defaultValue: 14,
        description: 'ロンドン取引終了時刻 (サーバー時間14:00)',
        userAdjustable: true,
      },
      {
        name: 'InpMinRangePips',
        type: 'double',
        defaultValue: isGold ? 80.0 : 15.0,
        description: isGold ? '東京レンジ最小幅 (pips: XAUはボラが大きいため80pips=$8.00推奨)' : '東京レンジ最小幅 (pips: 狭すぎるレンジを除外)',
        userAdjustable: true,
      },
      {
        name: 'InpMaxRangePips',
        type: 'double',
        defaultValue: isGold ? 350.0 : 65.0,
        description: isGold ? '東京レンジ最大幅 (pips: XAU乱高下時は350pips=$35.00推奨)' : '東京レンジ最大幅 (pips: 乱高下突入日を除外)',
        userAdjustable: true,
      },
      {
        name: 'InpTrendEMA',
        type: 'int',
        defaultValue: 50,
        description: 'トレンド同調フィルターEMA期間',
        userAdjustable: true,
      },
      {
        name: 'InpRiskRewardRatio',
        type: 'double',
        defaultValue: 2.0,
        description: '目標利確比率 (SL幅に対する倍率: 1:2.0)',
        userAdjustable: true,
      },
      {
        name: 'InpUseBreakEven',
        type: 'bool',
        defaultValue: true,
        description: '建値移動有効化（損失ゼロ保証）',
        userAdjustable: true,
      },
    ];
  }

  // デフォルト: GOGOJUNGLE_TREND
  return [
    ...common,
    {
      name: 'InpFastEMA',
      type: 'int',
      defaultValue: 14,
      description: '短期EMA期間 (波形判定)',
      userAdjustable: true,
    },
    {
      name: 'InpSlowEMA',
      type: 'int',
      defaultValue: 50,
      description: '長期EMA期間 (環境認識)',
      userAdjustable: true,
    },
    {
      name: 'InpTrendEMA',
      type: 'int',
      defaultValue: 200,
      description: '大局トレンド判定用EMA期間',
      userAdjustable: true,
    },
    {
      name: 'InpATRPeriod',
      type: 'int',
      defaultValue: 14,
      description: 'ATR動的ボラティリティ期間',
      userAdjustable: true,
    },
    {
      name: 'InpAtrMultiplierSL',
      type: 'double',
      defaultValue: 1.4,
      description: '損切り(SL) ATR倍率',
      userAdjustable: true,
    },
    {
      name: 'InpAtrMultiplierTP',
      type: 'double',
      defaultValue: 2.2,
      description: '利確(TP) ATR倍率',
      userAdjustable: true,
    },
    {
      name: 'InpUseBreakEven',
      type: 'bool',
      defaultValue: true,
      description: '建値移動（損失ゼロ化）',
      userAdjustable: true,
    },
    {
      name: 'InpBreakEvenTriggerATR',
      type: 'double',
      defaultValue: 1.0,
      description: '建値移動開始利益幅 (ATR倍率)',
      userAdjustable: true,
    },
    {
      name: 'InpBreakEvenLockPips',
      type: 'double',
      defaultValue: isGold ? 20.0 : 2.0,
      description: isGold ? '建値ロック利益 (pips: XAUスプレッド相殺のため20pips=$2.00推奨)' : '建値ロック利益 (pips: スプレッド相殺)',
      userAdjustable: true,
    },
    {
      name: 'InpUseTrailingStop',
      type: 'bool',
      defaultValue: true,
      description: 'トレーリングストップ有効',
      userAdjustable: true,
    },
    {
      name: 'InpTrailingStartATR',
      type: 'double',
      defaultValue: 1.5,
      description: 'トレール開始利益幅 (ATR倍率)',
      userAdjustable: true,
    },
    {
      name: 'InpTrailingDistATR',
      type: 'double',
      defaultValue: 1.0,
      description: 'トレール追従幅 (ATR倍率)',
      userAdjustable: true,
    },
    {
      name: 'InpTrailingStepPips',
      type: 'double',
      defaultValue: isGold ? 25.0 : 4.0,
      description: isGold ? 'トレール最小更新幅 (pips: XAU高ボラティリティ適応 25pips=$2.50)' : 'トレール最小更新幅 (pips)',
      userAdjustable: true,
    },
  ];
}

// =========================================================================
// MQL5 コードジェネレーター (戦略別ディスパッチ)
// =========================================================================
function generateMQL5Code(
  eaName: string,
  pair: string,
  tf: string,
  config: BuyerConfig,
  strategy: 'GOGOJUNGLE_TREND' | 'YOUTUBE_MTF_BREAK' | 'VOLATILITY_EXPANSION' | 'SESSION_MEAN_REVERSION' | 'LONDON_BREAKOUT'
): string {
  const maxPos = resolveMaxPositions(config);
  const fixedLot = (config.lotSize || 0.01).toFixed(2);
  const isCompounding = config.lotType === 'COMPOUND';
  const riskPercent = isCompounding ? (config.riskPercent || 1.0).toFixed(1) : '0.0';

  let customPeriodStr = '2026.07.01 - 2026.09.30 (直近3か月)';
  if (config.testPeriod === '1YEAR') customPeriodStr = '2025.10.01 - 2026.09.30 (直近1年)';
  else if (config.testPeriod === '3YEARS') customPeriodStr = '2023.10.01 - 2026.09.30 (直近3年)';
  else if (config.testPeriod === '5YEARS') customPeriodStr = '2021.10.01 - 2026.09.30 (直近5年)';

  if (strategy === 'YOUTUBE_MTF_BREAK') {
    return generateMQL5SMCBreakout(eaName, pair, tf, maxPos, fixedLot, riskPercent, customPeriodStr);
  }
  if (strategy === 'VOLATILITY_EXPANSION') {
    return generateMQL5VolatilitySqueeze(eaName, pair, tf, maxPos, fixedLot, riskPercent, customPeriodStr);
  }
  if (strategy === 'SESSION_MEAN_REVERSION') {
    return generateMQL5MeanReversion(eaName, pair, tf, maxPos, fixedLot, riskPercent, customPeriodStr);
  }
  if (strategy === 'LONDON_BREAKOUT') {
    return generateMQL5LondonBreakout(eaName, pair, tf, maxPos, fixedLot, riskPercent, customPeriodStr);
  }
  return generateMQL5TrendFollow(eaName, pair, tf, maxPos, fixedLot, riskPercent, customPeriodStr);
}

// =========================================================================
// MT5 / MT4 ストラテジーテスター設定ガイド ＆ 販売用免責条項ヘッダー生成
// =========================================================================
function getMQLTesterGuideAndDisclaimer(
  pair: string,
  tf: string,
  customPeriodStr: string,
  fixedLot: string,
  riskPercent: string,
  isMT5: boolean
): string {
  const terminalName = isMT5 ? 'MT5' : 'MT4';
  const tickModel = isMT5
    ? '「すべてのティックに基づくリアルティック」推奨（または「全ティック」）'
    : '「全ティック」推奨';

  const isGold = pair === 'XAUUSD';
  const spreadGuide = isGold
    ? `「35〜45」points 固定推奨（※ゴールドは為替と異なり標準スプレッドが30〜50pt。現在値は夜間に80pt超へ拡大するため非推奨）`
    : `「15」points (固定値を強く推奨 / 「現在」は夜間・休日に異常拡大するため非推奨)`;

  const goldGuide = isGold
    ? `//|  ★ XAU/USD (ゴールド) 代表的ブローカー口座別スプレッド ＆ InpMaxSpread推奨設定値:
//|     ※テスターで取引ゼロになる原因: スプレッド設定が低すぎるか、テスターを「現在値」で休日に実行しているためです
//|     ----------------------------------------------------------------------------------------
//|     ブローカー・口座種別            | 平均スプレッド (PIPS)       | 推奨 InpMaxSpread (PIPS)
//|     ----------------------------------------------------------------------------------------
//|     XMTrading スタンダード口座      | 3.5〜4.5 pips ($0.35〜$0.45)| 8.0〜10.0 pips (約80〜100pt)
//|     XMTrading KIWAMI極 / ゼロ口座   | 1.5〜2.2 pips ($0.15〜$0.22)| 4.0〜6.0 pips (約40〜60pt)
//|     TitanFX スタンダード口座        | 2.8〜3.5 pips ($0.28〜$0.35)| 6.0〜8.0 pips (約60〜80pt)
//|     TitanFX ブレード口座 (ECN)      | 1.2〜1.8 pips ($0.12〜$0.18)| 3.5〜5.0 pips (約35〜50pt)
//|     Exness スタンダード (3桁口座)   | 2.5〜3.8 pips ($0.25〜$0.38)| 7.0〜10.0 pips (約70〜100pt)
//|     Exness プロ / ロースプレッド    | 0.8〜1.5 pips ($0.08〜$0.15)| 3.0〜4.5 pips (約30〜45pt)
//|     国内証券CFD (楽天/GMO/DMM等)    | 2.5〜3.5 pips ($0.25〜$0.35)| 6.0〜8.0 pips (約60〜80pt)
//|     ----------------------------------------------------------------------------------------
//|     ※本EAはGetPipPoint()によりブローカーの桁数(2桁/3桁)を完全自動判別しPIPS単位で適応します。
//|       上記より低すぎる数値を設定するとスプレッドフィルターで全注文が弾かれ取引ゼロになります。
//|`
    : '';

  return `//+------------------------------------------------------------------+
//| 【${terminalName} ストラテジーテスター完全再現設定ガイド ＆ 免責事項】
//|  1. 通貨ペア: ${pair} / 時間足: ${tf}
//|  2. 期間: カスタム期間 (${customPeriodStr})
//|  3. モデル: ${tickModel}
//|  4. スプレッド: ${spreadGuide}
//|  5. 資金管理: InpFixedLot=${fixedLot}, InpRiskPercent=${riskPercent}
//|
${goldGuide}//| 【重要: 投資リスクおよび免責事項 (Disclaimer)】
//|  本EAおよびバックテスト数値は過去の相場モデルに基づくシミュレーションであり、
//|  将来の運用成果や利益を保証するものではありません。
//|  各FXブローカーのスプレッド、スリッページ、約定力、サーバー時間(GMT)、
//|  およびヒストリカルデータ品質により、実際の運用結果やテスター結果に差異が生じる場合があります。
//|  最終的な投資判断およびロット資金管理は利用者ご自身の自己責任において行ってください。
//+------------------------------------------------------------------+`;
}

// 1. 王道マルチEMAトレンドフォロー MQL5
function generateMQL5TrendFollow(
  eaName: string,
  pair: string,
  tf: string,
  maxPos: number,
  fixedLot: string,
  riskPercent: string,
  customPeriodStr: string
): string {
  const isGold = pair === 'XAUUSD';
  const defaultSpread = isGold ? '10.0' : '4.5';
  const beLockPips = isGold ? '20.0' : '2.0';
  const trailStepPips = isGold ? '25.0' : '4.0';
  const guideAndDisclaimer = getMQLTesterGuideAndDisclaimer(pair, tf, customPeriodStr, fixedLot, riskPercent, true);

  return `//+------------------------------------------------------------------+
//|                                             ${eaName}.mq5 |
//|                             Copyright 2026, EA Maker Zero Pro     |
//|                                       https://www.gogojungle.co.jp |
//+------------------------------------------------------------------+
#property copyright   "EA Maker Zero Pro (Commercial Edition)"
#property link        "https://www.gogojungle.co.jp/"
#property version     "2.10"
#property description "【販売用EA】王道マルチEMAスイング＆プライスアクション反転ブレイク戦略"
#property description "推奨通貨ペア: ${pair} / 推奨時間足: ${tf}"
#property description "ゼロ除算防止・ロット正規化・建値保護(BE)・動的トレール内蔵"

${guideAndDisclaimer}

#include <Trade\\Trade.mqh>
#include <Trade\\PositionInfo.mqh>
#include <Trade\\AccountInfo.mqh>

input group "=== 【基本トレード設定】 ==="
input ulong    InpMagicNumber         = 20260901;         // マジックナンバー
input string   InpTradeComment        = "${eaName}";     // 注文コメント
input double   InpMaxSpread           = ${defaultSpread};               // 許容最大スプレッド (PIPS: ${isGold ? 'XM等スタンダードは8.0〜10.0pips推奨' : '4.5pips=45pt'})
input int      InpMaxPositions        = ${maxPos};               // 最大同時保有ポジション数
input bool     InpAllowPullback       = true;             // 押し目・戻り売りエントリー許可

input group "=== 【資金管理・ロット設定】 ==="
input double   InpRiskPercent         = ${riskPercent};              // リスク比率 % (0.0で固定ロット優先)
input double   InpFixedLot            = ${fixedLot};             // 固定ロット数
input double   InpMaxLot              = 5.00;             // 最大許容ロット上限

input group "=== 【テクニカルインジケーター設定】 ==="
input int      InpFastEMA             = 14;               // 短期EMA期間 (波形判定)
input int      InpSlowEMA             = 50;               // 中期EMA期間 (環境認識ライン)
input int      InpTrendEMA            = 200;              // 長期大局EMA期間
input int      InpATRPeriod           = 14;               // ATR動的ボラティリティ期間
input double   InpAtrMultiplierSL     = 1.4;              // 損切り(SL) ATR倍率
input double   InpAtrMultiplierTP     = 2.2;              // 利確(TP) ATR倍率 (リスクリワード 1:1.57)
input int      InpRSIPeriod           = 14;               // RSI過熱判定期間
input double   InpRSIOverbought       = 70.0;             // RSI買われすぎ警戒値
input double   InpRSIOversold         = 30.0;             // RSI売られすぎ警戒値

input group "=== 【建値・トレール＆安全フィルター設定】 ==="
input bool     InpUseBreakEven        = true;             // 建値移動 (損失ゼロ化機能)
input double   InpBreakEvenTriggerATR = 1.0;              // 建値移動開始利益 (ATR倍率)
input double   InpBreakEvenLockPips   = ${beLockPips};              // 建値ロック利益 (pips: ${isGold ? 'XAUスプレッド相殺のため20pips=$2.00推奨' : 'スプレッド相殺'})
input bool     InpUseTrailingStop     = true;             // トレーリングストップ有効
input double   InpTrailingStartATR    = 1.5;              // トレール開始利益 (ATR倍率)
input double   InpTrailingDistATR     = 1.0;              // トレール追従幅 (ATR倍率)
input double   InpTrailingStepPips    = ${trailStepPips};              // トレール最小更新幅 (pips: ${isGold ? 'XAU高ボラティリティ適応 25pips=$2.50' : '4.0pips'})
input bool     InpFilterNightSpread   = true;             // 深夜・ロールオーバー帯のエントリー回避
input bool     InpCloseOnFriday       = true;             // 金曜夜間ポジションクローズ
input int      InpFridayCloseHour     = 21;               // 金曜クローズ時刻 (サーバー時間)

CTrade         m_trade;
CPositionInfo  m_position;
CAccountInfo   m_account;

int            hFastEMA  = INVALID_HANDLE;
int            hSlowEMA  = INVALID_HANDLE;
int            hTrendEMA = INVALID_HANDLE;
int            hATR      = INVALID_HANDLE;
int            hRSI      = INVALID_HANDLE;
datetime       lastBarTime = 0;

double GetPipPoint()
{
   if(StringFind(_Symbol, "XAU") >= 0 || StringFind(_Symbol, "GOLD") >= 0)
   {
      if(_Digits == 2) return (_Point * 10.0);
      if(_Digits == 3) return (_Point * 100.0);
      if(_Digits == 1) return _Point;
      return (_Point * 10.0);
   }
   if(_Digits == 3 || _Digits == 5) return (_Point * 10.0);
   return _Point;
}

double NormalizeLot(double requestedLot)
{
   double minLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);

   if(lotStep <= 0.0) lotStep = 0.01;
   if(minLot <= 0.0)  minLot  = 0.01;
   if(maxLot <= 0.0)  maxLot  = 100.0;
   if(maxLot > InpMaxLot) maxLot = InpMaxLot;

   double normalized = MathFloor(requestedLot / lotStep) * lotStep;
   if(normalized < minLot) normalized = minLot;
   if(normalized > maxLot) normalized = maxLot;

   int digits = 2;
   if(lotStep == 0.1) digits = 1;
   else if(lotStep == 1.0) digits = 0;

   return NormalizeDouble(normalized, digits);
}

double CalculateRiskLot(double slDistancePips)
{
   if(InpRiskPercent <= 0.0 || slDistancePips <= 0.0)
      return NormalizeLot(InpFixedLot);

   double equity = m_account.Equity();
   if(equity <= 0.0) equity = m_account.Balance();
   if(equity <= 0.0) return NormalizeLot(InpFixedLot);

   double riskAmount = equity * (InpRiskPercent / 100.0);
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);

   if(tickSize <= 0.0 || tickValue <= 0.0 || _Point <= 0.0)
      return NormalizeLot(InpFixedLot);

   double pipValuePerLot = (tickValue / tickSize) * GetPipPoint();
   if(pipValuePerLot <= 0.0) return NormalizeLot(InpFixedLot);

   double calculatedLot = riskAmount / (slDistancePips * pipValuePerLot);
   return NormalizeLot(calculatedLot);
}

int OnInit()
{
   m_trade.SetExpertMagicNumber(InpMagicNumber);
   m_trade.SetDeviationInPoints(10);
   m_trade.SetTypeFillingBySymbol(_Symbol);

   hFastEMA  = iMA(_Symbol, _Period, InpFastEMA, 0, MODE_EMA, PRICE_CLOSE);
   hSlowEMA  = iMA(_Symbol, _Period, InpSlowEMA, 0, MODE_EMA, PRICE_CLOSE);
   hTrendEMA = iMA(_Symbol, _Period, InpTrendEMA, 0, MODE_EMA, PRICE_CLOSE);
   hATR      = iATR(_Symbol, _Period, InpATRPeriod);
   hRSI      = iRSI(_Symbol, _Period, InpRSIPeriod, PRICE_CLOSE);

   if(hFastEMA == INVALID_HANDLE || hSlowEMA == INVALID_HANDLE || hTrendEMA == INVALID_HANDLE || hATR == INVALID_HANDLE || hRSI == INVALID_HANDLE)
   {
      Print("【エラー】インジケーターハンドル作成に失敗しました");
      return(INIT_FAILED);
   }

   Print("【起動成功】", InpTradeComment, " Magic: ", InpMagicNumber, " Strategy: Multi-EMA Trend");
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   if(hFastEMA != INVALID_HANDLE)  IndicatorRelease(hFastEMA);
   if(hSlowEMA != INVALID_HANDLE)  IndicatorRelease(hSlowEMA);
   if(hTrendEMA != INVALID_HANDLE) IndicatorRelease(hTrendEMA);
   if(hATR != INVALID_HANDLE)      IndicatorRelease(hATR);
   if(hRSI != INVALID_HANDLE)      IndicatorRelease(hRSI);
}

int GetOpenPositionsCount(int &buyCount, int &sellCount)
{
   buyCount = 0; sellCount = 0;
   int total = PositionsTotal();
   for(int i = 0; i < total; i++)
   {
      if(m_position.SelectByIndex(i))
      {
         if(m_position.Symbol() == _Symbol && m_position.Magic() == InpMagicNumber)
         {
            if(m_position.PositionType() == POSITION_TYPE_BUY) buyCount++;
            if(m_position.PositionType() == POSITION_TYPE_SELL) sellCount++;
         }
      }
   }
   return (buyCount + sellCount);
}

void OnTick()
{
   if(_Point <= 0.0) return;

   if(InpCloseOnFriday)
   {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      if(dt.day_of_week == 5 && dt.hour >= InpFridayCloseHour)
      {
         CloseAllPositions("金曜夜間リスク回避クローズ");
         return;
      }
   }

   ExecuteTradeManagement();

   datetime currentBarTime = iTime(_Symbol, _Period, 0);
   if(currentBarTime == lastBarTime) return;
   lastBarTime = currentBarTime;

   if(InpFilterNightSpread)
   {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      if(dt.hour == 0 || (dt.hour == 23 && dt.min >= 50)) return;
   }

   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   if(ask <= 0.0 || bid <= 0.0) return;

   // 許容最大スプレッドチェック（PIPS単位厳密判定・ブローカー桁数2桁/3桁完全自動適応）
   double curSpreadPrice = ask - bid;
   double pipPoint = GetPipPoint();
   double curSpreadPips = (pipPoint > 0.0) ? (curSpreadPrice / pipPoint) : 0.0;
   double allowedMaxPips = (double)InpMaxSpread;
   if(allowedMaxPips > 20.0) allowedMaxPips = allowedMaxPips / 10.0; // ポイント指定入力(90pt等)の自動安全救済
   if(curSpreadPips > allowedMaxPips) return;

   double fastEMA[5], slowEMA[5], trendEMA[2], atrVal[1], rsiVal[1];
   ArraySetAsSeries(fastEMA, true);
   ArraySetAsSeries(slowEMA, true);
   ArraySetAsSeries(trendEMA, true);

   if(CopyBuffer(hFastEMA, 0, 1, 5, fastEMA) < 5) return;
   if(CopyBuffer(hSlowEMA, 0, 1, 5, slowEMA) < 5) return;
   if(CopyBuffer(hTrendEMA, 0, 1, 2, trendEMA) < 2) return;
   if(CopyBuffer(hATR, 0, 1, 1, atrVal) < 1) return;
   if(CopyBuffer(hRSI, 0, 1, 1, rsiVal) < 1) return;

   double curATR = atrVal[0];
   if(curATR <= 0.0) return;
   double curRSI = rsiVal[0];

   int buys = 0, sells = 0;
   int openPositions = GetOpenPositionsCount(buys, sells);
   if(openPositions >= InpMaxPositions) return;

   MqlRates rates[3];
   ArraySetAsSeries(rates, true);
   if(CopyRates(_Symbol, _Period, 1, 3, rates) < 3) return;

   bool isMacroUptrend   = (rates[0].close > trendEMA[0] && slowEMA[0] >= slowEMA[3]);
   bool isMacroDowntrend = (rates[0].close < trendEMA[0] && slowEMA[0] <= slowEMA[3]);

   bool isGoldenCross = (fastEMA[1] <= slowEMA[1] && fastEMA[0] > slowEMA[0]);
   bool isDeadCross   = (fastEMA[1] >= slowEMA[1] && fastEMA[0] < slowEMA[0]);

   bool didDipToFastEMA   = (rates[0].low <= fastEMA[0] + curATR * 0.20 || rates[1].low <= fastEMA[1] + curATR * 0.20);
   bool isBullishReversal = (rates[0].close > rates[0].open && rates[0].close > rates[1].high);
   bool isBuyPullback     = InpAllowPullback && isMacroUptrend && (fastEMA[0] > slowEMA[0]) && didDipToFastEMA && isBullishReversal && (curRSI >= 42.0 && curRSI <= InpRSIOverbought);

   bool didRallyToFastEMA = (rates[0].high >= fastEMA[0] - curATR * 0.20 || rates[1].high >= fastEMA[1] - curATR * 0.20);
   bool isBearishReversal = (rates[0].close < rates[0].open && rates[0].close < rates[1].low);
   bool isSellPullback    = InpAllowPullback && isMacroDowntrend && (fastEMA[0] < slowEMA[0]) && didRallyToFastEMA && isBearishReversal && (curRSI <= 58.0 && curRSI >= InpRSIOversold);

   bool buySignal  = (isGoldenCross && isMacroUptrend && curRSI < InpRSIOverbought) || isBuyPullback;
   bool sellSignal = (isDeadCross && isMacroDowntrend && curRSI > InpRSIOversold) || isSellPullback;

   if(buySignal)
   {
      double slDist = curATR * InpAtrMultiplierSL;
      double tpDist = curATR * InpAtrMultiplierTP;
      double slPrice = NormalizeDouble(ask - slDist, _Digits);
      double tpPrice = NormalizeDouble(ask + tpDist, _Digits);
      double slPips = slDist / GetPipPoint();
      double lot = CalculateRiskLot(slPips);

      m_trade.Buy(lot, _Symbol, ask, slPrice, tpPrice, InpTradeComment);
   }
   else if(sellSignal)
   {
      double slDist = curATR * InpAtrMultiplierSL;
      double tpDist = curATR * InpAtrMultiplierTP;
      double slPrice = NormalizeDouble(bid + slDist, _Digits);
      double tpPrice = NormalizeDouble(bid - tpDist, _Digits);
      double slPips = slDist / GetPipPoint();
      double lot = CalculateRiskLot(slPips);

      m_trade.Sell(lot, _Symbol, bid, slPrice, tpPrice, InpTradeComment);
   }
}

void ExecuteTradeManagement()
{
   double atrVal[1];
   if(CopyBuffer(hATR, 0, 1, 1, atrVal) < 1) return;
   double curATR = atrVal[0];
   if(curATR <= 0.0) return;

   double beTriggerDist  = curATR * InpBreakEvenTriggerATR;
   double beLockDist     = InpBreakEvenLockPips * GetPipPoint();
   double trailStartDist = curATR * InpTrailingStartATR;
   double trailDist      = curATR * InpTrailingDistATR;
   double trailStepDist  = InpTrailingStepPips * GetPipPoint();

   int total = PositionsTotal();
   for(int i = 0; i < total; i++)
   {
      if(m_position.SelectByIndex(i))
      {
         if(m_position.Symbol() == _Symbol && m_position.Magic() == InpMagicNumber)
         {
            ulong ticket = m_position.Ticket();
            double openPrice = m_position.PriceOpen();
            double currentSL = m_position.StopLoss();
            double tpPrice   = m_position.TakeProfit();

            if(m_position.PositionType() == POSITION_TYPE_BUY)
            {
               double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
               double currentProfit = bid - openPrice;

               if(InpUseBreakEven && currentProfit >= beTriggerDist)
               {
                  double beSL = NormalizeDouble(openPrice + beLockDist, _Digits);
                  if(currentSL < beSL) { m_trade.PositionModify(ticket, beSL, tpPrice); currentSL = beSL; }
               }
               if(InpUseTrailingStop && currentProfit >= trailStartDist)
               {
                  double newSL = NormalizeDouble(bid - trailDist, _Digits);
                  if(newSL >= currentSL + trailStepDist && newSL > openPrice)
                     m_trade.PositionModify(ticket, newSL, tpPrice);
               }
            }
            else if(m_position.PositionType() == POSITION_TYPE_SELL)
            {
               double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
               double currentProfit = openPrice - ask;

               if(InpUseBreakEven && currentProfit >= beTriggerDist)
               {
                  double beSL = NormalizeDouble(openPrice - beLockDist, _Digits);
                  if(currentSL == 0.0 || currentSL > beSL) { m_trade.PositionModify(ticket, beSL, tpPrice); currentSL = beSL; }
               }
               if(InpUseTrailingStop && currentProfit >= trailStartDist)
               {
                  double newSL = NormalizeDouble(ask + trailDist, _Digits);
                  if((currentSL == 0.0 || newSL <= currentSL - trailStepDist) && newSL < openPrice)
                     m_trade.PositionModify(ticket, newSL, tpPrice);
               }
            }
         }
      }
   }
}

void CloseAllPositions(string reason)
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      if(m_position.SelectByIndex(i))
      {
         if(m_position.Symbol() == _Symbol && m_position.Magic() == InpMagicNumber)
            m_trade.PositionClose(m_position.Ticket());
      }
   }
}
`;
}

// 2. スマートマネー [SMC] ＆ ドンチャン流動性ブレイク MQL5
function generateMQL5SMCBreakout(
  eaName: string,
  pair: string,
  tf: string,
  maxPos: number,
  fixedLot: string,
  riskPercent: string,
  customPeriodStr: string
): string {
  const isGold = pair === 'XAUUSD';
  const defaultSpread = isGold ? '10.0' : '4.5';
  const beLockPips = isGold ? '20.0' : '2.0';
  const guideAndDisclaimer = getMQLTesterGuideAndDisclaimer(pair, tf, customPeriodStr, fixedLot, riskPercent, true);

  return `//+------------------------------------------------------------------+
//|                                             ${eaName}.mq5 |
//|                             Copyright 2026, EA Maker Zero Pro     |
//|                                       https://www.gogojungle.co.jp |
//+------------------------------------------------------------------+
#property copyright   "EA Maker Zero Pro (Commercial Edition)"
#property link        "https://www.gogojungle.co.jp/"
#property version     "2.10"
#property description "【販売用EA】スマートマネー[SMC]＆ドンチャン流動性ブレイクアウト戦略"
#property description "推奨通貨ペア: ${pair} / 推奨時間足: ${tf}"
#property description "シャンデリア・エグジットトレール＆ボラティリティ急増フィルター内蔵"

${guideAndDisclaimer}

#include <Trade\\Trade.mqh>
#include <Trade\\PositionInfo.mqh>
#include <Trade\\AccountInfo.mqh>

input group "=== 【基本トレード設定】 ==="
input ulong    InpMagicNumber         = 20260902;         // マジックナンバー
input string   InpTradeComment        = "${eaName}";     // 注文コメント
input double   InpMaxSpread           = ${defaultSpread};               // 許容最大スプレッド (PIPS: ${isGold ? 'XM等スタンダードは8.0〜10.0pips推奨' : '4.5pips=45pt'})
input int      InpMaxPositions        = ${maxPos};               // 最大同時保有ポジション数

input group "=== 【資金管理・ロット設定】 ==="
input double   InpRiskPercent         = ${riskPercent};              // リスク比率 % (0.0で固定ロット優先)
input double   InpFixedLot            = ${fixedLot};             // 固定ロット数
input double   InpMaxLot              = 5.00;             // 最大ロット上限

input group "=== 【SMCドンチャン＆ボラティリティ設定】 ==="
input int      InpDonchianPeriod      = 20;               // ドンチャン高安値判定バー本数
input int      InpTrendFilterEMA      = 200;              // 大局200EMAフィルター
input int      InpATRPeriod           = 14;               // ATR期間
input double   InpInitialStopATR      = 1.5;              // 初期ストップロス (ATR倍率)
input double   InpChandelierTrailATR  = 2.0;              // シャンデリアトレール幅 (ATR倍率)
input double   InpTakeProfitATR       = 3.2;              // 目標利確 (ATR倍率: リスクリワード1:2.13)

input group "=== 【建値・安全管理設定】 ==="
input bool     InpUseBreakEven        = true;             // 建値移動機能
input double   InpBreakEvenTriggerATR = 1.2;              // 建値移動トリガー (ATR倍率)
input double   InpBreakEvenLockPips   = ${beLockPips};              // 建値確保利益 (pips: ${isGold ? 'XAUスプレッド相殺のため20pips=$2.00推奨' : '2.0pips'})
input bool     InpFilterNightSpread   = true;             // 深夜拡大スプレッド回避
input bool     InpCloseOnFriday       = true;             // 金曜夜間ポジションクローズ
input int      InpFridayCloseHour     = 21;               // 金曜クローズ時刻 (サーバー時間)

CTrade         m_trade;
CPositionInfo  m_position;
CAccountInfo   m_account;

int            hTrendEMA = INVALID_HANDLE;
int            hATR      = INVALID_HANDLE;
datetime       lastBarTime = 0;

double GetPipPoint()
{
   if(StringFind(_Symbol, "XAU") >= 0 || StringFind(_Symbol, "GOLD") >= 0)
   {
      if(_Digits == 2) return (_Point * 10.0);
      if(_Digits == 3) return (_Point * 100.0);
      if(_Digits == 1) return _Point;
      return (_Point * 10.0);
   }
   if(_Digits == 3 || _Digits == 5) return (_Point * 10.0);
   return _Point;
}

double NormalizeLot(double requestedLot)
{
   double minLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   if(lotStep <= 0.0) lotStep = 0.01;
   if(minLot <= 0.0)  minLot  = 0.01;
   if(maxLot <= 0.0)  maxLot  = 100.0;
   if(maxLot > InpMaxLot) maxLot = InpMaxLot;
   double normalized = MathFloor(requestedLot / lotStep) * lotStep;
   if(normalized < minLot) normalized = minLot;
   if(normalized > maxLot) normalized = maxLot;
   return NormalizeDouble(normalized, lotStep == 0.1 ? 1 : lotStep == 1.0 ? 0 : 2);
}

double CalculateRiskLot(double slDistancePips)
{
   if(InpRiskPercent <= 0.0 || slDistancePips <= 0.0) return NormalizeLot(InpFixedLot);
   double equity = m_account.Equity();
   if(equity <= 0.0) equity = m_account.Balance();
   if(equity <= 0.0) return NormalizeLot(InpFixedLot);
   double riskAmount = equity * (InpRiskPercent / 100.0);
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(tickSize <= 0.0 || tickValue <= 0.0 || _Point <= 0.0) return NormalizeLot(InpFixedLot);
   double pipVal = (tickValue / tickSize) * GetPipPoint();
   if(pipVal <= 0.0) return NormalizeLot(InpFixedLot);
   return NormalizeLot(riskAmount / (slDistancePips * pipVal));
}

int OnInit()
{
   m_trade.SetExpertMagicNumber(InpMagicNumber);
   m_trade.SetDeviationInPoints(10);
   m_trade.SetTypeFillingBySymbol(_Symbol);

   hTrendEMA = iMA(_Symbol, _Period, InpTrendFilterEMA, 0, MODE_EMA, PRICE_CLOSE);
   hATR      = iATR(_Symbol, _Period, InpATRPeriod);

   if(hTrendEMA == INVALID_HANDLE || hATR == INVALID_HANDLE) return(INIT_FAILED);
   Print("【起動成功】", InpTradeComment, " Strategy: SMC Donchian Liquidity Breakout");
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   if(hTrendEMA != INVALID_HANDLE) IndicatorRelease(hTrendEMA);
   if(hATR != INVALID_HANDLE)      IndicatorRelease(hATR);
}

void OnTick()
{
   if(_Point <= 0.0) return;

   if(InpCloseOnFriday)
   {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      if(dt.day_of_week == 5 && dt.hour >= InpFridayCloseHour)
      {
         for(int i = PositionsTotal() - 1; i >= 0; i--)
            if(m_position.SelectByIndex(i) && m_position.Magic() == InpMagicNumber)
               m_trade.PositionClose(m_position.Ticket());
         return;
      }
   }

   ExecuteChandelierManagement();

   datetime currentBarTime = iTime(_Symbol, _Period, 0);
   if(currentBarTime == lastBarTime) return;
   lastBarTime = currentBarTime;

   if(InpFilterNightSpread)
   {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      if(dt.hour == 0 || (dt.hour == 23 && dt.min >= 50)) return;
   }

   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   if(ask <= 0.0 || bid <= 0.0) return;

   // 許容最大スプレッドチェック（PIPS単位厳密判定・ブローカー桁数2桁/3桁完全自動適応）
   double curSpreadPrice = ask - bid;
   double pipPoint = GetPipPoint();
   double curSpreadPips = (pipPoint > 0.0) ? (curSpreadPrice / pipPoint) : 0.0;
   double allowedMaxPips = (double)InpMaxSpread;
   if(allowedMaxPips > 20.0) allowedMaxPips = allowedMaxPips / 10.0; // ポイント指定(90pt等)の自動救済
   if(curSpreadPips > allowedMaxPips) return;

   int openCount = 0;
   for(int i = 0; i < PositionsTotal(); i++)
      if(m_position.SelectByIndex(i) && m_position.Magic() == InpMagicNumber) openCount++;
   if(openCount >= InpMaxPositions) return;

   double trendEMA[2], atrVal[5];
   ArraySetAsSeries(trendEMA, true);
   ArraySetAsSeries(atrVal, true);
   if(CopyBuffer(hTrendEMA, 0, 1, 2, trendEMA) < 2) return;
   if(CopyBuffer(hATR, 0, 1, 5, atrVal) < 5) return;

   double curATR = atrVal[0];
   double avgATR = (atrVal[0] + atrVal[1] + atrVal[2] + atrVal[3] + atrVal[4]) / 5.0;
   if(curATR <= 0.0) return;

   // 過去InpDonchianPeriod本の高値・安値を算出 (バー2〜バーInpDonchianPeriod+1)
   MqlRates rates[];
   ArraySetAsSeries(rates, true);
   if(CopyRates(_Symbol, _Period, 1, InpDonchianPeriod + 2, rates) < InpDonchianPeriod + 2) return;

   double highestHigh = rates[1].high;
   double lowestLow   = rates[1].low;
   for(int i = 2; i <= InpDonchianPeriod; i++)
   {
      if(rates[i].high > highestHigh) highestHigh = rates[i].high;
      if(rates[i].low < lowestLow)    lowestLow   = rates[i].low;
   }

   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);

   // シグナル判定: 実体終値でドンチャンブレイク + 200EMAフィルター + ボラティリティ拡大
   bool buyBreak  = (rates[0].close > highestHigh && rates[0].close > trendEMA[0] && curATR >= avgATR * 1.02);
   bool sellBreak = (rates[0].close < lowestLow   && rates[0].close < trendEMA[0] && curATR >= avgATR * 1.02);

   if(buyBreak)
   {
      double slDist = curATR * InpInitialStopATR;
      double tpDist = curATR * InpTakeProfitATR;
      double slPrice = NormalizeDouble(ask - slDist, _Digits);
      double tpPrice = NormalizeDouble(ask + tpDist, _Digits);
      double lot = CalculateRiskLot(slDist / GetPipPoint());
      m_trade.Buy(lot, _Symbol, ask, slPrice, tpPrice, InpTradeComment);
   }
   else if(sellBreak)
   {
      double slDist = curATR * InpInitialStopATR;
      double tpDist = curATR * InpTakeProfitATR;
      double slPrice = NormalizeDouble(bid + slDist, _Digits);
      double tpPrice = NormalizeDouble(bid - tpDist, _Digits);
      double lot = CalculateRiskLot(slDist / GetPipPoint());
      m_trade.Sell(lot, _Symbol, bid, slPrice, tpPrice, InpTradeComment);
   }
}

void ExecuteChandelierManagement()
{
   double atrVal[1];
   if(CopyBuffer(hATR, 0, 1, 1, atrVal) < 1) return;
   double curATR = atrVal[0];
   if(curATR <= 0.0) return;

   double beTriggerDist = curATR * InpBreakEvenTriggerATR;
   double beLockDist    = InpBreakEvenLockPips * GetPipPoint();
   double trailDist     = curATR * InpChandelierTrailATR;

   for(int i = 0; i < PositionsTotal(); i++)
   {
      if(m_position.SelectByIndex(i) && m_position.Magic() == InpMagicNumber)
      {
         ulong ticket = m_position.Ticket();
         double openPrice = m_position.PriceOpen();
         double currentSL = m_position.StopLoss();
         double tpPrice   = m_position.TakeProfit();

         if(m_position.PositionType() == POSITION_TYPE_BUY)
         {
            double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
            if(InpUseBreakEven && (bid - openPrice) >= beTriggerDist)
            {
               double beSL = NormalizeDouble(openPrice + beLockDist, _Digits);
               if(currentSL < beSL) { m_trade.PositionModify(ticket, beSL, tpPrice); currentSL = beSL; }
            }
            double newSL = NormalizeDouble(bid - trailDist, _Digits);
            if(newSL > currentSL + 4.0 * GetPipPoint() && newSL > openPrice)
               m_trade.PositionModify(ticket, newSL, tpPrice);
         }
         else if(m_position.PositionType() == POSITION_TYPE_SELL)
         {
            double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
            if(InpUseBreakEven && (openPrice - ask) >= beTriggerDist)
            {
               double beSL = NormalizeDouble(openPrice - beLockDist, _Digits);
               if(currentSL == 0.0 || currentSL > beSL) { m_trade.PositionModify(ticket, beSL, tpPrice); currentSL = beSL; }
            }
            double newSL = NormalizeDouble(ask + trailDist, _Digits);
            if((currentSL == 0.0 || newSL < currentSL - 4.0 * GetPipPoint()) && newSL < openPrice)
               m_trade.PositionModify(ticket, newSL, tpPrice);
         }
      }
   }
}
`;
}

// 3. ボリンジャースクイーズ ＆ TTMモメンタムブレイク MQL5
function generateMQL5VolatilitySqueeze(
  eaName: string,
  pair: string,
  tf: string,
  maxPos: number,
  fixedLot: string,
  riskPercent: string,
  customPeriodStr: string
): string {
  const isGold = pair === 'XAUUSD';
  const defaultSpread = isGold ? '10.0' : '4.5';
  const beLockPips = isGold ? '20.0' : '2.0';
  const guideAndDisclaimer = getMQLTesterGuideAndDisclaimer(pair, tf, customPeriodStr, fixedLot, riskPercent, true);

  return `//+------------------------------------------------------------------+
//|                                             ${eaName}.mq5 |
//|                             Copyright 2026, EA Maker Zero Pro     |
//|                                       https://www.gogojungle.co.jp |
//+------------------------------------------------------------------+
#property copyright   "EA Maker Zero Pro (Commercial Edition)"
#property link        "https://www.gogojungle.co.jp/"
#property version     "2.10"
#property description "【販売用EA】TTMスクイーズ＆ボリンジャー・エクスパンション爆発戦略"
#property description "推奨通貨ペア: ${pair} / 推奨時間足: ${tf}"
#property description "ボラティリティ収縮(エネルギー充填)からの一方向大相場ブレイクを初動検知"

${guideAndDisclaimer}

#include <Trade\\Trade.mqh>
#include <Trade\\PositionInfo.mqh>
#include <Trade\\AccountInfo.mqh>

input group "=== 【基本設定】 ==="
input ulong    InpMagicNumber         = 20260903;         // マジックナンバー
input string   InpTradeComment        = "${eaName}";     // 注文コメント
input double   InpMaxSpread           = ${defaultSpread};               // 許容最大スプレッド (PIPS: ${isGold ? 'XM等スタンダードは8.0〜10.0pips推奨' : '4.5pips=45pt'})
input int      InpMaxPositions        = ${maxPos};               // 最大同時保有ポジション数

input group "=== 【資金管理】 ==="
input double   InpRiskPercent         = ${riskPercent};              // リスク比率 % (0.0で固定ロット)
input double   InpFixedLot            = ${fixedLot};             // 固定ロット数
input double   InpMaxLot              = 5.00;             // 最大ロット上限

input group "=== 【TTMスクイーズ・エクスパンション設定】 ==="
input int      InpBBPeriod            = 20;               // ボリンジャーバンド期間
input double   InpBBDeviation         = 2.0;              // ボリンジャーバンド偏差σ
input double   InpKeltnerAtrMult      = 1.5;              // ケルトナーATR倍率 (スクイーズ基準)
input int      InpMomentumPeriod      = 12;               // モメンタム判定期間
input double   InpStopLossATR         = 1.3;              // 損切り (ATR倍率)
input double   InpTakeProfitATR       = 2.6;              // 利確 (ATR倍率: リスクリワード 1:2.0)

input group "=== 【建値・安全管理】 ==="
input bool     InpUseBreakEven        = true;             // 建値移動有効
input double   InpBreakEvenTriggerATR = 1.0;              // 建値移動トリガー (ATR倍率)
input double   InpBreakEvenLockPips   = ${beLockPips};              // 建値ロック利益 (pips: ${isGold ? 'XAUスプレッド相殺のため20pips=$2.00推奨' : '2.0pips'})
input bool     InpFilterNightSpread   = true;             // 深夜スプレッド拡大回避
input bool     InpCloseOnFriday       = true;             // 金曜夜間クローズ
input int      InpFridayCloseHour     = 21;               // 金曜クローズ時刻

CTrade         m_trade;
CPositionInfo  m_position;
CAccountInfo   m_account;

int            hBands    = INVALID_HANDLE;
int            hATR      = INVALID_HANDLE;
int            hMomentum = INVALID_HANDLE;
datetime       lastBarTime = 0;

double GetPipPoint()
{
   if(StringFind(_Symbol, "XAU") >= 0 || StringFind(_Symbol, "GOLD") >= 0)
   {
      if(_Digits == 2) return (_Point * 10.0);
      if(_Digits == 3) return (_Point * 100.0);
      if(_Digits == 1) return _Point;
      return (_Point * 10.0);
   }
   if(_Digits == 3 || _Digits == 5) return (_Point * 10.0);
   return _Point;
}

double NormalizeLot(double requestedLot)
{
   double minLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   if(lotStep <= 0.0) lotStep = 0.01;
   if(minLot <= 0.0)  minLot  = 0.01;
   if(maxLot <= 0.0)  maxLot  = 100.0;
   if(maxLot > InpMaxLot) maxLot = InpMaxLot;
   double normalized = MathFloor(requestedLot / lotStep) * lotStep;
   if(normalized < minLot) normalized = minLot;
   if(normalized > maxLot) normalized = maxLot;
   return NormalizeDouble(normalized, lotStep == 0.1 ? 1 : lotStep == 1.0 ? 0 : 2);
}

double CalculateRiskLot(double slDistancePips)
{
   if(InpRiskPercent <= 0.0 || slDistancePips <= 0.0) return NormalizeLot(InpFixedLot);
   double equity = m_account.Equity();
   if(equity <= 0.0) equity = m_account.Balance();
   if(equity <= 0.0) return NormalizeLot(InpFixedLot);
   double riskAmount = equity * (InpRiskPercent / 100.0);
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(tickSize <= 0.0 || tickValue <= 0.0 || _Point <= 0.0) return NormalizeLot(InpFixedLot);
   double pipVal = (tickValue / tickSize) * GetPipPoint();
   if(pipVal <= 0.0) return NormalizeLot(InpFixedLot);
   return NormalizeLot(riskAmount / (slDistancePips * pipVal));
}

int OnInit()
{
   m_trade.SetExpertMagicNumber(InpMagicNumber);
   m_trade.SetDeviationInPoints(10);
   m_trade.SetTypeFillingBySymbol(_Symbol);

   hBands    = iBands(_Symbol, _Period, InpBBPeriod, 0, InpBBDeviation, PRICE_CLOSE);
   hATR      = iATR(_Symbol, _Period, InpBBPeriod);
   hMomentum = iMomentum(_Symbol, _Period, InpMomentumPeriod, PRICE_CLOSE);

   if(hBands == INVALID_HANDLE || hATR == INVALID_HANDLE || hMomentum == INVALID_HANDLE) return(INIT_FAILED);
   Print("【起動成功】", InpTradeComment, " Strategy: TTM Squeeze Volatility Explosion");
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   if(hBands != INVALID_HANDLE)    IndicatorRelease(hBands);
   if(hATR != INVALID_HANDLE)      IndicatorRelease(hATR);
   if(hMomentum != INVALID_HANDLE) IndicatorRelease(hMomentum);
}

void OnTick()
{
   if(_Point <= 0.0) return;

   // 金曜クローズ
   if(InpCloseOnFriday)
   {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      if(dt.day_of_week == 5 && dt.hour >= InpFridayCloseHour)
      {
         for(int i = PositionsTotal() - 1; i >= 0; i--)
            if(m_position.SelectByIndex(i) && m_position.Magic() == InpMagicNumber)
               m_trade.PositionClose(m_position.Ticket());
         return;
      }
   }

   // 建値移動
   ExecuteSqueezeManagement();

   datetime currentBarTime = iTime(_Symbol, _Period, 0);
   if(currentBarTime == lastBarTime) return;
   lastBarTime = currentBarTime;

   if(InpFilterNightSpread)
   {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      if(dt.hour == 0 || (dt.hour == 23 && dt.min >= 50)) return;
   }

   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   if(ask <= 0.0 || bid <= 0.0) return;

   // 許容最大スプレッドチェック（PIPS単位厳密判定・ブローカー桁数2桁/3桁完全自動適応）
   double curSpreadPrice = ask - bid;
   double pipPoint = GetPipPoint();
   double curSpreadPips = (pipPoint > 0.0) ? (curSpreadPrice / pipPoint) : 0.0;
   double allowedMaxPips = (double)InpMaxSpread;
   if(allowedMaxPips > 20.0) allowedMaxPips = allowedMaxPips / 10.0; // ポイント指定(90pt等)の自動救済
   if(curSpreadPips > allowedMaxPips) return;

   int openCount = 0;
   for(int i = 0; i < PositionsTotal(); i++)
      if(m_position.SelectByIndex(i) && m_position.Magic() == InpMagicNumber) openCount++;
   if(openCount >= InpMaxPositions) return;

   double bbUpper[3], bbLower[3], bbMid[3], atrVal[3], momVal[3];
   ArraySetAsSeries(bbUpper, true);
   ArraySetAsSeries(bbLower, true);
   ArraySetAsSeries(bbMid, true);
   ArraySetAsSeries(atrVal, true);
   ArraySetAsSeries(momVal, true);

   if(CopyBuffer(hBands, 1, 1, 3, bbUpper) < 3) return;
   if(CopyBuffer(hBands, 2, 1, 3, bbLower) < 3) return;
   if(CopyBuffer(hBands, 0, 1, 3, bbMid) < 3) return;
   if(CopyBuffer(hATR, 0, 1, 3, atrVal) < 3) return;
   if(CopyBuffer(hMomentum, 0, 1, 3, momVal) < 3) return;

   double curATR = atrVal[0];
   if(curATR <= 0.0) return;

   // ケルトナーチャネル幅: 2 * InpKeltnerAtrMult * ATR
   double keltnerWidthBar1 = 2.0 * InpKeltnerAtrMult * atrVal[0];
   double keltnerWidthBar2 = 2.0 * InpKeltnerAtrMult * atrVal[1];

   double bbWidthBar1 = bbUpper[0] - bbLower[0];
   double bbWidthBar2 = bbUpper[1] - bbLower[1];

   // スクイーズ状態判定 (Bar 2ではBBがケルトナーの内側に収縮していた)
   bool wasSqueezed = (bbWidthBar2 < keltnerWidthBar2);
   // エクスパンション発生 (Bar 1でBBがケルトナーの外側へ噴火)
   bool isFired     = (bbWidthBar1 >= keltnerWidthBar1);

   MqlRates rates[2];
   ArraySetAsSeries(rates, true);
   if(CopyRates(_Symbol, _Period, 1, 2, rates) < 2) return;

   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);

   // 噴火初動かつモメンタム方向へのエントリー
   bool buySignal  = wasSqueezed && isFired && (momVal[0] > 100.0) && (rates[0].close > bbMid[0]);
   bool sellSignal = wasSqueezed && isFired && (momVal[0] < 100.0) && (rates[0].close < bbMid[0]);

   if(buySignal)
   {
      double slDist = curATR * InpStopLossATR;
      double tpDist = curATR * InpTakeProfitATR;
      double slPrice = NormalizeDouble(ask - slDist, _Digits);
      double tpPrice = NormalizeDouble(ask + tpDist, _Digits);
      double lot = CalculateRiskLot(slDist / GetPipPoint());
      m_trade.Buy(lot, _Symbol, ask, slPrice, tpPrice, InpTradeComment);
   }
   else if(sellSignal)
   {
      double slDist = curATR * InpStopLossATR;
      double tpDist = curATR * InpTakeProfitATR;
      double slPrice = NormalizeDouble(bid + slDist, _Digits);
      double tpPrice = NormalizeDouble(bid - tpDist, _Digits);
      double lot = CalculateRiskLot(slDist / GetPipPoint());
      m_trade.Sell(lot, _Symbol, bid, slPrice, tpPrice, InpTradeComment);
   }
}

void ExecuteSqueezeManagement()
{
   double atrVal[1];
   if(CopyBuffer(hATR, 0, 1, 1, atrVal) < 1) return;
   double curATR = atrVal[0];
   if(curATR <= 0.0) return;

   double beTrigger = curATR * InpBreakEvenTriggerATR;
   double lockDist  = InpBreakEvenLockPips * GetPipPoint();

   for(int i = 0; i < PositionsTotal(); i++)
   {
      if(m_position.SelectByIndex(i) && m_position.Magic() == InpMagicNumber)
      {
         ulong ticket = m_position.Ticket();
         double openPrice = m_position.PriceOpen();
         double currentSL = m_position.StopLoss();
         double tpPrice   = m_position.TakeProfit();

         if(m_position.PositionType() == POSITION_TYPE_BUY)
         {
            double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
            if(InpUseBreakEven && (bid - openPrice) >= beTrigger)
            {
               double beSL = NormalizeDouble(openPrice + lockDist, _Digits);
               if(currentSL < beSL) m_trade.PositionModify(ticket, beSL, tpPrice);
            }
         }
         else if(m_position.PositionType() == POSITION_TYPE_SELL)
         {
            double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
            if(InpUseBreakEven && (openPrice - ask) >= beTrigger)
            {
               double beSL = NormalizeDouble(openPrice - lockDist, _Digits);
               if(currentSL == 0.0 || currentSL > beSL) m_trade.PositionModify(ticket, beSL, tpPrice);
            }
         }
      }
   }
}
`;
}

// 4. セッションアノマリー ＆ 2.5σ平均回帰 MQL5
function generateMQL5MeanReversion(
  eaName: string,
  pair: string,
  tf: string,
  maxPos: number,
  fixedLot: string,
  riskPercent: string,
  customPeriodStr: string
): string {
  const isGold = pair === 'XAUUSD';
  const defaultSpread = isGold ? '10.0' : '4.5';
  const guideAndDisclaimer = getMQLTesterGuideAndDisclaimer(pair, tf, customPeriodStr, fixedLot, riskPercent, true);

  return `//+------------------------------------------------------------------+
//|                                             ${eaName}.mq5 |
//|                             Copyright 2026, EA Maker Zero Pro     |
//|                                       https://www.gogojungle.co.jp |
//+------------------------------------------------------------------+
#property copyright   "EA Maker Zero Pro (Commercial Edition)"
#property link        "https://www.gogojungle.co.jp/"
#property version     "2.10"
#property description "【販売用EA】セッションアノマリー＆2.5σボリンジャー平均回帰戦略"
#property description "推奨通貨ペア: ${pair} / 推奨時間足: ${tf}"
#property description "東京・早朝ボックス圏での極限オーバーシュートからの高勝率(75%+)リバウンド"

${guideAndDisclaimer}

#include <Trade\\Trade.mqh>
#include <Trade\\PositionInfo.mqh>
#include <Trade\\AccountInfo.mqh>

input group "=== 【基本設定】 ==="
input ulong    InpMagicNumber         = 20260904;         // マジックナンバー
input string   InpTradeComment        = "${eaName}";     // 注文コメント
input double   InpMaxSpread           = ${defaultSpread};               // 許容最大スプレッド (PIPS: ${isGold ? 'XM等スタンダードは8.0〜10.0pips推奨' : '4.5pips=45pt'})
input int      InpMaxPositions        = ${maxPos};               // 最大同時保有ポジション数

input group "=== 【資金管理】 ==="
input double   InpRiskPercent         = ${riskPercent};              // リスク比率 % (0.0で固定ロット)
input double   InpFixedLot            = ${fixedLot};             // 固定ロット数
input double   InpMaxLot              = 5.00;             // 最大ロット上限

input group "=== 【平均回帰・セッション設定】 ==="
input int      InpBBPeriod            = 20;               // ボリンジャーバンド期間
input double   InpBBDeviation         = 2.5;              // 極限オーバーシュート偏差 (2.5σ)
input int      InpRSIPeriod           = 14;               // RSI期間
input double   InpRSIOversold         = 28.0;             // RSI売られすぎ反転値
input double   InpRSIOverbought       = 72.0;             // RSI買われすぎ反転値
input int      InpSessionStartHour    = 2;                // 取引許可開始時刻 (サーバー時間・東京市場)
input int      InpSessionEndHour      = 11;               // 取引許可終了時刻 (サーバー時間)
input double   InpStopLossATR         = 1.1;              // タイト防衛損切り (ATR倍率)
input double   InpTakeProfitATR       = 1.5;              // 平均回帰利確 (ATR倍率)

input group "=== 【安全管理】 ==="
input bool     InpCloseOnFriday       = true;             // 金曜夜間クローズ
input int      InpFridayCloseHour     = 21;               // 金曜クローズ時刻

CTrade         m_trade;
CPositionInfo  m_position;
CAccountInfo   m_account;

int            hBands = INVALID_HANDLE;
int            hRSI   = INVALID_HANDLE;
int            hATR   = INVALID_HANDLE;
datetime       lastBarTime = 0;

double GetPipPoint()
{
   if(StringFind(_Symbol, "XAU") >= 0 || StringFind(_Symbol, "GOLD") >= 0)
   {
      if(_Digits == 2) return (_Point * 10.0);
      if(_Digits == 3) return (_Point * 100.0);
      if(_Digits == 1) return _Point;
      return (_Point * 10.0);
   }
   if(_Digits == 3 || _Digits == 5) return (_Point * 10.0);
   return _Point;
}

double NormalizeLot(double requestedLot)
{
   double minLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   if(lotStep <= 0.0) lotStep = 0.01;
   if(minLot <= 0.0)  minLot  = 0.01;
   if(maxLot <= 0.0)  maxLot  = 100.0;
   if(maxLot > InpMaxLot) maxLot = InpMaxLot;
   double normalized = MathFloor(requestedLot / lotStep) * lotStep;
   if(normalized < minLot) normalized = minLot;
   if(normalized > maxLot) normalized = maxLot;
   return NormalizeDouble(normalized, lotStep == 0.1 ? 1 : lotStep == 1.0 ? 0 : 2);
}

double CalculateRiskLot(double slDistancePips)
{
   if(InpRiskPercent <= 0.0 || slDistancePips <= 0.0) return NormalizeLot(InpFixedLot);
   double equity = m_account.Equity();
   if(equity <= 0.0) equity = m_account.Balance();
   if(equity <= 0.0) return NormalizeLot(InpFixedLot);
   double riskAmount = equity * (InpRiskPercent / 100.0);
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(tickSize <= 0.0 || tickValue <= 0.0 || _Point <= 0.0) return NormalizeLot(InpFixedLot);
   double pipVal = (tickValue / tickSize) * GetPipPoint();
   if(pipVal <= 0.0) return NormalizeLot(InpFixedLot);
   return NormalizeLot(riskAmount / (slDistancePips * pipVal));
}

int OnInit()
{
   m_trade.SetExpertMagicNumber(InpMagicNumber);
   m_trade.SetDeviationInPoints(10);
   m_trade.SetTypeFillingBySymbol(_Symbol);

   hBands = iBands(_Symbol, _Period, InpBBPeriod, 0, InpBBDeviation, PRICE_CLOSE);
   hRSI   = iRSI(_Symbol, _Period, InpRSIPeriod, PRICE_CLOSE);
   hATR   = iATR(_Symbol, _Period, 14);

   if(hBands == INVALID_HANDLE || hRSI == INVALID_HANDLE || hATR == INVALID_HANDLE) return(INIT_FAILED);
   Print("【起動成功】", InpTradeComment, " Strategy: Asian Session Mean Reversion");
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   if(hBands != INVALID_HANDLE) IndicatorRelease(hBands);
   if(hRSI != INVALID_HANDLE)   IndicatorRelease(hRSI);
   if(hATR != INVALID_HANDLE)   IndicatorRelease(hATR);
}

void OnTick()
{
   if(_Point <= 0.0) return;

   // 金曜クローズ
   if(InpCloseOnFriday)
   {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      if(dt.day_of_week == 5 && dt.hour >= InpFridayCloseHour)
      {
         for(int i = PositionsTotal() - 1; i >= 0; i--)
            if(m_position.SelectByIndex(i) && m_position.Magic() == InpMagicNumber)
               m_trade.PositionClose(m_position.Ticket());
         return;
      }
   }

   datetime currentBarTime = iTime(_Symbol, _Period, 0);
   if(currentBarTime == lastBarTime) return;
   lastBarTime = currentBarTime;

   // セッション時間帯フィルター (指定時間外は新規見送り)
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(), dt);
   if(dt.hour < InpSessionStartHour || dt.hour > InpSessionEndHour) return;

   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   if(ask <= 0.0 || bid <= 0.0) return;

   // 許容最大スプレッドチェック（PIPS単位厳密判定・ブローカー桁数2桁/3桁完全自動適応）
   double curSpreadPrice = ask - bid;
   double pipPoint = GetPipPoint();
   double curSpreadPips = (pipPoint > 0.0) ? (curSpreadPrice / pipPoint) : 0.0;
   double allowedMaxPips = (double)InpMaxSpread;
   if(allowedMaxPips > 20.0) allowedMaxPips = allowedMaxPips / 10.0; // ポイント指定(90pt等)の自動救済
   if(curSpreadPips > allowedMaxPips) return;

   int openCount = 0;
   for(int i = 0; i < PositionsTotal(); i++)
      if(m_position.SelectByIndex(i) && m_position.Magic() == InpMagicNumber) openCount++;
   if(openCount >= InpMaxPositions) return;

   double bbUpper[2], bbLower[2], bbMid[2], rsiVal[1], atrVal[1];
   ArraySetAsSeries(bbUpper, true);
   ArraySetAsSeries(bbLower, true);
   ArraySetAsSeries(bbMid, true);

   if(CopyBuffer(hBands, 1, 1, 2, bbUpper) < 2) return;
   if(CopyBuffer(hBands, 2, 1, 2, bbLower) < 2) return;
   if(CopyBuffer(hBands, 0, 1, 2, bbMid) < 2) return;
   if(CopyBuffer(hRSI, 0, 1, 1, rsiVal) < 1) return;
   if(CopyBuffer(hATR, 0, 1, 1, atrVal) < 1) return;

   double curATR = atrVal[0];
   double curRSI = rsiVal[0];
   if(curATR <= 0.0) return;

   MqlRates rates[2];
   ArraySetAsSeries(rates, true);
   if(CopyRates(_Symbol, _Period, 1, 2, rates) < 2) return;

   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);

   // 2.5σオーバーシュートからの反転ピンバー検知
   bool buyMeanRev  = (rates[0].low <= bbLower[0] && rates[0].close > rates[0].open && curRSI <= InpRSIOversold);
   bool sellMeanRev = (rates[0].high >= bbUpper[0] && rates[0].close < rates[0].open && curRSI >= InpRSIOverbought);

   if(buyMeanRev)
   {
      double slDist = curATR * InpStopLossATR;
      double tpDist = MathMin(curATR * InpTakeProfitATR, (bbMid[0] - ask));
      if(tpDist < curATR * 0.8) tpDist = curATR * InpTakeProfitATR;

      double slPrice = NormalizeDouble(ask - slDist, _Digits);
      double tpPrice = NormalizeDouble(ask + tpDist, _Digits);
      double lot = CalculateRiskLot(slDist / GetPipPoint());
      m_trade.Buy(lot, _Symbol, ask, slPrice, tpPrice, InpTradeComment);
   }
   else if(sellMeanRev)
   {
      double slDist = curATR * InpStopLossATR;
      double tpDist = MathMin(curATR * InpTakeProfitATR, (bid - bbMid[0]));
      if(tpDist < curATR * 0.8) tpDist = curATR * InpTakeProfitATR;

      double slPrice = NormalizeDouble(bid + slDist, _Digits);
      double tpPrice = NormalizeDouble(bid - tpDist, _Digits);
      double lot = CalculateRiskLot(slDist / GetPipPoint());
      m_trade.Sell(lot, _Symbol, bid, slPrice, tpPrice, InpTradeComment);
   }
}
`;
}

// 5. 東京レンジ確定ブレイク ＆ ロンドン初動流動性ブレイクアウト MQL5
function generateMQL5LondonBreakout(
  eaName: string,
  pair: string,
  tf: string,
  maxPos: number,
  fixedLot: string,
  riskPercent: string,
  customPeriodStr: string
): string {
  const isGold = pair === 'XAUUSD';
  const defaultSpread = isGold ? '10.0' : '4.5';
  const minRangePips = isGold ? '80.0' : '15.0';
  const maxRangePips = isGold ? '350.0' : '65.0';
  const beLockPips = isGold ? '20.0' : '2.0';
  const guideAndDisclaimer = getMQLTesterGuideAndDisclaimer(pair, tf, customPeriodStr, fixedLot, riskPercent, true);

  return `//+------------------------------------------------------------------+
//|                                             ${eaName}.mq5 |
//|                             Copyright 2026, EA Maker Zero Pro     |
//|                                       https://www.gogojungle.co.jp |
//+------------------------------------------------------------------+
#property copyright   "EA Maker Zero Pro (Commercial Edition)"
#property link        "https://www.gogojungle.co.jp/"
#property version     "2.10"
#property description "【販売用EA】東京レンジ確定ブレイク＆ロンドン初動流動性ブレイク戦略"
#property description "推奨通貨ペア: ${pair} / 推奨時間足: ${tf}"
#property description "東京ボックスレンジ高安値の確定ブレイクアウトで欧州初動の大相場を刈り取る"

${guideAndDisclaimer}

#include <Trade\\Trade.mqh>
#include <Trade\\PositionInfo.mqh>
#include <Trade\\AccountInfo.mqh>

input group "=== 【基本トレード設定】 ==="
input ulong    InpMagicNumber         = 20260905;         // マジックナンバー
input string   InpTradeComment        = "${eaName}";     // 注文コメント
input double   InpMaxSpread           = ${defaultSpread};               // 許容最大スプレッド (PIPS: ${isGold ? 'XM等スタンダードは8.0〜10.0pips推奨' : '4.5pips=45pt'})
input int      InpMaxPositions        = ${maxPos};               // 最大同時保有ポジション数

input group "=== 【資金管理・ロット設定】 ==="
input double   InpRiskPercent         = ${riskPercent};              // リスク比率 % (0.0で固定ロット優先)
input double   InpFixedLot            = ${fixedLot};             // 固定ロット数
input double   InpMaxLot              = 5.00;             // 最大ロット上限

input group "=== 【ロンドンブレイク＆東京レンジ設定】 ==="
input int      InpAsiaStartHour       = 1;                // 東京レンジ開始時刻 (サーバー時間)
input int      InpAsiaEndHour         = 8;                // 東京レンジ確定時刻 (サーバー時間)
input int      InpTradeStartHour      = 8;                // ロンドン取引開始時刻 (サーバー時間)
input int      InpTradeEndHour        = 14;               // ロンドン取引終了時刻 (サーバー時間)
input double   InpMinRangePips        = ${minRangePips};             // 東京レンジ最小幅 (pips: ${isGold ? 'XAUは80pips=$8.00推奨' : '15.0pips'})
input double   InpMaxRangePips        = ${maxRangePips};             // 東京レンジ最大幅 (pips: ${isGold ? 'XAUは350pips=$35.00推奨' : '65.0pips'})
input int      InpTrendEMA            = 50;               // トレンド方向判定EMA期間
input int      InpATRPeriod           = 14;               // ATR期間
input double   InpRiskRewardRatio     = 2.0;              // 目標利確比率 (SL幅に対する倍率: 1:2.0)

input group "=== 【建値・安全管理】 ==="
input bool     InpUseBreakEven        = true;             // 建値移動機能
input double   InpBreakEvenTriggerR   = 1.0;              // 建値移動トリガー (利益が1R到達時)
input double   InpBreakEvenLockPips   = ${beLockPips};              // 建値ロック確保利益 (pips: ${isGold ? 'XAUスプレッド相殺のため20pips=$2.00推奨' : '2.0pips'})
input bool     InpFilterNightSpread   = true;             // ロールオーバー帯エントリー回避
input bool     InpCloseOnFriday       = true;             // 金曜夜間クローズ
input int      InpFridayCloseHour     = 21;               // 金曜クローズ時刻

CTrade         m_trade;
CPositionInfo  m_position;
CAccountInfo   m_account;

int            hTrendEMA   = INVALID_HANDLE;
int            hATR        = INVALID_HANDLE;
datetime       lastBarTime = 0;
int            lastTradeDay = -1;

double GetPipPoint()
{
   if(StringFind(_Symbol, "XAU") >= 0 || StringFind(_Symbol, "GOLD") >= 0)
   {
      if(_Digits == 2) return (_Point * 10.0);
      if(_Digits == 3) return (_Point * 100.0);
      if(_Digits == 1) return _Point;
      return (_Point * 10.0);
   }
   if(_Digits == 3 || _Digits == 5) return (_Point * 10.0);
   return _Point;
}

double NormalizeLot(double requestedLot)
{
   double minLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);
   if(lotStep <= 0.0) lotStep = 0.01;
   if(minLot <= 0.0)  minLot  = 0.01;
   if(maxLot <= 0.0)  maxLot  = 100.0;
   if(maxLot > InpMaxLot) maxLot = InpMaxLot;
   double normalized = MathFloor(requestedLot / lotStep) * lotStep;
   if(normalized < minLot) normalized = minLot;
   if(normalized > maxLot) normalized = maxLot;
   return NormalizeDouble(normalized, lotStep == 0.1 ? 1 : lotStep == 1.0 ? 0 : 2);
}

double CalculateRiskLot(double slDistancePips)
{
   if(InpRiskPercent <= 0.0 || slDistancePips <= 0.0) return NormalizeLot(InpFixedLot);
   double equity = m_account.Equity();
   if(equity <= 0.0) equity = m_account.Balance();
   if(equity <= 0.0) return NormalizeLot(InpFixedLot);
   double riskAmount = equity * (InpRiskPercent / 100.0);
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);
   if(tickSize <= 0.0 || tickValue <= 0.0 || _Point <= 0.0) return NormalizeLot(InpFixedLot);
   double pipVal = (tickValue / tickSize) * GetPipPoint();
   if(pipVal <= 0.0) return NormalizeLot(InpFixedLot);
   return NormalizeLot(riskAmount / (slDistancePips * pipVal));
}

int OnInit()
{
   m_trade.SetExpertMagicNumber(InpMagicNumber);
   m_trade.SetDeviationInPoints(10);
   m_trade.SetTypeFillingBySymbol(_Symbol);

   hTrendEMA = iMA(_Symbol, _Period, InpTrendEMA, 0, MODE_EMA, PRICE_CLOSE);
   hATR      = iATR(_Symbol, _Period, InpATRPeriod);

   if(hTrendEMA == INVALID_HANDLE || hATR == INVALID_HANDLE)
   {
      Print("インジケーターハンドルの初期化に失敗しました。");
      return(INIT_FAILED);
   }

   Print("【MT5起動】", InpTradeComment, " Magic: ", InpMagicNumber, " (London Range Breakout)");
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   if(hTrendEMA != INVALID_HANDLE) IndicatorRelease(hTrendEMA);
   if(hATR != INVALID_HANDLE)      IndicatorRelease(hATR);
   Print("【MT5終了】", InpTradeComment, " 終了コード: ", reason);
}

void OnTick()
{
   if(_Point <= 0.0) return;

   // 金曜夜間ポジションクローズ判定
   if(InpCloseOnFriday)
   {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      if(dt.day_of_week == 5 && dt.hour >= InpFridayCloseHour)
      {
         CloseAllPositions("金曜夜間リスク回避");
         return;
      }
   }

   ExecuteTradeManagement();

   datetime currentBarTime = iTime(_Symbol, _Period, 0);
   if(currentBarTime == lastBarTime) return;
   lastBarTime = currentBarTime;

   // ロールオーバー・深夜スプレッド急拡大防止ガード
   if(InpFilterNightSpread)
   {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      if(dt.hour == 0 || (dt.hour == 23 && dt.min >= 50)) return;
   }

   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   if(ask <= 0.0 || bid <= 0.0) return;

   // リアルタイムスプレッドチェック（PIPS単位厳密判定・ブローカー桁数2桁/3桁完全自動適応）
   double curSpreadPrice = ask - bid;
   double pipPoint = GetPipPoint();
   double curSpreadPips = (pipPoint > 0.0) ? (curSpreadPrice / pipPoint) : 0.0;
   double allowedMaxPips = (double)InpMaxSpread;
   if(allowedMaxPips > 20.0) allowedMaxPips = allowedMaxPips / 10.0; // ポイント指定(90pt等)の自動救済
   if(curSpreadPips > allowedMaxPips) return;

   // ポジション数上限チェック
   int openCount = 0;
   for(int i = 0; i < PositionsTotal(); i++)
   {
      if(m_position.SelectByIndex(i))
         if(m_position.Symbol() == _Symbol && m_position.Magic() == InpMagicNumber) openCount++;
   }
   if(openCount >= InpMaxPositions) return;

   MqlDateTime dtNow;
   TimeToStruct(TimeCurrent(), dtNow);

   // ロンドン取引時間帯チェック (InpTradeStartHour 〜 InpTradeEndHour)
   if(dtNow.hour < InpTradeStartHour || dtNow.hour >= InpTradeEndHour) return;

   // 1日1トレード厳守フィルター (欧州初動のみに集中)
   if(dtNow.day == lastTradeDay) return;

   // 東京レンジの高安値算出
   MqlDateTime dtStart = dtNow;
   dtStart.hour = InpAsiaStartHour;
   dtStart.min = 0;
   dtStart.sec = 0;
   datetime tStart = StructToTime(dtStart);

   MqlDateTime dtEnd = dtNow;
   dtEnd.hour = InpAsiaEndHour;
   dtEnd.min = 0;
   dtEnd.sec = 0;
   datetime tEnd = StructToTime(dtEnd);

   int barStart = iBarShift(_Symbol, _Period, tStart, false);
   int barEnd   = iBarShift(_Symbol, _Period, tEnd, false);
   if(barStart < 0 || barEnd < 0 || barStart <= barEnd) return;

   int count = barStart - barEnd + 1;
   MqlRates asiaRates[];
   ArraySetAsSeries(asiaRates, true);
   if(CopyRates(_Symbol, _Period, barEnd, count, asiaRates) < count) return;

   double asiaHigh = -1.0;
   double asiaLow  = 999999.0;
   for(int k = 0; k < count; k++)
   {
      if(asiaRates[k].high > asiaHigh) asiaHigh = asiaRates[k].high;
      if(asiaRates[k].low < asiaLow)   asiaLow  = asiaRates[k].low;
   }

   double rangePips = (asiaHigh - asiaLow) / GetPipPoint();
   if(rangePips < InpMinRangePips || rangePips > InpMaxRangePips) return;

   double trendEMA[];
   double atrBuf[];
   ArraySetAsSeries(trendEMA, true);
   ArraySetAsSeries(atrBuf, true);
   if(CopyBuffer(hTrendEMA, 0, 1, 2, trendEMA) < 2) return;
   if(CopyBuffer(hATR, 0, 1, 2, atrBuf) < 2) return;

   MqlRates currentRates[];
   ArraySetAsSeries(currentRates, true);
   if(CopyRates(_Symbol, _Period, 1, 2, currentRates) < 2) return;

   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);

   // ブレイクアウト判定: 直前確定足(index 1)が東京高安値を実体でブレイクかつEMAと同調
   bool buyBreak  = (currentRates[0].close > asiaHigh && currentRates[0].open <= asiaHigh && currentRates[0].close > trendEMA[0]);
   bool sellBreak = (currentRates[0].close < asiaLow  && currentRates[0].open >= asiaLow  && currentRates[0].close < trendEMA[0]);

   if(buyBreak)
   {
      double slPrice = NormalizeDouble(asiaLow, _Digits);
      double slDist = ask - slPrice;
      if(slDist < atrBuf[0] * 0.8) { slDist = atrBuf[0] * 1.2; slPrice = NormalizeDouble(ask - slDist, _Digits); }
      double tpPrice = NormalizeDouble(ask + slDist * InpRiskRewardRatio, _Digits);
      double lot = CalculateRiskLot(slDist / GetPipPoint());

      if(m_trade.Buy(lot, _Symbol, ask, slPrice, tpPrice, InpTradeComment))
         lastTradeDay = dtNow.day;
   }
   else if(sellBreak)
   {
      double slPrice = NormalizeDouble(asiaHigh, _Digits);
      double slDist = slPrice - bid;
      if(slDist < atrBuf[0] * 0.8) { slDist = atrBuf[0] * 1.2; slPrice = NormalizeDouble(bid + slDist, _Digits); }
      double tpPrice = NormalizeDouble(bid - slDist * InpRiskRewardRatio, _Digits);
      double lot = CalculateRiskLot(slDist / GetPipPoint());

      if(m_trade.Sell(lot, _Symbol, bid, slPrice, tpPrice, InpTradeComment))
         lastTradeDay = dtNow.day;
   }
}

void ExecuteTradeManagement()
{
   for(int i = 0; i < PositionsTotal(); i++)
   {
      if(m_position.SelectByIndex(i))
      {
         if(m_position.Symbol() == _Symbol && m_position.Magic() == InpMagicNumber)
         {
            ulong ticket = m_position.Ticket();
            double openPrice = m_position.PriceOpen();
            double currentSL = m_position.StopLoss();
            double tpPrice   = m_position.TakeProfit();

            if(m_position.PositionType() == POSITION_TYPE_BUY)
            {
               double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
               double initialRisk = openPrice - currentSL;
               if(initialRisk > 0.0 && (bid - openPrice) >= initialRisk * InpBreakEvenTriggerR)
               {
                  double beSL = NormalizeDouble(openPrice + InpBreakEvenLockPips * GetPipPoint(), _Digits);
                  if(currentSL < beSL) { m_trade.PositionModify(ticket, beSL, tpPrice); }
               }
            }
            else if(m_position.PositionType() == POSITION_TYPE_SELL)
            {
               double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
               double initialRisk = currentSL - openPrice;
               if(initialRisk > 0.0 && (openPrice - ask) >= initialRisk * InpBreakEvenTriggerR)
               {
                  double beSL = NormalizeDouble(openPrice - InpBreakEvenLockPips * GetPipPoint(), _Digits);
                  if(currentSL == 0.0 || currentSL > beSL) { m_trade.PositionModify(ticket, beSL, tpPrice); }
               }
            }
         }
      }
   }
}

void CloseAllPositions(string reason)
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      if(m_position.SelectByIndex(i))
         if(m_position.Symbol() == _Symbol && m_position.Magic() == InpMagicNumber)
            m_trade.PositionClose(m_position.Ticket());
   }
}
`;
}

// =========================================================================
// MQL4 コードジェネレーター (戦略別完全個別ディスパッチ)
// =========================================================================
function generateMQL4Code(
  eaName: string,
  pair: string,
  tf: string,
  config: BuyerConfig,
  strategy: 'GOGOJUNGLE_TREND' | 'YOUTUBE_MTF_BREAK' | 'VOLATILITY_EXPANSION' | 'SESSION_MEAN_REVERSION' | 'LONDON_BREAKOUT'
): string {
  const maxPos = resolveMaxPositions(config);
  const fixedLot = (config.lotSize || 0.01).toFixed(2);
  const isCompounding = config.lotType === 'COMPOUND';
  const riskPercent = isCompounding ? (config.riskPercent || 1.0).toFixed(1) : '0.0';

  let customPeriodStr = '2026.07.01 - 2026.09.30 (直近3か月)';
  if (config.testPeriod === '1YEAR') customPeriodStr = '2025.10.01 - 2026.09.30 (直近1年)';
  else if (config.testPeriod === '3YEARS') customPeriodStr = '2023.10.01 - 2026.09.30 (直近3年)';
  else if (config.testPeriod === '5YEARS') customPeriodStr = '2021.10.01 - 2026.09.30 (直近5年)';

  if (strategy === 'YOUTUBE_MTF_BREAK') {
    return generateMQL4SMCBreakout(eaName, pair, tf, maxPos, fixedLot, riskPercent, customPeriodStr);
  }
  if (strategy === 'VOLATILITY_EXPANSION') {
    return generateMQL4VolatilitySqueeze(eaName, pair, tf, maxPos, fixedLot, riskPercent, customPeriodStr);
  }
  if (strategy === 'SESSION_MEAN_REVERSION') {
    return generateMQL4MeanReversion(eaName, pair, tf, maxPos, fixedLot, riskPercent, customPeriodStr);
  }
  if (strategy === 'LONDON_BREAKOUT') {
    return generateMQL4LondonBreakout(eaName, pair, tf, maxPos, fixedLot, riskPercent, customPeriodStr);
  }
  return generateMQL4TrendFollow(eaName, pair, tf, maxPos, fixedLot, riskPercent, customPeriodStr);
}

// 1. 王道マルチEMAトレンドフォロー MQL4
function generateMQL4TrendFollow(
  eaName: string,
  pair: string,
  tf: string,
  maxPos: number,
  fixedLot: string,
  riskPercent: string,
  customPeriodStr: string
): string {
  const isGold = pair === 'XAUUSD';
  const defaultSpread = isGold ? '10.0' : '4.5';
  const beLockPips = isGold ? '20.0' : '2.0';
  const trailStepPips = isGold ? '25.0' : '4.0';
  const guideAndDisclaimer = getMQLTesterGuideAndDisclaimer(pair, tf, customPeriodStr, fixedLot, riskPercent, false);

  return `//+------------------------------------------------------------------+
//|                                             ${eaName}.mq4 |
//|                             Copyright 2026, EA Maker Zero Pro     |
//|                                       https://www.gogojungle.co.jp |
//+------------------------------------------------------------------+
#property copyright   "EA Maker Zero Pro (Commercial Edition)"
#property link        "https://www.gogojungle.co.jp/"
#property version     "2.10"
#property strict
#property description "【販売用EA】王道マルチEMAスイング＆プライスアクション反転ブレイク戦略"
#property description "推奨通貨ペア: ${pair} / 推奨時間足: ${tf}"
#property description "ゼロ除算防止・ロット正規化・建値保護(BE)・動的トレール内蔵"

${guideAndDisclaimer}

//--- 入力パラメーター
input string   _group1             = "=== 【基本設定】 ===";
input int      InpMagicNumber      = 20260901;
input string   InpTradeComment     = "${eaName}";
input double   InpMaxSpread        = ${defaultSpread};
input int      InpMaxPositions     = ${maxPos};

input string   _group2             = "=== 【資金管理】 ===";
input double   InpRiskPercent      = ${riskPercent};
input double   InpFixedLot         = ${fixedLot};
input double   InpMaxLot           = 5.00;

input string   _group3             = "=== 【インジケーター設定】 ===";
input int      InpFastEMA          = 14;
input int      InpSlowEMA          = 50;
input int      InpTrendEMA         = 200;
input int      InpATRPeriod        = 14;
input double   InpAtrMultiplierSL  = 1.4;
input double   InpAtrMultiplierTP  = 2.2;

input string   _group4             = "=== 【安全管理】 ===";
input bool     InpUseBreakEven     = true;
input double   InpBreakEvenTriggerATR = 1.0;
input double   InpBreakEvenLockPips   = ${beLockPips};
input bool     InpUseTrailingStop  = true;
input double   InpTrailingStartATR = 1.5;
input double   InpTrailingDistATR  = 1.0;
input double   InpTrailingStepPips = ${trailStepPips};
input bool     InpFilterNightSpread = true;
input bool     InpCloseOnFriday    = true;
input int      InpFridayCloseHour  = 21;

datetime lastBarTime = 0;

double GetPipPoint()
{
   if(StringFind(Symbol(), "XAU") >= 0 || StringFind(Symbol(), "GOLD") >= 0)
   {
      if(Digits == 2) return (Point * 10.0);
      if(Digits == 3) return (Point * 100.0);
      if(Digits == 1) return Point;
      return (Point * 10.0);
   }
   if(Digits == 3 || Digits == 5) return (Point * 10.0);
   return Point;
}

double NormalizeLot(double requestedLot)
{
   double minLot  = MarketInfo(Symbol(), MODE_MINLOT);
   double maxLot  = MarketInfo(Symbol(), MODE_MAXLOT);
   double lotStep = MarketInfo(Symbol(), MODE_LOTSTEP);
   if(lotStep <= 0.0) lotStep = 0.01;
   if(minLot <= 0.0)  minLot  = 0.01;
   if(maxLot <= 0.0)  maxLot  = 100.0;
   if(maxLot > InpMaxLot) maxLot = InpMaxLot;
   double normalized = MathFloor(requestedLot / lotStep) * lotStep;
   if(normalized < minLot) normalized = minLot;
   if(normalized > maxLot) normalized = maxLot;
   return NormalizeDouble(normalized, lotStep == 0.1 ? 1 : lotStep == 1.0 ? 0 : 2);
}

double CalculateRiskLot(double slDistancePips)
{
   if(InpRiskPercent <= 0.0 || slDistancePips <= 0.0) return NormalizeLot(InpFixedLot);
   double equity = AccountEquity();
   if(equity <= 0.0) equity = AccountBalance();
   if(equity <= 0.0) return NormalizeLot(InpFixedLot);
   double riskAmount = equity * (InpRiskPercent / 100.0);
   double tickValue = MarketInfo(Symbol(), MODE_TICKVALUE);
   double tickSize  = MarketInfo(Symbol(), MODE_TICKSIZE);
   if(tickSize <= 0.0 || tickValue <= 0.0 || Point <= 0.0) return NormalizeLot(InpFixedLot);
   double pipVal = (tickValue / tickSize) * GetPipPoint();
   if(pipVal <= 0.0) return NormalizeLot(InpFixedLot);
   return NormalizeLot(riskAmount / (slDistancePips * pipVal));
}

int OnInit()
{
   Print("【MT4起動】", InpTradeComment, " Magic: ", InpMagicNumber, " (Trend Follow)");
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   Print("【MT4終了】", InpTradeComment, " Code: ", reason);
}

void OnTick()
{
   if(Point <= 0.0) return;

   if(InpCloseOnFriday && DayOfWeek() == 5 && TimeHour(TimeCurrent()) >= InpFridayCloseHour)
   {
      for(int i = OrdersTotal() - 1; i >= 0; i--)
         if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES) && OrderMagicNumber() == InpMagicNumber)
            OrderClose(OrderTicket(), OrderLots(), OrderType() == OP_BUY ? Bid : Ask, 3, clrWhite);
      return;
   }

   ExecuteMql4TradeManagement();

   if(Time[0] == lastBarTime) return;
   lastBarTime = Time[0];

   if(InpFilterNightSpread)
   {
      int currentHour = TimeHour(TimeCurrent());
      int currentMin  = TimeMinute(TimeCurrent());
      if(currentHour == 0 || (currentHour == 23 && currentMin >= 50)) return;
   }

   // 許容最大スプレッドチェック（PIPS単位厳密判定・ブローカー桁数2桁/3桁完全自動適応）
   double curSpreadPrice = Ask - Bid;
   double pipPoint = GetPipPoint();
   double curSpreadPips = (pipPoint > 0.0) ? (curSpreadPrice / pipPoint) : 0.0;
   double allowedMaxPips = (double)InpMaxSpread;
   if(allowedMaxPips > 20.0) allowedMaxPips = allowedMaxPips / 10.0; // ポイント指定(90pt等)の自動救済
   if(curSpreadPips > allowedMaxPips) return;

   int openCount = 0;
   for(int i = 0; i < OrdersTotal(); i++)
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES) && OrderMagicNumber() == InpMagicNumber) openCount++;
   if(openCount >= InpMaxPositions) return;

   double fastEMA1 = iMA(Symbol(), 0, InpFastEMA, 0, MODE_EMA, PRICE_CLOSE, 1);
   double slowEMA1 = iMA(Symbol(), 0, InpSlowEMA, 0, MODE_EMA, PRICE_CLOSE, 1);
   double slowEMA4 = iMA(Symbol(), 0, InpSlowEMA, 0, MODE_EMA, PRICE_CLOSE, 4);
   double trendEMA = iMA(Symbol(), 0, InpTrendEMA, 0, MODE_EMA, PRICE_CLOSE, 1);
   double curATR   = iATR(Symbol(), 0, InpATRPeriod, 1);
   if(curATR <= 0.0) return;

   bool isUptrendSlope   = (slowEMA1 >= slowEMA4);
   bool isDowntrendSlope = (slowEMA1 <= slowEMA4);
   bool didDip           = (Low[1] <= fastEMA1 + curATR * 0.20 || Low[2] <= iMA(Symbol(), 0, InpFastEMA, 0, MODE_EMA, PRICE_CLOSE, 2) + curATR * 0.20);
   bool isBullReversal   = (Close[1] > Open[1] && Close[1] > High[2]);
   bool buySignal  = (fastEMA1 > slowEMA1 && isUptrendSlope && Close[1] > trendEMA && didDip && isBullReversal);

   bool didRally         = (High[1] >= fastEMA1 - curATR * 0.20 || High[2] >= iMA(Symbol(), 0, InpFastEMA, 0, MODE_EMA, PRICE_CLOSE, 2) - curATR * 0.20);
   bool isBearReversal   = (Close[1] < Open[1] && Close[1] < Low[2]);
   bool sellSignal = (fastEMA1 < slowEMA1 && isDowntrendSlope && Close[1] < trendEMA && didRally && isBearReversal);

   if(buySignal)
   {
      double slDist = curATR * InpAtrMultiplierSL;
      double tpDist = curATR * InpAtrMultiplierTP;
      double slPrice = NormalizeDouble(Ask - slDist, Digits);
      double tpPrice = NormalizeDouble(Ask + tpDist, Digits);
      double lot = CalculateRiskLot(slDist / GetPipPoint());
      OrderSend(Symbol(), OP_BUY, lot, Ask, 3, slPrice, tpPrice, InpTradeComment, InpMagicNumber, 0, clrBlue);
   }
   else if(sellSignal)
   {
      double slDist = curATR * InpAtrMultiplierSL;
      double tpDist = curATR * InpAtrMultiplierTP;
      double slPrice = NormalizeDouble(Bid + slDist, Digits);
      double tpPrice = NormalizeDouble(Bid - tpDist, Digits);
      double lot = CalculateRiskLot(slDist / GetPipPoint());
      OrderSend(Symbol(), OP_SELL, lot, Bid, 3, slPrice, tpPrice, InpTradeComment, InpMagicNumber, 0, clrRed);
   }
}

void ExecuteMql4TradeManagement()
{
   double curATR = iATR(Symbol(), 0, InpATRPeriod, 1);
   if(curATR <= 0.0) return;
   double beTriggerDist  = curATR * InpBreakEvenTriggerATR;
   double beLockDist     = InpBreakEvenLockPips * GetPipPoint();
   double trailStartDist = curATR * InpTrailingStartATR;
   double trailDist      = curATR * InpTrailingDistATR;
   double trailStepDist  = InpTrailingStepPips * GetPipPoint();

   for(int i = 0; i < OrdersTotal(); i++)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES) && OrderMagicNumber() == InpMagicNumber)
      {
         double openPrice = OrderOpenPrice();
         double currentSL = OrderStopLoss();
         double tpPrice   = OrderTakeProfit();

         if(OrderType() == OP_BUY)
         {
            double profit = Bid - openPrice;
            if(InpUseBreakEven && profit >= beTriggerDist)
            {
               double beSL = NormalizeDouble(openPrice + beLockDist, Digits);
               if(currentSL < beSL) { OrderModify(OrderTicket(), openPrice, beSL, tpPrice, 0, clrNONE); currentSL = beSL; }
            }
            if(InpUseTrailingStop && profit >= trailStartDist)
            {
               double newSL = NormalizeDouble(Bid - trailDist, Digits);
               if(newSL >= currentSL + trailStepDist && newSL > openPrice)
                  OrderModify(OrderTicket(), openPrice, newSL, tpPrice, 0, clrNONE);
            }
         }
         else if(OrderType() == OP_SELL)
         {
            double profit = openPrice - Ask;
            if(InpUseBreakEven && profit >= beTriggerDist)
            {
               double beSL = NormalizeDouble(openPrice - beLockDist, Digits);
               if(currentSL == 0.0 || currentSL > beSL) { OrderModify(OrderTicket(), openPrice, beSL, tpPrice, 0, clrNONE); currentSL = beSL; }
            }
            if(InpUseTrailingStop && profit >= trailStartDist)
            {
               double newSL = NormalizeDouble(Ask + trailDist, Digits);
               if((currentSL == 0.0 || newSL <= currentSL - trailStepDist) && newSL < openPrice)
                  OrderModify(OrderTicket(), openPrice, newSL, tpPrice, 0, clrNONE);
            }
         }
      }
   }
}
`;
}

// 2. スマートマネー [SMC] ＆ ドンチャン流動性ブレイク MQL4
function generateMQL4SMCBreakout(
  eaName: string,
  pair: string,
  tf: string,
  maxPos: number,
  fixedLot: string,
  riskPercent: string,
  customPeriodStr: string
): string {
  const isGold = pair === 'XAUUSD';
  const defaultSpread = isGold ? '10.0' : '4.5';
  const beLockPips = isGold ? '20.0' : '2.0';
  const guideAndDisclaimer = getMQLTesterGuideAndDisclaimer(pair, tf, customPeriodStr, fixedLot, riskPercent, false);

  return `//+------------------------------------------------------------------+
//|                                             ${eaName}.mq4 |
//|                             Copyright 2026, EA Maker Zero Pro     |
//|                                       https://www.gogojungle.co.jp |
//+------------------------------------------------------------------+
#property copyright   "EA Maker Zero Pro (Commercial Edition)"
#property link        "https://www.gogojungle.co.jp/"
#property version     "2.10"
#property strict
#property description "【販売用EA】スマートマネー[SMC]＆ドンチャン流動性ブレイクアウト戦略"
#property description "推奨通貨ペア: ${pair} / 推奨時間足: ${tf}"

${guideAndDisclaimer}

input string   _group1             = "=== 【基本設定】 ===";
input int      InpMagicNumber      = 20260902;
input string   InpTradeComment     = "${eaName}";
input double   InpMaxSpread        = ${defaultSpread};
input int      InpMaxPositions     = ${maxPos};

input string   _group2             = "=== 【資金管理】 ===";
input double   InpRiskPercent      = ${riskPercent};
input double   InpFixedLot         = ${fixedLot};
input double   InpMaxLot           = 5.00;

input string   _group3             = "=== 【SMCドンチャン設定】 ===";
input int      InpDonchianPeriod   = 20;
input int      InpTrendFilterEMA   = 200;
input int      InpATRPeriod        = 14;
input double   InpInitialStopATR   = 1.5;
input double   InpChandelierTrailATR = 2.0;
input double   InpTakeProfitATR    = 3.2;

input string   _group4             = "=== 【安全管理】 ===";
input bool     InpUseBreakEven     = true;
input double   InpBreakEvenTriggerATR = 1.2;
input double   InpBreakEvenLockPips   = ${beLockPips};
input bool     InpFilterNightSpread = true;
input bool     InpCloseOnFriday    = true;
input int      InpFridayCloseHour  = 21;

datetime lastBarTime = 0;

double GetPipPoint()
{
   if(StringFind(Symbol(), "XAU") >= 0 || StringFind(Symbol(), "GOLD") >= 0)
   {
      if(Digits == 2) return (Point * 10.0);
      if(Digits == 3) return (Point * 100.0);
      if(Digits == 1) return Point;
      return (Point * 10.0);
   }
   if(Digits == 3 || Digits == 5) return (Point * 10.0);
   return Point;
}

double NormalizeLot(double requestedLot)
{
   double minLot  = MarketInfo(Symbol(), MODE_MINLOT);
   double maxLot  = MarketInfo(Symbol(), MODE_MAXLOT);
   double lotStep = MarketInfo(Symbol(), MODE_LOTSTEP);
   if(lotStep <= 0.0) lotStep = 0.01;
   if(minLot <= 0.0)  minLot  = 0.01;
   if(maxLot <= 0.0)  maxLot  = 100.0;
   if(maxLot > InpMaxLot) maxLot = InpMaxLot;
   double normalized = MathFloor(requestedLot / lotStep) * lotStep;
   if(normalized < minLot) normalized = minLot;
   if(normalized > maxLot) normalized = maxLot;
   return NormalizeDouble(normalized, lotStep == 0.1 ? 1 : lotStep == 1.0 ? 0 : 2);
}

double CalculateRiskLot(double slDistancePips)
{
   if(InpRiskPercent <= 0.0 || slDistancePips <= 0.0) return NormalizeLot(InpFixedLot);
   double equity = AccountEquity();
   if(equity <= 0.0) equity = AccountBalance();
   if(equity <= 0.0) return NormalizeLot(InpFixedLot);
   double riskAmount = equity * (InpRiskPercent / 100.0);
   double tickValue = MarketInfo(Symbol(), MODE_TICKVALUE);
   double tickSize  = MarketInfo(Symbol(), MODE_TICKSIZE);
   if(tickSize <= 0.0 || tickValue <= 0.0 || Point <= 0.0) return NormalizeLot(InpFixedLot);
   double pipVal = (tickValue / tickSize) * GetPipPoint();
   if(pipVal <= 0.0) return NormalizeLot(InpFixedLot);
   return NormalizeLot(riskAmount / (slDistancePips * pipVal));
}

int OnInit()
{
   Print("【MT4起動】", InpTradeComment, " Magic: ", InpMagicNumber, " (SMC Donchian Break)");
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   Print("【MT4終了】", InpTradeComment, " Code: ", reason);
}

void OnTick()
{
   if(Point <= 0.0) return;

   if(InpCloseOnFriday && DayOfWeek() == 5 && TimeHour(TimeCurrent()) >= InpFridayCloseHour)
   {
      for(int i = OrdersTotal() - 1; i >= 0; i--)
         if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES) && OrderMagicNumber() == InpMagicNumber)
            OrderClose(OrderTicket(), OrderLots(), OrderType() == OP_BUY ? Bid : Ask, 3, clrWhite);
      return;
   }

   ExecuteMql4SMCManagement();

   if(Time[0] == lastBarTime) return;
   lastBarTime = Time[0];

   if(InpFilterNightSpread)
   {
      int currentHour = TimeHour(TimeCurrent());
      int currentMin  = TimeMinute(TimeCurrent());
      if(currentHour == 0 || (currentHour == 23 && currentMin >= 50)) return;
   }

   // 許容最大スプレッドチェック（PIPS単位厳密判定・ブローカー桁数2桁/3桁完全自動適応）
   double curSpreadPrice = Ask - Bid;
   double pipPoint = GetPipPoint();
   double curSpreadPips = (pipPoint > 0.0) ? (curSpreadPrice / pipPoint) : 0.0;
   double allowedMaxPips = (double)InpMaxSpread;
   if(allowedMaxPips > 20.0) allowedMaxPips = allowedMaxPips / 10.0; // ポイント指定(90pt等)の自動救済
   if(curSpreadPips > allowedMaxPips) return;

   int openCount = 0;
   for(int i = 0; i < OrdersTotal(); i++)
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES) && OrderMagicNumber() == InpMagicNumber) openCount++;
   if(openCount >= InpMaxPositions) return;

   int highBar = iHighest(Symbol(), 0, MODE_HIGH, InpDonchianPeriod, 2);
   int lowBar  = iLowest(Symbol(), 0, MODE_LOW, InpDonchianPeriod, 2);
   double donchianHigh = High[highBar];
   double donchianLow  = Low[lowBar];

   double trendEMA = iMA(Symbol(), 0, InpTrendFilterEMA, 0, MODE_EMA, PRICE_CLOSE, 1);
   double curATR   = iATR(Symbol(), 0, InpATRPeriod, 1);
   double prevATR  = iATR(Symbol(), 0, InpATRPeriod, 5);
   if(curATR <= 0.0) return;

   bool isVolatilityExpanding = (curATR >= prevATR * 0.95);
   bool buyBreak  = (Close[1] > donchianHigh && Open[1] <= donchianHigh && Close[1] > trendEMA && isVolatilityExpanding);
   bool sellBreak = (Close[1] < donchianLow  && Open[1] >= donchianLow  && Close[1] < trendEMA && isVolatilityExpanding);

   if(buyBreak)
   {
      double slDist = curATR * InpInitialStopATR;
      double tpDist = curATR * InpTakeProfitATR;
      double slPrice = NormalizeDouble(Ask - slDist, Digits);
      double tpPrice = NormalizeDouble(Ask + tpDist, Digits);
      double lot = CalculateRiskLot(slDist / GetPipPoint());
      OrderSend(Symbol(), OP_BUY, lot, Ask, 3, slPrice, tpPrice, InpTradeComment, InpMagicNumber, 0, clrBlue);
   }
   else if(sellBreak)
   {
      double slDist = curATR * InpInitialStopATR;
      double tpDist = curATR * InpTakeProfitATR;
      double slPrice = NormalizeDouble(Bid + slDist, Digits);
      double tpPrice = NormalizeDouble(Bid - tpDist, Digits);
      double lot = CalculateRiskLot(slDist / GetPipPoint());
      OrderSend(Symbol(), OP_SELL, lot, Bid, 3, slPrice, tpPrice, InpTradeComment, InpMagicNumber, 0, clrRed);
   }
}

void ExecuteMql4SMCManagement()
{
   double curATR = iATR(Symbol(), 0, InpATRPeriod, 1);
   if(curATR <= 0.0) return;
   double beTriggerDist = curATR * InpBreakEvenTriggerATR;
   double trailDist     = curATR * InpChandelierTrailATR;

   for(int i = 0; i < OrdersTotal(); i++)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES) && OrderMagicNumber() == InpMagicNumber)
      {
         double openPrice = OrderOpenPrice();
         double currentSL = OrderStopLoss();
         double tpPrice   = OrderTakeProfit();

         if(OrderType() == OP_BUY)
         {
            double profit = Bid - openPrice;
            if(InpUseBreakEven && profit >= beTriggerDist)
            {
               double beSL = NormalizeDouble(openPrice + InpBreakEvenLockPips * GetPipPoint(), Digits);
               if(currentSL < beSL) { OrderModify(OrderTicket(), openPrice, beSL, tpPrice, 0, clrNONE); currentSL = beSL; }
            }
            double highestHigh = High[iHighest(Symbol(), 0, MODE_HIGH, 10, 1)];
            double chandelierSL = NormalizeDouble(highestHigh - trailDist, Digits);
            if(chandelierSL > currentSL + 4.0 * GetPipPoint() && chandelierSL > openPrice)
               OrderModify(OrderTicket(), openPrice, chandelierSL, tpPrice, 0, clrNONE);
         }
         else if(OrderType() == OP_SELL)
         {
            double profit = openPrice - Ask;
            if(InpUseBreakEven && profit >= beTriggerDist)
            {
               double beSL = NormalizeDouble(openPrice - InpBreakEvenLockPips * GetPipPoint(), Digits);
               if(currentSL == 0.0 || currentSL > beSL) { OrderModify(OrderTicket(), openPrice, beSL, tpPrice, 0, clrNONE); currentSL = beSL; }
            }
            double lowestLow = Low[iLowest(Symbol(), 0, MODE_LOW, 10, 1)];
            double chandelierSL = NormalizeDouble(lowestLow + trailDist, Digits);
            if((currentSL == 0.0 || chandelierSL < currentSL - 4.0 * GetPipPoint()) && chandelierSL < openPrice)
               OrderModify(OrderTicket(), openPrice, chandelierSL, tpPrice, 0, clrNONE);
         }
      }
   }
}
`;
}

// 3. ボリンジャースクイーズ ＆ TTMモメンタムブレイク MQL4
function generateMQL4VolatilitySqueeze(
  eaName: string,
  pair: string,
  tf: string,
  maxPos: number,
  fixedLot: string,
  riskPercent: string,
  customPeriodStr: string
): string {
  const isGold = pair === 'XAUUSD';
  const defaultSpread = isGold ? '10.0' : '4.5';
  const beLockPips = isGold ? '20.0' : '2.0';
  const guideAndDisclaimer = getMQLTesterGuideAndDisclaimer(pair, tf, customPeriodStr, fixedLot, riskPercent, false);

  return `//+------------------------------------------------------------------+
//|                                             ${eaName}.mq4 |
//|                             Copyright 2026, EA Maker Zero Pro     |
//|                                       https://www.gogojungle.co.jp |
//+------------------------------------------------------------------+
#property copyright   "EA Maker Zero Pro (Commercial Edition)"
#property link        "https://www.gogojungle.co.jp/"
#property version     "2.10"
#property strict
#property description "【販売用EA】TTMスクイーズ＆ボリンジャー・エクスパンション爆発戦略"
#property description "推奨通貨ペア: ${pair} / 推奨時間足: ${tf}"

${guideAndDisclaimer}

input string   _group1             = "=== 【基本設定】 ===";
input int      InpMagicNumber      = 20260903;
input string   InpTradeComment     = "${eaName}";
input double   InpMaxSpread        = ${defaultSpread};
input int      InpMaxPositions     = ${maxPos};

input string   _group2             = "=== 【資金管理】 ===";
input double   InpRiskPercent      = ${riskPercent};
input double   InpFixedLot         = ${fixedLot};
input double   InpMaxLot           = 5.00;

input string   _group3             = "=== 【TTMスクイーズ設定】 ===";
input int      InpBBPeriod         = 20;
input double   InpBBDeviation      = 2.0;
input int      InpMomentumPeriod   = 12;
input double   InpStopLossATR      = 1.3;
input double   InpTakeProfitATR    = 2.6;

input string   _group4             = "=== 【安全管理】 ===";
input bool     InpUseBreakEven     = true;
input double   InpBreakEvenTriggerATR = 1.0;
input double   InpBreakEvenLockPips   = ${beLockPips};
input bool     InpFilterNightSpread = true;
input bool     InpCloseOnFriday    = true;
input int      InpFridayCloseHour  = 21;

datetime lastBarTime = 0;

double GetPipPoint()
{
   if(StringFind(Symbol(), "XAU") >= 0 || StringFind(Symbol(), "GOLD") >= 0)
   {
      if(Digits == 2) return (Point * 10.0);
      if(Digits == 3) return (Point * 100.0);
      if(Digits == 1) return Point;
      return (Point * 10.0);
   }
   if(Digits == 3 || Digits == 5) return (Point * 10.0);
   return Point;
}

double NormalizeLot(double requestedLot)
{
   double minLot  = MarketInfo(Symbol(), MODE_MINLOT);
   double maxLot  = MarketInfo(Symbol(), MODE_MAXLOT);
   double lotStep = MarketInfo(Symbol(), MODE_LOTSTEP);
   if(lotStep <= 0.0) lotStep = 0.01;
   if(minLot <= 0.0)  minLot  = 0.01;
   if(maxLot <= 0.0)  maxLot  = 100.0;
   if(maxLot > InpMaxLot) maxLot = InpMaxLot;
   double normalized = MathFloor(requestedLot / lotStep) * lotStep;
   if(normalized < minLot) normalized = minLot;
   if(normalized > maxLot) normalized = maxLot;
   return NormalizeDouble(normalized, lotStep == 0.1 ? 1 : lotStep == 1.0 ? 0 : 2);
}

double CalculateRiskLot(double slDistancePips)
{
   if(InpRiskPercent <= 0.0 || slDistancePips <= 0.0) return NormalizeLot(InpFixedLot);
   double equity = AccountEquity();
   if(equity <= 0.0) equity = AccountBalance();
   if(equity <= 0.0) return NormalizeLot(InpFixedLot);
   double riskAmount = equity * (InpRiskPercent / 100.0);
   double tickValue = MarketInfo(Symbol(), MODE_TICKVALUE);
   double tickSize  = MarketInfo(Symbol(), MODE_TICKSIZE);
   if(tickSize <= 0.0 || tickValue <= 0.0 || Point <= 0.0) return NormalizeLot(InpFixedLot);
   double pipVal = (tickValue / tickSize) * GetPipPoint();
   if(pipVal <= 0.0) return NormalizeLot(InpFixedLot);
   return NormalizeLot(riskAmount / (slDistancePips * pipVal));
}

int OnInit()
{
   Print("【MT4起動】", InpTradeComment, " Magic: ", InpMagicNumber, " (TTM Squeeze)");
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   Print("【MT4終了】", InpTradeComment, " Code: ", reason);
}

void OnTick()
{
   if(Point <= 0.0) return;

   if(InpCloseOnFriday && DayOfWeek() == 5 && TimeHour(TimeCurrent()) >= InpFridayCloseHour)
   {
      for(int i = OrdersTotal() - 1; i >= 0; i--)
         if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES) && OrderMagicNumber() == InpMagicNumber)
            OrderClose(OrderTicket(), OrderLots(), OrderType() == OP_BUY ? Bid : Ask, 3, clrWhite);
      return;
   }

   ExecuteMql4SqueezeManagement();

   if(Time[0] == lastBarTime) return;
   lastBarTime = Time[0];

   if(InpFilterNightSpread)
   {
      int currentHour = TimeHour(TimeCurrent());
      int currentMin  = TimeMinute(TimeCurrent());
      if(currentHour == 0 || (currentHour == 23 && currentMin >= 50)) return;
   }

   // 許容最大スプレッドチェック（PIPS単位厳密判定・ブローカー桁数2桁/3桁完全自動適応）
   double curSpreadPrice = Ask - Bid;
   double pipPoint = GetPipPoint();
   double curSpreadPips = (pipPoint > 0.0) ? (curSpreadPrice / pipPoint) : 0.0;
   double allowedMaxPips = (double)InpMaxSpread;
   if(allowedMaxPips > 20.0) allowedMaxPips = allowedMaxPips / 10.0; // ポイント指定(90pt等)の自動救済
   if(curSpreadPips > allowedMaxPips) return;

   int openCount = 0;
   for(int i = 0; i < OrdersTotal(); i++)
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES) && OrderMagicNumber() == InpMagicNumber) openCount++;
   if(openCount >= InpMaxPositions) return;

   double bbUp1 = iBands(Symbol(), 0, InpBBPeriod, InpBBDeviation, 0, PRICE_CLOSE, MODE_UPPER, 1);
   double bbDn1 = iBands(Symbol(), 0, InpBBPeriod, InpBBDeviation, 0, PRICE_CLOSE, MODE_LOWER, 1);
   double curATR = iATR(Symbol(), 0, InpBBPeriod, 1);
   double mom1   = iMomentum(Symbol(), 0, InpMomentumPeriod, PRICE_CLOSE, 1);
   double mom2   = iMomentum(Symbol(), 0, InpMomentumPeriod, PRICE_CLOSE, 2);
   if(curATR <= 0.0) return;

   bool buySqueezeFire  = (Close[1] > bbUp1 && mom1 > 100.0 && mom1 > mom2);
   bool sellSqueezeFire = (Close[1] < bbDn1 && mom1 < 100.0 && mom1 < mom2);

   if(buySqueezeFire)
   {
      double slDist = curATR * InpStopLossATR;
      double tpDist = curATR * InpTakeProfitATR;
      double slPrice = NormalizeDouble(Ask - slDist, Digits);
      double tpPrice = NormalizeDouble(Ask + tpDist, Digits);
      double lot = CalculateRiskLot(slDist / (Point * 10.0));
      OrderSend(Symbol(), OP_BUY, lot, Ask, 3, slPrice, tpPrice, InpTradeComment, InpMagicNumber, 0, clrBlue);
   }
   else if(sellSqueezeFire)
   {
      double slDist = curATR * InpStopLossATR;
      double tpDist = curATR * InpTakeProfitATR;
      double slPrice = NormalizeDouble(Bid + slDist, Digits);
      double tpPrice = NormalizeDouble(Bid - tpDist, Digits);
      double lot = CalculateRiskLot(slDist / (Point * 10.0));
      OrderSend(Symbol(), OP_SELL, lot, Bid, 3, slPrice, tpPrice, InpTradeComment, InpMagicNumber, 0, clrRed);
   }
}

void ExecuteMql4SqueezeManagement()
{
   double curATR = iATR(Symbol(), 0, InpBBPeriod, 1);
   if(curATR <= 0.0) return;
   double beTriggerDist = curATR * InpBreakEvenTriggerATR;

   for(int i = 0; i < OrdersTotal(); i++)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES) && OrderMagicNumber() == InpMagicNumber)
      {
         double openPrice = OrderOpenPrice();
         double currentSL = OrderStopLoss();
         double tpPrice   = OrderTakeProfit();

         if(OrderType() == OP_BUY)
         {
            double profit = Bid - openPrice;
            if(InpUseBreakEven && profit >= beTriggerDist)
            {
               double beSL = NormalizeDouble(openPrice + 2.0 * Point * 10.0, Digits);
               if(currentSL < beSL) { OrderModify(OrderTicket(), openPrice, beSL, tpPrice, 0, clrNONE); }
            }
         }
         else if(OrderType() == OP_SELL)
         {
            double profit = openPrice - Ask;
            if(InpUseBreakEven && profit >= beTriggerDist)
            {
               double beSL = NormalizeDouble(openPrice - 2.0 * Point * 10.0, Digits);
               if(currentSL == 0.0 || currentSL > beSL) { OrderModify(OrderTicket(), openPrice, beSL, tpPrice, 0, clrNONE); }
            }
         }
      }
   }
}
`;
}

// 4. セッションアノマリー ＆ 2.5σ平均回帰 MQL4
function generateMQL4MeanReversion(
  eaName: string,
  pair: string,
  tf: string,
  maxPos: number,
  fixedLot: string,
  riskPercent: string,
  customPeriodStr: string
): string {
  const isGold = pair === 'XAUUSD';
  const defaultSpread = isGold ? '10.0' : '4.5';
  const guideAndDisclaimer = getMQLTesterGuideAndDisclaimer(pair, tf, customPeriodStr, fixedLot, riskPercent, false);

  return `//+------------------------------------------------------------------+
//|                                             ${eaName}.mq4 |
//|                             Copyright 2026, EA Maker Zero Pro     |
//|                                       https://www.gogojungle.co.jp |
//+------------------------------------------------------------------+
#property copyright   "EA Maker Zero Pro (Commercial Edition)"
#property link        "https://www.gogojungle.co.jp/"
#property version     "2.10"
#property strict
#property description "【販売用EA】東京・欧州早朝セッション2.5σ平均回帰スキャルピング"
#property description "推奨通貨ペア: ${pair} / 推奨時間足: ${tf}"

${guideAndDisclaimer}

input string   _group1             = "=== 【基本設定】 ===";
input int      InpMagicNumber      = 20260904;
input string   InpTradeComment     = "${eaName}";
input double   InpMaxSpread        = ${defaultSpread};
input int      InpMaxPositions     = ${maxPos};

input string   _group2             = "=== 【資金管理】 ===";
input double   InpRiskPercent      = ${riskPercent};
input double   InpFixedLot         = ${fixedLot};
input double   InpMaxLot           = 5.00;

input string   _group3             = "=== 【平均回帰設定】 ===";
input int      InpBBPeriod         = 20;
input double   InpBBDeviation      = 2.5;
input int      InpRSIPeriod        = 14;
input double   InpRSIOversold      = 28.0;
input double   InpRSIOverbought    = 72.0;
input int      InpSessionStartHour = 2;
input int      InpSessionEndHour   = 11;
input double   InpStopLossATR      = 1.1;
input double   InpTakeProfitATR    = 1.5;

input string   _group4             = "=== 【安全管理】 ===";
input bool     InpFilterNightSpread = true;
input bool     InpCloseOnFriday    = true;
input int      InpFridayCloseHour  = 21;

datetime lastBarTime = 0;

double NormalizeLot(double requestedLot)
{
   double minLot  = MarketInfo(Symbol(), MODE_MINLOT);
   double maxLot  = MarketInfo(Symbol(), MODE_MAXLOT);
   double lotStep = MarketInfo(Symbol(), MODE_LOTSTEP);
   if(lotStep <= 0.0) lotStep = 0.01;
   if(minLot <= 0.0)  minLot  = 0.01;
   if(maxLot <= 0.0)  maxLot  = 100.0;
   if(maxLot > InpMaxLot) maxLot = InpMaxLot;
   double normalized = MathFloor(requestedLot / lotStep) * lotStep;
   if(normalized < minLot) normalized = minLot;
   if(normalized > maxLot) normalized = maxLot;
   return NormalizeDouble(normalized, lotStep == 0.1 ? 1 : lotStep == 1.0 ? 0 : 2);
}

double CalculateRiskLot(double slDistancePips)
{
   if(InpRiskPercent <= 0.0 || slDistancePips <= 0.0) return NormalizeLot(InpFixedLot);
   double equity = AccountEquity();
   if(equity <= 0.0) equity = AccountBalance();
   if(equity <= 0.0) return NormalizeLot(InpFixedLot);
   double riskAmount = equity * (InpRiskPercent / 100.0);
   double tickValue = MarketInfo(Symbol(), MODE_TICKVALUE);
   double tickSize  = MarketInfo(Symbol(), MODE_TICKSIZE);
   if(tickSize <= 0.0 || tickValue <= 0.0 || Point <= 0.0) return NormalizeLot(InpFixedLot);
   double pipVal = (tickValue / tickSize) * (Point * 10.0);
   if(pipVal <= 0.0) return NormalizeLot(InpFixedLot);
   return NormalizeLot(riskAmount / (slDistancePips * pipVal));
}

int OnInit()
{
   Print("【MT4起動】", InpTradeComment, " Magic: ", InpMagicNumber, " (Mean Reversion)");
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   Print("【MT4終了】", InpTradeComment, " Code: ", reason);
}

void OnTick()
{
   if(Point <= 0.0) return;

   if(InpCloseOnFriday && DayOfWeek() == 5 && TimeHour(TimeCurrent()) >= InpFridayCloseHour)
   {
      for(int i = OrdersTotal() - 1; i >= 0; i--)
         if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES) && OrderMagicNumber() == InpMagicNumber)
            OrderClose(OrderTicket(), OrderLots(), OrderType() == OP_BUY ? Bid : Ask, 3, clrWhite);
      return;
   }

   if(Time[0] == lastBarTime) return;
   lastBarTime = Time[0];

   int hr = TimeHour(TimeCurrent());
   if(hr < InpSessionStartHour || hr > InpSessionEndHour) return;

   if(InpFilterNightSpread)
   {
      int currentMin  = TimeMinute(TimeCurrent());
      if(hr == 0 || (hr == 23 && currentMin >= 50)) return;
   }

   // 許容最大スプレッドチェック（PIPS単位厳密判定・ブローカー桁数2桁/3桁完全自動適応）
   double curSpreadPrice = Ask - Bid;
   double pipPoint = GetPipPoint();
   double curSpreadPips = (pipPoint > 0.0) ? (curSpreadPrice / pipPoint) : 0.0;
   double allowedMaxPips = (double)InpMaxSpread;
   if(allowedMaxPips > 20.0) allowedMaxPips = allowedMaxPips / 10.0; // ポイント指定(90pt等)の自動救済
   if(curSpreadPips > allowedMaxPips) return;

   int openCount = 0;
   for(int i = 0; i < OrdersTotal(); i++)
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES) && OrderMagicNumber() == InpMagicNumber) openCount++;
   if(openCount >= InpMaxPositions) return;

   double bbUp = iBands(Symbol(), 0, InpBBPeriod, InpBBDeviation, 0, PRICE_CLOSE, MODE_UPPER, 1);
   double bbDn = iBands(Symbol(), 0, InpBBPeriod, InpBBDeviation, 0, PRICE_CLOSE, MODE_LOWER, 1);
   double bbMid = iBands(Symbol(), 0, InpBBPeriod, InpBBDeviation, 0, PRICE_CLOSE, MODE_MAIN, 1);
   double rsi  = iRSI(Symbol(), 0, InpRSIPeriod, PRICE_CLOSE, 1);
   double curATR = iATR(Symbol(), 0, InpBBPeriod, 1);
   if(curATR <= 0.0) return;

   bool buyMeanRev  = (Low[1] <= bbDn && Close[1] > Open[1] && rsi <= InpRSIOversold);
   bool sellMeanRev = (High[1] >= bbUp && Close[1] < Open[1] && rsi >= InpRSIOverbought);

   if(buyMeanRev)
   {
      double slDist = curATR * InpStopLossATR;
      double tpDist = MathMin(curATR * InpTakeProfitATR, (bbMid - Ask));
      if(tpDist < curATR * 0.8) tpDist = curATR * InpTakeProfitATR;
      double slPrice = NormalizeDouble(Ask - slDist, Digits);
      double tpPrice = NormalizeDouble(Ask + tpDist, Digits);
      double lot = CalculateRiskLot(slDist / (Point * 10.0));
      OrderSend(Symbol(), OP_BUY, lot, Ask, 3, slPrice, tpPrice, InpTradeComment, InpMagicNumber, 0, clrBlue);
   }
   else if(sellMeanRev)
   {
      double slDist = curATR * InpStopLossATR;
      double tpDist = MathMin(curATR * InpTakeProfitATR, (Bid - bbMid));
      if(tpDist < curATR * 0.8) tpDist = curATR * InpTakeProfitATR;
      double slPrice = NormalizeDouble(Bid + slDist, Digits);
      double tpPrice = NormalizeDouble(Bid - tpDist, Digits);
      double lot = CalculateRiskLot(slDist / (Point * 10.0));
      OrderSend(Symbol(), OP_SELL, lot, Bid, 3, slPrice, tpPrice, InpTradeComment, InpMagicNumber, 0, clrRed);
   }
}
`;
}

// 5. 東京レンジ確定ブレイク ＆ ロンドン初動流動性ブレイクアウト MQL4
function generateMQL4LondonBreakout(
  eaName: string,
  pair: string,
  tf: string,
  maxPos: number,
  fixedLot: string,
  riskPercent: string,
  customPeriodStr: string
): string {
  const isGold = pair === 'XAUUSD';
  const defaultSpread = isGold ? '10.0' : '4.5';
  const minRangePips = isGold ? '80.0' : '15.0';
  const maxRangePips = isGold ? '350.0' : '65.0';
  const beLockPips = isGold ? '20.0' : '2.0';
  const guideAndDisclaimer = getMQLTesterGuideAndDisclaimer(pair, tf, customPeriodStr, fixedLot, riskPercent, false);

  return `//+------------------------------------------------------------------+
//|                                             ${eaName}.mq4 |
//|                             Copyright 2026, EA Maker Zero Pro     |
//|                                       https://www.gogojungle.co.jp |
//+------------------------------------------------------------------+
#property copyright   "EA Maker Zero Pro (Commercial Edition)"
#property link        "https://www.gogojungle.co.jp/"
#property version     "2.10"
#property strict
#property description "【販売用EA】東京レンジ確定ブレイク＆ロンドン初動流動性ブレイク戦略"
#property description "推奨通貨ペア: ${pair} / 推奨時間足: ${tf}"

${guideAndDisclaimer}

input string   _group1             = "=== 【基本設定】 ===";
input int      InpMagicNumber      = 20260905;
input string   InpTradeComment     = "${eaName}";
input double   InpMaxSpread        = ${defaultSpread};
input int      InpMaxPositions     = ${maxPos};

input string   _group2             = "=== 【資金管理】 ===";
input double   InpRiskPercent      = ${riskPercent};
input double   InpFixedLot         = ${fixedLot};
input double   InpMaxLot           = 5.00;

input string   _group3             = "=== 【ロンドンブレイク設定】 ===";
input int      InpAsiaStartHour    = 1;
input int      InpAsiaEndHour      = 8;
input int      InpTradeStartHour   = 8;
input int      InpTradeEndHour     = 14;
input double   InpMinRangePips     = ${minRangePips};
input double   InpMaxRangePips     = ${maxRangePips};
input int      InpTrendEMA         = 50;
input int      InpATRPeriod        = 14;
input double   InpRiskRewardRatio  = 2.0;

input string   _group4             = "=== 【安全管理】 ===";
input bool     InpUseBreakEven     = true;
input bool     InpFilterNightSpread = true;
input bool     InpCloseOnFriday    = true;
input int      InpFridayCloseHour  = 21;

datetime lastBarTime = 0;
int      lastTradeDay = -1;

double NormalizeLot(double requestedLot)
{
   double minLot  = MarketInfo(Symbol(), MODE_MINLOT);
   double maxLot  = MarketInfo(Symbol(), MODE_MAXLOT);
   double lotStep = MarketInfo(Symbol(), MODE_LOTSTEP);
   if(lotStep <= 0.0) lotStep = 0.01;
   if(minLot <= 0.0)  minLot  = 0.01;
   if(maxLot <= 0.0)  maxLot  = 100.0;
   if(maxLot > InpMaxLot) maxLot = InpMaxLot;
   double normalized = MathFloor(requestedLot / lotStep) * lotStep;
   if(normalized < minLot) normalized = minLot;
   if(normalized > maxLot) normalized = maxLot;
   return NormalizeDouble(normalized, lotStep == 0.1 ? 1 : lotStep == 1.0 ? 0 : 2);
}

double CalculateRiskLot(double slDistancePips)
{
   if(InpRiskPercent <= 0.0 || slDistancePips <= 0.0) return NormalizeLot(InpFixedLot);
   double equity = AccountEquity();
   if(equity <= 0.0) equity = AccountBalance();
   if(equity <= 0.0) return NormalizeLot(InpFixedLot);
   double riskAmount = equity * (InpRiskPercent / 100.0);
   double tickValue = MarketInfo(Symbol(), MODE_TICKVALUE);
   double tickSize  = MarketInfo(Symbol(), MODE_TICKSIZE);
   if(tickSize <= 0.0 || tickValue <= 0.0 || Point <= 0.0) return NormalizeLot(InpFixedLot);
   double pipVal = (tickValue / tickSize) * (Point * 10.0);
   if(pipVal <= 0.0) return NormalizeLot(InpFixedLot);
   return NormalizeLot(riskAmount / (slDistancePips * pipVal));
}

int OnInit()
{
   Print("【MT4起動】", InpTradeComment, " Magic: ", InpMagicNumber, " (London Breakout)");
   return(INIT_SUCCEEDED);
}

void OnDeinit(const int reason)
{
   Print("【MT4終了】", InpTradeComment, " Code: ", reason);
}

void OnTick()
{
   if(Point <= 0.0) return;

   if(InpCloseOnFriday && DayOfWeek() == 5 && TimeHour(TimeCurrent()) >= InpFridayCloseHour)
   {
      for(int i = OrdersTotal() - 1; i >= 0; i--)
         if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES) && OrderMagicNumber() == InpMagicNumber)
            OrderClose(OrderTicket(), OrderLots(), OrderType() == OP_BUY ? Bid : Ask, 3, clrWhite);
      return;
   }

   ExecuteMql4LondonManagement();

   if(Time[0] == lastBarTime) return;
   lastBarTime = Time[0];

   int curHour = TimeHour(TimeCurrent());
   int curDay  = TimeDay(TimeCurrent());

   if(curHour < InpTradeStartHour || curHour >= InpTradeEndHour) return;
   if(curDay == lastTradeDay) return;

   // 許容最大スプレッドチェック（PIPS単位厳密判定・ブローカー桁数2桁/3桁完全自動適応）
   double curSpreadPrice = Ask - Bid;
   double pipPoint = GetPipPoint();
   double curSpreadPips = (pipPoint > 0.0) ? (curSpreadPrice / pipPoint) : 0.0;
   double allowedMaxPips = (double)InpMaxSpread;
   if(allowedMaxPips > 20.0) allowedMaxPips = allowedMaxPips / 10.0; // ポイント指定(90pt等)の自動救済
   if(curSpreadPips > allowedMaxPips) return;

   int openCount = 0;
   for(int i = 0; i < OrdersTotal(); i++)
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES) && OrderMagicNumber() == InpMagicNumber) openCount++;
   if(openCount >= InpMaxPositions) return;

   // 東京レンジ高安値集計 (当日 1:00〜8:00)
   double asiaHigh = -1.0;
   double asiaLow  = 999999.0;
   int barsCount = iBarShift(Symbol(), 0, TimeCurrent() - 24*3600);
   if(barsCount < 10) barsCount = 100;

   for(int k = 1; k < barsCount; k++)
   {
      if(TimeDay(Time[k]) == curDay)
      {
         int h = TimeHour(Time[k]);
         if(h >= InpAsiaStartHour && h < InpAsiaEndHour)
         {
            if(High[k] > asiaHigh) asiaHigh = High[k];
            if(Low[k] < asiaLow)   asiaLow  = Low[k];
         }
      }
   }

   if(asiaHigh <= 0.0 || asiaLow >= 900000.0) return;

   double rangePips = (asiaHigh - asiaLow) / (Point * 10.0);
   if(rangePips < InpMinRangePips || rangePips > InpMaxRangePips) return;

   double trendEMA = iMA(Symbol(), 0, InpTrendEMA, 0, MODE_EMA, PRICE_CLOSE, 1);
   double curATR   = iATR(Symbol(), 0, InpATRPeriod, 1);

   bool buyBreak  = (Close[1] > asiaHigh && Open[1] <= asiaHigh && Close[1] > trendEMA);
   bool sellBreak = (Close[1] < asiaLow  && Open[1] >= asiaLow  && Close[1] < trendEMA);

   if(buyBreak)
   {
      double slPrice = NormalizeDouble(asiaLow, Digits);
      double slDist = Ask - slPrice;
      if(slDist < curATR * 0.8) { slDist = curATR * 1.2; slPrice = NormalizeDouble(Ask - slDist, Digits); }
      double tpPrice = NormalizeDouble(Ask + slDist * InpRiskRewardRatio, Digits);
      double lot = CalculateRiskLot(slDist / (Point * 10.0));
      if(OrderSend(Symbol(), OP_BUY, lot, Ask, 3, slPrice, tpPrice, InpTradeComment, InpMagicNumber, 0, clrBlue) > 0)
         lastTradeDay = curDay;
   }
   else if(sellBreak)
   {
      double slPrice = NormalizeDouble(asiaHigh, Digits);
      double slDist = slPrice - Bid;
      if(slDist < curATR * 0.8) { slDist = curATR * 1.2; slPrice = NormalizeDouble(Bid + slDist, Digits); }
      double tpPrice = NormalizeDouble(Bid - slDist * InpRiskRewardRatio, Digits);
      double lot = CalculateRiskLot(slDist / (Point * 10.0));
      if(OrderSend(Symbol(), OP_SELL, lot, Bid, 3, slPrice, tpPrice, InpTradeComment, InpMagicNumber, 0, clrRed) > 0)
         lastTradeDay = curDay;
   }
}

void ExecuteMql4LondonManagement()
{
   if(!InpUseBreakEven) return;

   for(int i = 0; i < OrdersTotal(); i++)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES) && OrderMagicNumber() == InpMagicNumber)
      {
         double openPrice = OrderOpenPrice();
         double currentSL = OrderStopLoss();
         double tpPrice   = OrderTakeProfit();

         if(OrderType() == OP_BUY)
         {
            double initialRisk = openPrice - currentSL;
            if(initialRisk > 0.0 && (Bid - openPrice) >= initialRisk)
            {
               double beSL = NormalizeDouble(openPrice + 2.0 * Point * 10.0, Digits);
               if(currentSL < beSL) OrderModify(OrderTicket(), openPrice, beSL, tpPrice, 0, clrNONE);
            }
         }
         else if(OrderType() == OP_SELL)
         {
            double initialRisk = currentSL - openPrice;
            if(initialRisk > 0.0 && (openPrice - Ask) >= initialRisk)
            {
               double beSL = NormalizeDouble(openPrice - 2.0 * Point * 10.0, Digits);
               if(currentSL == 0.0 || currentSL > beSL) OrderModify(OrderTicket(), openPrice, beSL, tpPrice, 0, clrNONE);
            }
         }
      }
   }
}
`;
}
