/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Language } from '../types';

export interface Translations {
  common: {
    freeEditionBadge: string;
    allView: string;
    simulationNav: string;
    codeNav: string;
    salesNav: string;
    proUnlockNav: string;
    proFeaturesBtn: string;
    aiAnalysisBtn: string;
    aiGenerating: string;
    exportAllBtn: string;
    toastGenerated: string;
    toastAiApplied: string;
    toastExported: string;
    copied: string;
    copy: string;
    close: string;
  };
  header: {
    title: string;
    subtitle: string;
    freeBadge: string;
  };
  config: {
    title: string;
    freeBadge: string;
    description: string;
    pairTitle: string;
    pairLimitNotice: string;
    timeframeTitle: string;
    timeframeNotice: string;
    pfTitle: string;
    pfLimitNotice: string;
    ddTitle: string;
    ddLimitNotice: string;
    freqTitle: string;
    freqNotice: string;
    periodTitle: string;
    periodNotice: string;
    capitalTitle: string;
    capitalNotice: string;
    capitalValue: string;
    capitalFixedTag: string;
    capitalDesc: string;
    capitalSubNote: string;
    capitalProHint: string;
    lotTitle: string;
    lotLabel: string;
    lotValue: string;
    lotFixedTag: string;
    lotDesc: string;
    lotSubNote: string;
    lotProHint: string;
    lotProButton: string;
    positionsTitle: string;
    positionsLimitNotice: string;
    positionsOption1: string;
    positionsOptionLe5: string;
    positionsOptionLe10: string;
    positionsOptionLe20: string;
    positionsOptionGe20: string;
    positionsOptionAuto: string;
    freeEditionProcessTime: string;
    proEditionProcessTime: string;
    waveformDisclaimer: string;
    futureFeaturesNote: string;
    btnGenerate: string;
    btnGenerating: string;
    btnSubText: string;
    speedHintNote: string;
    speedHintLink: string;
    proOnlyBadge: string;
    recommendedBadge: string;
    stableBadge: string;
    swingBadge: string;
    autoBadge: string;
    freeRefBadge: string;
  };
  backtest: {
    title: string;
    badge: string;
    desc: (pair: string, tf: string) => string;
    unlockLongTerm: string;
    resultCardTitle: string;
    shortPeriodBadge: string;
    pfLabel: string;
    maxDdLabel: string;
    freqLabel: string;
    periodLabel: string;
    periodSub: string;
    periodValue: string;
    baseCapitalLabel: string;
    baseCapitalValue: string;
    profitLabel: string;
    profitSub: string;
    capitalNoticeLine: string;
    totalTradesLine: string;
    winRateLine: string;
    lotCardTitle: string;
    lotCardFixedTag: string;
    lotUpgradeBtn: string;
    eaEvalTitle: string;
    eaEvalBadge: string;
    eaEvalGuideline: string;
    curveFitLink: string;
    payoffLabel: string;
    payoffTag: string;
    plRatioLabel: string;
    plRatioTag: string;
    maxConsecWinsLabel: string;
    maxConsecWinsTag: string;
    maxConsecLossesLabel: string;
    maxConsecLossesTag: string;
    weeklyFreqLabel: string;
    weeklyFreqTag: string;
    recoveryFactorLabel: string;
    recoveryFactorTag: string;
    evalDisclaimerTitle: string;
    evalDisclaimerText: string;
    tabMetrics: string;
    tabChart: string;
    tabTrades: (count: number) => string;
    tabNote: string;
    metricsWinRateTrades: string;
    metricsTradesPerWeek: string;
    metricsTradeAutoOpt: string;
    metricsAvgProfitLoss: string;
    metricsRiskRewardRatio: string;
    metricsSharpeRatio: string;
    metricsSharpeNote: string;
    chartTitle: string;
    chartFinalBalance: string;
    sharpeRatio: string;
    sharpeRatioNote: string;
    chartBalance: string;
    chartFinal: string;
    tradeFilterAll: string;
    tradeFilterBuy: string;
    tradeFilterSell: string;
    tradeFilterWins: string;
    tradeFilterLosses: string;
    colId: string;
    colOpenTime: string;
    colType: string;
    colLots: string;
    colProfitPips: string;
    colProfitAmount: string;
    colReason: string;
    colDateTime: string;
    colPips: string;
    colAmount: string;
    metricsTitle: string;
    metricsTag: string;
    metricsSubTitle: string;
    curveFitUpgradeHint: string;
    expectedPayoff: string;
    expectedPayoffNote: string;
    profitLossRatio: string;
    profitLossRatioNote: string;
    maxConsecutiveWins: string;
    maxConsecutiveWinsNote: string;
    maxConsecutiveLosses: string;
    maxConsecutiveLossesNote: string;
    estTradesPerWeek: string;
    estTradesPerWeekNote: string;
    recoveryFactor: string;
    recoveryFactorNote: string;
    disclaimerTitle: string;
    disclaimerText: string;
    tabSummary: string;
    tabNotice: string;
    winRateTrades: string;
    weeklyTrades: string;
    weeklyTradesNote: string;
    avgProfitLoss: string;
    upgradeLongTerm: string;
    tableTitle: string;
    tableTag: string;
    pf: string;
    maxDrawdown: string;
    targetFreq: string;
    simPeriod: string;
    simPeriodNote: string;
    simPeriodValue: string;
    baseCapital: string;
    simProfit: string;
    simProfitNote: string;
    profitNotice: string;
    minLotLabel: string;
    minLotTag: string;
    minLotDesc: string;
    minLotNote: string;
  };
  sourceCode: {
    title: string;
    badge: string;
    subtitle: string;
    compileBadge: string;
    desc: string;
    copied: string;
    copyCode: string;
    scanning: string;
    rescanBtn: string;
    compileNotice: string;
    auditVerified: string;
    auditDesc: string;
    auditScore: string;
    passed: string;
    paramName: string;
    paramType: string;
    paramDefault: string;
    paramDesc: string;
    paramAdjustable: string;
    copyBtn: string;
    downloadBtn: string;
    tabCode: string;
    tabAudit: string;
    tabGuide: string;
    auditTitle: string;
    auditBadge: string;
    btnRecheck: string;
    btnRechecking: string;
    zeroDivideTitle: string;
    zeroDivideDesc: string;
    errorGuardTitle: string;
    errorGuardDesc: string;
    lotNormTitle: string;
    lotNormDesc: string;
    guideTitle: string;
    step1Title: string;
    step1Desc: string;
    step2Title: string;
    step2Desc: string;
    step3Title: string;
    step3Desc: string;
    lockedBadge: string;
    lockedTitle: string;
    lockedDesc: string;
    unlockBtn: string;
    copyLocked: string;
    copyBtnLocked: string;
    downloadLocked: string;
    featureListTitle: string;
    featureItem1: string;
    featureItem2: string;
    featureItem3: string;
    featureItem4: string;
  };
  salesPackage: {
    title: string;
    badge: string;
    desc: string;
    subtitle: string;
    openMarket: string;
    copiedText: string;
    copyAll: string;
    previewTitle: string;
    highlights: string;
    recommendedSpec: string;
    broker: string;
    leverage: string;
    deposit: string;
    vps: string;
    vpsDesc: string;
    faqTitle: string;
    disclaimerTitle: string;
    copyAllBtn: string;
    tabOverview: string;
    tabManual: string;
    tabFaq: string;
    tabDisclaimer: string;
    recommendedEnv: string;
    brokerLabel: string;
    leverageLabel: string;
    minDepositLabel: string;
    recDepositLabel: string;
    vpsLabel: string;
  };
  upgradeModal: {
    badge: string;
    exclusive: string;
    close: string;
    title: string;
    bannerDefault: string;
    ctaDefault: string;
    triggerPairTitle: string;
    triggerPairMsg: string;
    triggerPfTitle: string;
    triggerPfMsg: string;
    triggerDdTitle: string;
    triggerDdMsg: string;
    triggerPeriodTitle: string;
    triggerPeriodMsg: string;
    triggerCapitalTitle: string;
    triggerCapitalMsg: string;
    triggerLotTitle: string;
    triggerLotMsg: string;
    triggerMaxPositionsTitle: string;
    triggerMaxPositionsMsg: string;
    triggerMaxPositionsCta: string;
    triggerCurveFitTitle: string;
    triggerCurveFitMsg: string;
    featuresHeader: string;
    feature1Title: string;
    feature1Desc: string;
    feature2Title: string;
    feature2Desc: string;
    feature3Title: string;
    feature3Desc: string;
    feature4Title: string;
    feature4Desc: string;
    feature5Title: string;
    feature5Desc: string;
    feature6Title: string;
    feature6Desc: string;
    migrationTitle: string;
    migrationDesc: string;
    continueFree: string;
    proBadge: string;
    defaultTitle: string;
    defaultBanner: string;
    defaultCta: string;
    pairTitle: string;
    pairBanner: string;
    pairCta: string;
    pfTitle: string;
    pfBanner: string;
    pfCta: string;
    ddTitle: string;
    ddBanner: string;
    ddCta: string;
    periodTitle: string;
    periodBanner: string;
    periodCta: string;
    capitalTitle: string;
    capitalBanner: string;
    capitalCta: string;
    lotTitle: string;
    lotBanner: string;
    lotCta: string;
    curveFitTitle: string;
    curveFitBanner: string;
    curveFitCta: string;
    triggerCodeTitle: string;
    triggerCodeMsg: string;
    triggerCodeCta: string;
    triggerSpeedTitle: string;
    triggerSpeedMsg: string;
    triggerSpeedCta: string;
    proFeatureHeader: string;
    closeBtn: string;
  };
  generationProgress: {
    modalTitle: string;
    modalSubtitle: string;
    statusSimulating: string;
    step1Title: string;
    step1Desc: string;
    step2Title: string;
    step2Desc: string;
    step3Title: string;
    step3Desc: string;
    step4Title: string;
    step4Desc: string;
    step5Title: string;
    step5Desc: string;
    processedBarsLabel: string;
    simulatedTradesLabel: string;
    winRateLabel: string;
    currentPfLabel: string;
    auditLabel: string;
    ticksProcessedLabel: string;
    monteCarloLabel: string;
    equityCurveTitle: string;
    generationLabel: string;
    balanceLabel: string;
    profitPipsLabel: string;
    candidateHighNotice: string;
    stressTestNotice: string;
    optimalLockedNotice: string;
    fitnessLabel: string;
    trialCounterLabel: string;
    rapidSweepBadge: string;
    retryReason1: string;
    retryReason2: string;
    retryReason3: string;
    retrySuccess: string;
    stageTitle1: string;
    stageTitle2: string;
    stageTitle3: string;
    stageTitle4: string;
    skipSpeedBtn: string;
    skipSpeedHint: string;
    recentTradesTitle: string;
    speedProBannerTitle: string;
    speedProBannerDesc: string;
    speedProBtn: string;
    progressPercent: string;
  };
  aiModal: {
    title: string;
    subtitle: string;
    researchPrompt: string;
    gogojungleLink: string;
    youtubeLink: string;
    templatesTitle: string;
    customPromptLabel: string;
    customPromptPlaceholder: string;
    cancel: string;
    generate: string;
    generating: string;
    quickIdeasTitle: string;
    promptLabel: string;
    promptPlaceholder: string;
    strategyTypeLabel: string;
    btnGenerate: string;
    btnGenerating: string;
    closeBtn: string;
  };
}

export const translations: Record<Language, Translations> = {
  ja: {
    common: {
      freeEditionBadge: '無料体験版 (Free Trial)',
      allView: '全体画面',
      simulationNav: '参考シミュレーション結果',
      codeNav: 'MQL5 / MQL4 コード & エラー検証',
      salesNav: '出品用マニュアル & FAQ',
      proUnlockNav: '上位版で全機能開放',
      proFeaturesBtn: '上位版の機能を見る',
      aiAnalysisBtn: 'AI手法分析',
      aiGenerating: 'AI作成中...',
      exportAllBtn: '全データ出力',
      toastGenerated: 'EA自動生成完了: 3か月参考シミュレーション & MQLコードを出力しました',
      toastAiApplied: 'AI生成ロジックとMQL5/MQL4コードを適用しました',
      toastExported: '無料体験版パッケージ (MQLコード・3か月検証・出品文) を出力しました',
      copied: 'コピーしました',
      copy: 'コピー',
      close: '閉じる',
    },
    header: {
      title: '簡単EA作成ツール EA Maker Zero',
      subtitle: '通貨ペア・時間足・PF・最大DD・取引回数を選んでMQL4/MQL5コードを無料自動生成',
      freeBadge: '無料体験版 (Free Trial)',
    },
    config: {
      title: '無料体験版 EA生成パラメータ設定',
      freeBadge: '無料体験版 (Free Trial)',
      description: '各項目を選択し、無料版の制限条件を確認のうえ、下のボタンからEA自動生成を実行してください。',
      pairTitle: '1. 通貨ペア (Currency Pair)',
      pairLimitNotice: '無料版：1ペアのみ利用可能 (上位版で全通貨開放)',
      timeframeTitle: '2. 時間足 (Timeframe)',
      timeframeNotice: '無料版でも全時間足を選択可能',
      pfTitle: '3. プロフィットファクター目標 (PF)',
      pfLimitNotice: '無料版：PF 1.2+ のみ (上位版で1.5〜2.0+開放)',
      ddTitle: '4. 許容最大ドローダウン (Max Drawdown)',
      ddLimitNotice: '無料版：最大DD 10%固定 (上位版で3%・5%指定可能)',
      freqTitle: '5. 希望取引回数 (Trade Frequency)',
      freqNotice: '無料版でも全回数を選択可能',
      periodTitle: '6. バックテスト検証期間 (Backtest Period)',
      periodNotice: '無料版：3か月固定 (上位版で1〜5年長期検証)',
      capitalTitle: '7. 運用予定資金 (Base Capital)',
      capitalNotice: '無料版：基準資金10万円固定 (上位版で自由設定可能)',
      capitalValue: '100,000円',
      capitalFixedTag: '無料版固定・基準資金',
      capitalDesc: '無料版の予想利益額は、基準資金10万円で算出しています。',
      capitalSubNote: '※無料版のため資金設定は固定されています。',
      capitalProHint: '上位版なら10万〜1,000万円で資金設定可能',
      lotTitle: '8. 最小ロット (Minimum Lot)',
      lotLabel: '最小ロット',
      lotValue: '0.01 lot',
      lotFixedTag: '無料版固定・参考値',
      lotDesc: 'リスクを抑えた検証用の最小取引単位です。実際の取引可否や適切なロット数は、利用するブローカーの仕様と口座残高を確認してください。',
      lotSubNote: '※参考値です。実際の最小取引数量は、利用するブローカーと口座仕様をご確認ください。',
      lotProHint: '任意ロット・複利設定をするには？ (上位版)',
      lotProButton: '上位版なら任意ロット・複利計算に対応',
      positionsTitle: '9. 最大同時保有ポジション数 (Maximum Concurrent Positions)',
      positionsLimitNotice: '無料版：1ポジションのみ (上位版で最大同時保有ポジション数を任意設定可能)',
      positionsOption1: '1ポジション',
      positionsOptionLe5: '最大5ポジション',
      positionsOptionLe10: '最大10ポジション',
      positionsOptionLe20: '最大20ポジション',
      positionsOptionGe20: '20ポジション超',
      positionsOptionAuto: 'その他',
      freeEditionProcessTime: '無料版は、条件確認用の簡易シミュレーションを行うため、通常数分程度で完了します。',
      proEditionProcessTime: '上位版では、より複雑な条件、長期検証、資金管理、ポジション数、EAコード生成・検証などを行うため、生成完了まで30分を超える場合があります。',
      waveformDisclaimer: '※表示中の波形・候補表示は、検証プロセスを分かりやすく伝えるための視覚化です。',
      futureFeaturesNote: '※グリッド、トラリピ、多層ピラミッディング、複利設定は今後対応予定（現在準備中）です。',
      btnGenerate: 'EA自動生成を開始する (MQL4/MQL5コード出力)',
      btnGenerating: 'EA生成＆参考バックテスト検証中...',
      btnSubText: '※MT5ストラテジーテスター不要・ブラウザ上で即座に検証完了',
      speedHintNote: '※無料版は通常数分程度、上位版は処理内容により30分以上かかる場合があります。',
      speedHintLink: '⚡ 有料版（Pro）なら高速クラウド並列処理で【約10秒の超高速バックテスト】',
      proOnlyBadge: '上位版',
      recommendedBadge: '推奨',
      stableBadge: '安定型',
      swingBadge: 'スイング',
      autoBadge: '全自動',
      freeRefBadge: '無料版 (参考値)',
    },
    backtest: {
      title: 'EA自動生成 & 参考シミュレーション結果',
      badge: 'Free Simulation',
      desc: (pair, tf) => `設定したパラメータ（${pair} / ${tf}）に基づき、3か月の参考バックテストを高速検証しました。`,
      unlockLongTerm: '1年〜5年 長期検証を開放 (上位版)',
      resultCardTitle: '参考シミュレーション結果',
      shortPeriodBadge: '無料版のため短期間（3か月）検証',
      pfLabel: 'PF',
      maxDdLabel: '最大ドローダウン',
      freqLabel: '希望取引回数',
      periodLabel: 'シミュレーション期間',
      periodSub: '※無料版のため短期間',
      periodValue: '3か月',
      baseCapitalLabel: '基準資金',
      baseCapitalValue: '100,000円',
      profitLabel: '参考シミュレーション利益額',
      profitSub: '※金額で表示（利益率非表示）',
      capitalNoticeLine: '※予想利益額は、基準資金10万円で算出しています。',
      totalTradesLine: '総取引数',
      winRateLine: '勝率',
      lotCardTitle: '最小ロット (検証条件)',
      lotCardFixedTag: '無料版固定',
      lotUpgradeBtn: 'ロット変更・複利設定 (上位版)',
      eaEvalTitle: 'EA評価指標',
      eaEvalBadge: '内蔵モデルによる参考値 / 簡易評価',
      eaEvalGuideline: '判定の目安（実測値・確定値ではありません）',
      curveFitLink: 'カーブフィッティング率を見るには？',
      payoffLabel: '期待利得 (1トレード)',
      payoffTag: '参考シミュレーション値',
      plRatioLabel: '損益比 (平均利益/損失)',
      plRatioTag: '内蔵モデル参考値',
      maxConsecWinsLabel: '最大連勝数',
      maxConsecWinsTag: '簡易評価 (3か月)',
      maxConsecLossesLabel: '最大連敗数',
      maxConsecLossesTag: '簡易評価 (3か月)',
      weeklyFreqLabel: '推定週間取引頻度',
      weeklyFreqTag: '判定の目安',
      recoveryFactorLabel: 'リカバリーファクター',
      recoveryFactorTag: '参考評価 (純利益/最大DD)',
      evalDisclaimerTitle: '【検証データの取り扱いについて】',
      evalDisclaimerText: '本結果は過去データを使用したシミュレーションであり、将来の利益を保証するものではありません。本画面の指標は、実際の市場ティックデータやMT4/MT5ストラテジーテスターによる実測値・実績値・確定値ではなく、ブラウザ内蔵モデルによる「参考シミュレーション値・簡易評価・判定の目安」です。実運用前の参考情報としてご利用ください。',
      tabMetrics: '詳細メトリクス',
      tabChart: '資産曲線 (3か月)',
      tabTrades: (count) => `取引履歴ログ (${count}件)`,
      tabNote: 'MT5を使わずに即時検証完了',
      metricsWinRateTrades: '勝率 / 取引数',
      metricsTradesPerWeek: '週平均取引数',
      metricsTradeAutoOpt: '希望設定に自動最適化',
      metricsAvgProfitLoss: '平均利益 / 平均損失',
      metricsRiskRewardRatio: 'リスクリワード比',
      metricsSharpeRatio: 'Sharpe比',
      metricsSharpeNote: 'リスク調整後リターン優良',
      chartTitle: '3か月 残高推移 (初期資金: 100,000円)',
      chartFinalBalance: '最終残高',
      sharpeRatio: 'Sharpe比',
      sharpeRatioNote: 'リスク調整後リターン優良',
      chartBalance: '3か月 残高推移 (初期資金: 100,000円)',
      chartFinal: '最終残高',
      tradeFilterAll: 'ALL',
      tradeFilterBuy: 'BUY',
      tradeFilterSell: 'SELL',
      tradeFilterWins: 'WINS',
      tradeFilterLosses: 'LOSSES',
      colId: '#',
      colOpenTime: '日時',
      colType: '売買',
      colLots: 'Lot',
      colProfitPips: '損益(pips)',
      colProfitAmount: '損益(円)',
      colReason: '決済理由',
      colDateTime: '日時',
      colPips: '損益(pips)',
      colAmount: '損益(円)',
      metricsTitle: 'EA評価指標',
      metricsTag: '内蔵モデルによる参考値 / 簡易評価',
      metricsSubTitle: '判定の目安（実測値・確定値ではありません）',
      curveFitUpgradeHint: 'カーブフィッティング率を見るには？',
      expectedPayoff: '期待利得 (1トレード)',
      expectedPayoffNote: '参考シミュレーション値',
      profitLossRatio: '損益比 (平均利益/損失)',
      profitLossRatioNote: '内蔵モデル参考値',
      maxConsecutiveWins: '最大連勝数',
      maxConsecutiveWinsNote: '簡易評価 (3か月)',
      maxConsecutiveLosses: '最大連敗数',
      maxConsecutiveLossesNote: '簡易評価 (3か月)',
      estTradesPerWeek: '推定週間取引頻度',
      estTradesPerWeekNote: '判定の目安',
      recoveryFactor: 'リカバリーファクター',
      recoveryFactorNote: '参考評価 (純利益/最大DD)',
      disclaimerTitle: '【検証データの取り扱いについて】',
      disclaimerText: '本結果は過去データを使用したシミュレーションであり、将来の利益を保証するものではありません。本画面の指標は、実際の市場ティックデータやMT4/MT5ストラテジーテスターによる実測値・実績値・確定値ではなく、ブラウザ内蔵モデルによる「参考シミュレーション値・簡易評価・判定の目安」です。実運用前の参考情報としてご利用ください。',
      tabSummary: '詳細メトリクス',
      tabNotice: 'MT5を使わずに即時検証完了',
      winRateTrades: '勝率 / 取引数',
      weeklyTrades: '週平均取引数',
      weeklyTradesNote: '希望設定に自動最適化',
      avgProfitLoss: '平均利益 / 平均損失',
      upgradeLongTerm: '1年・3年・5年の長期検証は上位版で利用可能',
      tableTitle: '参考シミュレーション結果',
      tableTag: '※内蔵モデルによる参考値',
      pf: 'PF (プロフィットファクター)',
      maxDrawdown: '最大ドローダウン',
      targetFreq: '希望取引回数',
      simPeriod: 'シミュレーション期間',
      simPeriodNote: '※無料版のため短期間',
      simPeriodValue: '3か月',
      baseCapital: '基準資金',
      simProfit: '参考シミュレーション利益額',
      simProfitNote: '※金額で表示（利益率非表示）',
      profitNotice: '※予想利益額は、基準資金10万円で算出しています。',
      minLotLabel: '最小ロット (検証条件)',
      minLotTag: '無料版固定',
      minLotDesc: '無料体験版では安全検証のため、すべてのシミュレーションおよびMQL出力コードは最小ロット（0.01 lot）固定で稼働します。',
      minLotNote: '※任意の固定ロット指定や複利ロット自動計算機能は、上位版（EA Maker Zero Pro）にて提供されます。',
    },
    sourceCode: {
      title: '販売用EA完成ソースコード',
      badge: '100% コンパイル可能',
      subtitle: '取引エラー防止・ゼロ除算安全ガード・ブローカー適応ロット正規化が組み込まれた本番コード',
      compileBadge: '100% コンパイル可能',
      desc: '取引エラー防止・ゼロ除算安全ガード・ブローカー適応ロット正規化が組み込まれた本番コード',
      copied: 'コピー完了',
      copyCode: 'コードをコピー',
      scanning: '安全監査を実行中...',
      rescanBtn: '安全性を再検証する',
      compileNotice: 'MetaEditor 5 (Build 3800+) / MetaEditor 4 にてエラー0件でコンパイル可能です',
      auditVerified: '厳格エラー検知 & ゼロ除算防止チェック済み',
      auditDesc: 'MQL5標準取引ライブラリに準拠し、未定義変数や不正ポインタ参照はありません',
      auditScore: 'エラー 0件・警告 0件',
      passed: '合格',
      paramName: 'パラメータ名',
      paramType: '型',
      paramDefault: 'デフォルト値',
      paramDesc: '解説・役割',
      paramAdjustable: '調整可否',
      copyBtn: 'コードをコピー',
      downloadBtn: 'ファイルをダウンロード',
      tabCode: 'MQLソースコード',
      tabAudit: '安全監査 & ゼロ除算検査',
      tabGuide: 'MT4/MT5導入マニュアル',
      auditTitle: '厳格エラー検知 & ゼロ除算防止チェック済み',
      auditBadge: 'エラー 0件・警告 0件',
      btnRecheck: '安全性を再検証する',
      btnRechecking: '検査中...',
      zeroDivideTitle: 'ゼロ除算防止ガード (Zero-Division SafeGuard)',
      zeroDivideDesc: 'ATR計算、Point値、ティックサイズ、スプレッド除算処理において、分母がゼロまたはマイナスの場合は安全にフォールバック処理を行います。',
      errorGuardTitle: '取引サーバーエラー自動リトライ (Error 10004/10006/130対応)',
      errorGuardDesc: 'リクオート・コンテキストビジー・無効なスリッページ時に最大3回のリトライ処理とログ出力を自動実行します。',
      lotNormTitle: 'ブローカーロット正規化 & マージンチェック',
      lotNormDesc: 'ブローカーごとの最小ロット(minLot)、最大ロット(maxLot)、刻みステップ(lotStep)に合わせて自動丸めを行い、OrderSendエラーを未然に防止します。',
      guideTitle: 'MT4 / MT5へのEA導入手順',
      step1Title: '1. ソースコードのダウンロード',
      step1Desc: '右上の「ファイルをダウンロード」をクリックし、.mq5 または .mq4 ファイルを保存します。',
      step2Title: '2. MetaEditorで開いてコンパイル',
      step2Desc: 'MetaTraderのMetaEditorを開き、ファイルをExpertsフォルダに配置して「コンパイル(F7)」を押します。エラー0件を確認します。',
      step3Title: '3. チャートにドラッグ＆ドロップ',
      step3Desc: 'ナビゲーターウィンドウから該当EAを対象チャートに適用し、「アルゴリズム取引を許可」にチェックを入れます。',
      lockedBadge: '上位版 (Pro) 限定',
      lockedTitle: 'EAソースコードは上位版（Pro）限定です',
      lockedDesc: '無料版ではロジックの3か月シミュレーション検証、安全監査、購入者用パラメータ設計をご確認いただけます。MetaEditorでコンパイルしてMT4 / MT5で即座に運用・出品できる本番用MQLソースコード（.mq5 / .mq4）の閲覧・出力・ダウンロードは、上位版（EA Maker Zero Pro）にてご利用いただけます。',
      unlockBtn: '上位版でソースコードを出力・ダウンロード',
      copyLocked: 'ソースコードのコピーは上位版（Pro）限定です',
      copyBtnLocked: 'コードをコピー (Pro限定)',
      downloadLocked: '保存 (Pro限定)',
      featureListTitle: '上位版（EA Maker Zero Pro）で開放されるコード仕様:',
      featureItem1: 'MetaEditor 4 / 5 完全準拠のコンパイル可能コード全文（.mq5 / .mq4）',
      featureItem2: '取引サーバーエラー（Error 10004/10006/130）自動リトライ＆診断ハンドラ',
      featureItem3: 'ゼロ除算防止・ブローカー適応ロット正規化（MinLot/LotStep自動丸め）',
      featureItem4: 'GogoJungleなどのマーケットプレイス即時出品・商用利用対応',
    },
    salesPackage: {
      title: 'GogoJungle・出品用商品ページ＆マニュアル',
      badge: 'そのままコピペ出品可能',
      desc: '購入者が迷わないパラメータ解説・推奨環境・Q&A・免責事項がすべて揃った販売パッケージ',
      subtitle: '購入者が迷わないパラメータ解説・推奨環境・Q&A・免責事項がすべて揃った販売パッケージ',
      openMarket: 'GogoJungleを開く',
      copiedText: '出品用テキストをコピー完了',
      copyAll: '出品文面を一括コピー',
      previewTitle: '出品タイトル案',
      highlights: '商品の魅力・特長ポイント (購入者アピール)',
      recommendedSpec: '購入者向け 推奨運用スペック',
      broker: '推奨ブローカー',
      leverage: '推奨レバレッジ',
      deposit: '推奨証拠金',
      vps: 'VPS稼働',
      vpsDesc: '24時間安定稼働推奨',
      faqTitle: '購入者からの想定質問 & 回答 (FAQ)',
      disclaimerTitle: '投資リスク及び免責事項 (GogoJungle規定記載用)',
      copyAllBtn: '出品文・マニュアルを一括コピー',
      tabOverview: '商品説明・特徴',
      tabManual: 'パラメータマニュアル',
      tabFaq: 'FAQ・よくある質問',
      tabDisclaimer: '注意事項・免責事項',
      recommendedEnv: '推奨動作環境',
      brokerLabel: '推奨ブローカー',
      leverageLabel: '推奨レバレッジ',
      minDepositLabel: '最低証拠金',
      recDepositLabel: '推奨証拠金',
      vpsLabel: 'VPS推奨',
    },
    upgradeModal: {
      badge: 'Pro Edition',
      exclusive: '上位版限定機能',
      close: '閉じる',
      title: '上位版（EA Maker Zero Pro）の機能拡張',
      bannerDefault: '無料版をご利用いただきありがとうございます。上位版へアップグレードすることで、すべての制限を解除しプロ仕様のEA開発環境をご利用いただけます。',
      ctaDefault: '上位版の機能を見る',
      triggerPairTitle: '通貨ペアの制限について',
      triggerPairMsg: '無料版では1回につき1通貨ペアのみ利用できます。複数通貨ペアや追加通貨ペアを利用するにはアップグレードしてください。',
      triggerPfTitle: 'プロフィットファクター (PF) の制限について',
      triggerPfMsg: 'PF 1.5以上、PF 1.8以上などの高度な条件は上位版で利用できます。',
      triggerDdTitle: '最大ドローダウン条件の制限について',
      triggerDdMsg: 'より厳しいドローダウン条件を指定するには、上位版をご利用ください。',
      triggerPeriodTitle: 'シミュレーション検証期間の制限について',
      triggerPeriodMsg: '無料版では3か月の参考シミュレーションを利用できます。1年・3年・5年の長期ウォークフォワード検証は上位版で利用可能です。',
      triggerCapitalTitle: '運用予定資金の設定について',
      triggerCapitalMsg: '無料版の予想利益額は、基準資金10万円で算出しています。10万円〜1,000万円までの自由な運用資金設定や複利設定は上位版で利用可能です。',
      triggerLotTitle: '取引ロット数の設定について',
      triggerLotMsg: '無料版では安全検証のため「最小ロット（0.01 lot）」に固定されています。任意の固定ロット指定や複利ロット自動計算機能は上位版で利用可能です。',
      triggerCurveFitTitle: 'カーブフィッティング率（過剰最適化度）の計算・表示について',
      triggerCurveFitMsg: '有料版（上位版）では、ヒストリカルデータを用いたインサンプル（IS）とアウトオブサンプル（OOS）のウォークフォワード分析により、カーブフィッティング率（過剰最適化の危険度%）を精密に計算・評価表示することが可能です。',
      featuresHeader: '上位版（EA Maker Zero Pro）で開放される機能',
      feature1Title: '全通貨ペア & マルチ通貨ポートフォリオ対応',
      feature1Desc: 'USD/JPY、GBP/JPY、EUR/JPY、ゴールド(XAU/USD)など主要全通貨ペアを無制限生成。',
      feature2Title: 'PF 1.5〜2.0+ 高期待値フィルター',
      feature2Desc: 'だまし相場を極限まで排除し、プロ販売用として人気の高い高勝率・高PFモデルを設計可能。',
      feature3Title: '最大DD 3%・5%以下の鉄壁防衛設計',
      feature3Desc: '大口資金運用でも安心して放置できる極限の低ドローダウン条件を厳格に指定可能。',
      feature4Title: '1年・3年・5年の長期バックテスト検証',
      feature4Desc: '相場サイクル全体を通じた長期堅牢性をMT5を使わずブラウザ上で即座に確認。',
      feature5Title: '運用予定資金の自由指定（10万〜1,000万円）',
      feature5Desc: 'ご自身の運用予算に合わせたロット自動計算・複利シミュレーションに対応。',
      feature6Title: 'Gemini AIによるカスタム手法EA化が無制限',
      feature6Desc: 'YouTube手法やオリジナルロジックを自然言語でEA化し、販売用パッケージを即時生成。',
      migrationTitle: '無料版で生成したMQLコードや設定データもそのまま引き継ぎ可能',
      migrationDesc: '上位版への移行後も、作成したストラテジーやバックテスト結果はそのまま活用いただけます。',
      continueFree: '無料版をそのまま続ける',
      proBadge: 'Pro Edition',
      defaultTitle: '上位版（EA Maker Zero Pro）の機能拡張',
      defaultBanner: '無料版をご利用いただきありがとうございます。上位版へアップグレードすることで、すべての制限を解除しプロ仕様のEA開発環境をご利用いただけます。',
      defaultCta: '上位版の機能を見る',
      pairTitle: '通貨ペアの制限について',
      pairBanner: '無料版では1回につき1通貨ペアのみ利用できます。複数通貨ペアや追加通貨ペアを利用するにはアップグレードしてください。',
      pairCta: '上位版の機能を見る',
      pfTitle: 'プロフィットファクター (PF) の制限について',
      pfBanner: 'PF 1.5以上、PF 1.8以上などの高度な条件は上位版で利用できます。',
      pfCta: 'PF条件を拡張する',
      ddTitle: '最大ドローダウン条件の制限について',
      ddBanner: 'より厳しいドローダウン条件を指定するには、上位版をご利用ください。',
      ddCta: 'より低リスクな条件を開放',
      periodTitle: 'シミュレーション検証期間の制限について',
      periodBanner: '無料版では3か月の参考シミュレーションを利用できます。1年・3年・5年の長期ウォークフォワード検証は上位版で利用可能です。',
      periodCta: '長期検証機能を開放する',
      capitalTitle: '運用予定資金の設定について',
      capitalBanner: '無料版の予想利益額は、基準資金10万円で算出しています。10万円〜1,000万円までの自由な運用資金設定や複利設定は上位版で利用可能です。',
      capitalCta: '資金設定をカスタマイズする',
      lotTitle: '取引ロット数の設定について',
      lotBanner: '無料版では安全検証のため「最小ロット（0.01 lot）」に固定されています。任意の固定ロット指定や複利ロット自動計算機能は上位版で利用可能です。',
      lotCta: 'ロット設定を拡張する',
      triggerMaxPositionsTitle: 'ポジション数設定・複数エントリー機能の開放',
      triggerMaxPositionsMsg: '無料版は安全重視のため【1ポジション固定】に制限されています。上位版（EA Maker Zero Pro）へアップグレードすることで、最大ポジション数を「5以下」「10以下」「20以下」「20〜」「お任せ」まで自由に設定可能！グリッド、トラリピ、多層ナンピン・ピラミッディングなど高度な資金管理戦略を自在に構築できます。',
      triggerMaxPositionsCta: 'ポジション数設定（Pro）を開放する',
      curveFitTitle: 'カーブフィッティング率（過剰最適化度）の計算・表示について',
      curveFitBanner: '有料版（上位版）では、ヒストリカルデータを用いたインサンプル（IS）とアウトオブサンプル（OOS）のウォークフォワード分析により、カーブフィッティング率（過剰最適化の危険度%）を精密に計算・評価表示することが可能です。',
      curveFitCta: 'カーブフィッティング検証を開放',
      triggerCodeTitle: 'EAソースコードの出力・ダウンロードについて',
      triggerCodeMsg: '無料版ではEAソースコードの閲覧・ダウンロードは制限されています。上位版（EA Maker Zero Pro）へアップグレードすることで、エラー制御・ゼロ除算ガード・ロット正規化が組み込まれた本番用MQL5/MQL4ソースコードの全文閲覧・ダウンロードが可能になります。',
      triggerCodeCta: '上位版でソースコードを出力する',
      triggerSpeedTitle: '超高速クラウド並列バックテスト（大幅短縮 / 約10秒）',
      triggerSpeedMsg: '無料版はブラウザ環境で精緻な全ティックシミュレーションと遺伝的アルゴリズム最適化を順次実行するため、約5分間の検証待機時間が発生します。上位版（EA Maker Zero Pro）では、専用クラウド分散クラスタが複数パラメータと長期間ヒストリカルデータを並列処理！【約10〜15秒の超高速バックテスト】を実現します。',
      triggerSpeedCta: '高速版（Pro）を開放する',
      proFeatureHeader: 'プロフェッショナル版で解放される主要機能',
      closeBtn: '閉じる',
    },
    generationProgress: {
      modalTitle: '高精度EAバックテスト＆全ティック走査シミュレーション実行中',
      modalSubtitle: '過去3か月分のM15ティックデータ（約128,000ティック）と約定負荷を順次検証中（所要時間：約5分）',
      statusSimulating: '精密バックテスト進行中',
      step1Title: '1. ヒストリカルティックデータ読込＆スプレッドモデル構築',
      step1Desc: '過去ローソク足 2,880本 / 128,450ティックを走査中。変動スプレッド（1.2〜2.8 pips）および週末ギャップを再構成...',
      step2Title: '2. テクニカルシグナル検証＆エントリー判定',
      step2Desc: 'EMA / MACDフィルター、ボラティリティATR走査。全バーにおける買/売シグナル生成とダマシ除外ロジックを1ティックずつ照合...',
      step3Title: '3. 約定シミュレーション＆スリッページ負荷テスト',
      step3Desc: '逆指値・指値の約定率、深夜帯スプレッド拡大ストレステスト、ゼロ除算回避ロジックを全自動監査...',
      step4Title: '4. ドローダウン解析＆パフォーマンス指標集計',
      step4Desc: 'プロフィットファクター、リカバリーファクター、最大連勝/連敗数、Sharpe比、モンテカルロ試行1,000回を集計完了...',
      step5Title: '5. MQL5/MQL4本番仕様コード整合性チェック',
      step5Desc: 'Error 10004/10006自動リトライ構造、注文ロット正規化関数の整合性を最終監査中...',
      processedBarsLabel: '解析ローソク足数',
      simulatedTradesLabel: '検知トレード数',
      winRateLabel: '暫定勝率',
      currentPfLabel: 'プロフィットファクター',
      auditLabel: '安全監査ステータス',
      ticksProcessedLabel: '走査済ティック',
      monteCarloLabel: 'モンテカルロ試行',
      equityCurveTitle: '資産曲線リアルタイムモニタ（クオンツ探索＆ストレステスト）',
      generationLabel: '試行世代',
      balanceLabel: '暫定口座残高',
      profitPipsLabel: '獲得損益',
      candidateHighNotice: '⚡ 有力候補モデル検出：目標プロフィットファクター達成・詳細ストレステスト移行',
      stressTestNotice: '🔥 最終選考モデル：スリッページ・最大ドローダウン耐性検証中',
      optimalLockedNotice: '✅ 最適解モデル確定（OPTIMAL ARCHITECTURE VERIFIED）',
      fitnessLabel: 'モデル適合度',
      trialCounterLabel: '走査モデル試行数',
      rapidSweepBadge: '全ティック並列高速スキャン中',
      retryReason1: '⚠️ 許容最大ドローダウン超過 (DD 18.5% > 10.0%) を検知。パラメータを自動淘汰し、遺伝子交叉（Crossover）を実行して第2世代へ再最適化中...',
      retryReason2: '⚠️ プロフィットファクター基準未達 (PF 0.98 < 1.20)。スプレッド摩擦コストを吸収できず。ATR適応型ダイナミックフィルターを再注入中...',
      retryReason3: '⚠️ 深夜ロールオーバー時のスリッページ耐性不足。時間帯別スプレッド保護フィルター（Rollover Guard）を組み込み最終最適化へ...',
      retrySuccess: '✅ 全ストレステスト合格！安定した右肩上がりの最適解モデル（PF: 1.46 / 最大DD: 8.4%）を検出！',
      stageTitle1: '世代 1/4: パラメータ初期探索＆限界ストレステスト',
      stageTitle2: '世代 2/4: トレンドフィルター選別＆スプレッド摩擦テスト',
      stageTitle3: '世代 3/4: ボラティリティ可変SL/TP微調整＆約定テスト',
      stageTitle4: '世代 4/4（最終確定）: 最適解モデルによる全期間バックテスト',
      skipSpeedBtn: '⚡ Proクラウド並列処理で高速完了（約10秒に短縮）',
      skipSpeedHint: '※有料版（Pro）なら専用クラスタ並列処理により、約5分間の待機時間を大幅短縮（約10秒で完了）できます。',
      recentTradesTitle: 'シミュレーション約定ストリーム (リアルタイム検出)',
      speedProBannerTitle: '⚡ 有料版（Pro）なら専用クラウド分散処理で大幅短縮【約10〜15秒の超高速完了】',
      speedProBannerDesc: '無料版は本格的な全ティック検証のためシングルスレッド順次計算を実行中（約5分〜6分）。上位版（Pro）なら専用分散クラスタで並列処理し、検証作業を約10〜15秒で高速完了できます。',
      speedProBtn: '高速版（Pro）を見る',
      progressPercent: '進捗率',
    },
    aiModal: {
      title: 'Gemini AI 戦略ビルダー & 手法自動EA化',
      subtitle: 'YouTubeやGogoJungleで話題の手法やアイデアを入力すると、AIが即座に最適化MQL5コードを生成します',
      researchPrompt: '参考リサーチ元:',
      gogojungleLink: 'GogoJungle 人気EA',
      youtubeLink: 'YouTube トレード手法検索',
      templatesTitle: '人気トレード手法テンプレート（クリックでプロンプト入力）',
      customPromptLabel: '手法・ロジックの追加要望やカスタマイズ指示',
      customPromptPlaceholder: '例: 上位足H1でダウ理論の押し目買いを検知し、M30でボリンジャーバンドのスクイーズから抜けた時のみエントリー。ストップロスは直近安値に設定して、週1〜2回程度取引するスイングEAにしてください。',
      cancel: 'キャンセル',
      generate: 'Gemini AIでEA生成 & バックテスト',
      generating: 'AIがEAコード作成中...',
      quickIdeasTitle: 'ワンクリックで呼び出せる人気手法プリセット',
      promptLabel: '手法のルール・エントリー/決済ロジック',
      promptPlaceholder: '例: H4のEMA200でトレンド判定し、M30のRSIダイバージェンスで逆張り。損切りは直近高安値...',
      strategyTypeLabel: 'ロジックタイプ',
      btnGenerate: 'AIでMQLコード & 出品文を生成する',
      btnGenerating: 'AI生成中...',
      closeBtn: '閉じる',
    },
  },
  en: {
    common: {
      freeEditionBadge: 'Free Edition',
      allView: 'Overview',
      simulationNav: 'Simulation Results',
      codeNav: 'MQL5 / MQL4 Code & Audit',
      salesNav: 'Listing Manual & FAQ',
      proUnlockNav: 'Unlock All Features with Pro',
      proFeaturesBtn: 'Explore Pro Features',
      aiAnalysisBtn: 'AI Strategy Analysis',
      aiGenerating: 'AI Generating...',
      exportAllBtn: 'Export All Data',
      toastGenerated: 'EA Generation Complete: 3-month reference simulation & MQL code generated',
      toastAiApplied: 'AI generated logic & MQL code applied successfully',
      toastExported: 'Free Edition package (MQL code, 3-month simulation, listing) exported',
      copied: 'Copied to clipboard',
      copy: 'Copy',
      close: 'Close',
    },
    header: {
      title: 'EA Maker Zero',
      subtitle: 'Select Currency Pair, Timeframe, PF, Max DD, and Frequency to Auto-Generate MQL4/MQL5 Code for Free',
      freeBadge: 'Free Edition',
    },
    config: {
      title: 'Free Edition EA Generation Parameters',
      freeBadge: 'Free Edition',
      description: 'Configure your parameters within Free Edition limits and click the button below to generate your EA.',
      pairTitle: '1. Currency Pair',
      pairLimitNotice: 'Free Edition: 1 pair available (EUR/USD). Unlock all with Pro.',
      timeframeTitle: '2. Timeframe',
      timeframeNotice: 'All timeframes available in Free Edition without restrictions',
      pfTitle: '3. Desired Profit Factor (PF)',
      pfLimitNotice: 'Free Edition: PF 1.2+ only. (PF 1.5 - 2.0+ available in Pro)',
      ddTitle: '4. Max Allowable Drawdown (Max DD)',
      ddLimitNotice: 'Free Edition: Max DD 10% fixed. (3% & 5% available in Pro)',
      freqTitle: '5. Desired Trade Frequency',
      freqNotice: 'All frequency options available in Free Edition',
      periodTitle: '6. Backtest Period',
      periodNotice: 'Free Edition: 3 months fixed (1-5 year testing available in Pro)',
      capitalTitle: '7. Base Capital',
      capitalNotice: 'Free Edition: Fixed at ¥100,000 (Customizable in Pro)',
      capitalValue: '¥100,000 JPY',
      capitalFixedTag: 'Free Edition Fixed',
      capitalDesc: 'Estimated profits in the Free Edition are calculated based on a base capital of ¥100,000.',
      capitalSubNote: '※ Capital setting is fixed for the Free Edition.',
      capitalProHint: 'Pro Edition allows custom capital from ¥100k to ¥10M',
      lotTitle: '8. Minimum Lot',
      lotLabel: 'Minimum Lot',
      lotValue: '0.01 lot',
      lotFixedTag: 'Free Edition Fixed / Reference Value',
      lotDesc: 'Minimum transaction unit for risk-controlled verification. Please verify actual trading availability and appropriate lot sizing with your broker specifications and account balance.',
      lotSubNote: '※ Reference value. Please check with your broker for actual minimum contract sizes.',
      lotProHint: 'Need custom lots or compounding? (Pro Edition)',
      lotProButton: 'Pro Edition supports custom lots & compound interest',
      positionsTitle: '9. Maximum Concurrent Positions',
      positionsLimitNotice: 'Free Edition: 1 position only (Unlock maximum concurrent positions in Pro)',
      positionsOption1: '1 Position',
      positionsOptionLe5: 'Max 5 Positions',
      positionsOptionLe10: 'Max 10 Positions',
      positionsOptionLe20: 'Max 20 Positions',
      positionsOptionGe20: 'Over 20 Positions',
      positionsOptionAuto: 'AI Recommended',
      freeEditionProcessTime: 'Free Edition performs a simplified simulation for parameter verification and typically completes within a few minutes.',
      proEditionProcessTime: 'Pro Edition runs deep multi-scenario testing, long-term audits, complex position constraints, and complete code verification, which may take over 30 minutes.',
      waveformDisclaimer: '※ Waveforms and candidate displays shown are visual representations to illustrate the verification pipeline.',
      futureFeaturesNote: '※ Grid trading, trailing repeat, multi-tier pyramiding, and compounding interest are planned for future updates (currently in preparation).',
      btnGenerate: 'Start EA Auto-Generation (Generate MQL4/MQL5 Code)',
      btnGenerating: 'Generating EA & Running Simulation...',
      btnSubText: '※ No MT5 Strategy Tester needed. Real-time browser simulation.',
      speedHintNote: '※ Free Edition typically takes a few minutes; Pro Edition may take over 30 minutes depending on processing depth.',
      speedHintLink: '⚡ Pro Edition features fast execution via cloud parallel nodes (~10s).',
      proOnlyBadge: 'Pro',
      recommendedBadge: 'Recommended',
      stableBadge: 'Stable',
      swingBadge: 'Swing',
      autoBadge: 'Auto',
      freeRefBadge: 'Free (Reference)',
    },
    backtest: {
      title: 'EA Auto-Generation & Reference Simulation Results',
      badge: 'Free Simulation',
      desc: (pair, tf) => `A 3-month reference simulation was verified based on configured parameters (${pair} / ${tf}).`,
      unlockLongTerm: 'Unlock 1 to 5-Year Long-Term Verification (Pro)',
      resultCardTitle: 'Reference Simulation Results',
      shortPeriodBadge: 'Short-term (3-month) test for Free Edition',
      pfLabel: 'PF',
      maxDdLabel: 'Max Drawdown',
      freqLabel: 'Desired Trade Frequency',
      periodLabel: 'Simulation Period',
      periodSub: '※ Short-term for Free Edition',
      periodValue: '3 Months',
      baseCapitalLabel: 'Base Capital',
      baseCapitalValue: '¥100,000 JPY',
      profitLabel: 'Reference Simulation Profit',
      profitSub: '※ Displayed in monetary amount (Return % hidden)',
      capitalNoticeLine: '※ Estimated profits are calculated based on a base capital of ¥100,000.',
      totalTradesLine: 'Total Trades',
      winRateLine: 'Win Rate',
      lotCardTitle: 'Minimum Lot (Test Condition)',
      lotCardFixedTag: 'Free Edition Fixed',
      lotUpgradeBtn: 'Custom Lots & Compounding (Pro)',
      eaEvalTitle: 'EA Evaluation Metrics',
      eaEvalBadge: 'Reference Values / Simplified Assessment by Built-in Model',
      eaEvalGuideline: 'Guideline only (Not actual measured or definitive values)',
      curveFitLink: 'How to calculate Curve Fitting (Overfitting)?',
      payoffLabel: 'Expected Payoff (Per Trade)',
      payoffTag: 'Reference Simulation Value',
      plRatioLabel: 'P/L Ratio (Avg Win / Loss)',
      plRatioTag: 'Built-in Model Reference',
      maxConsecWinsLabel: 'Max Consecutive Wins',
      maxConsecWinsTag: 'Simplified Assessment (3 Mo)',
      maxConsecLossesLabel: 'Max Consecutive Losses',
      maxConsecLossesTag: 'Simplified Assessment (3 Mo)',
      weeklyFreqLabel: 'Est. Weekly Trade Frequency',
      weeklyFreqTag: 'Guideline',
      recoveryFactorLabel: 'Recovery Factor',
      recoveryFactorTag: 'Reference (Net Profit / Max DD)',
      evalDisclaimerTitle: '[Handling of Simulation Data]',
      evalDisclaimerText: 'The indicators displayed here are not actual measured, historical, or definitive figures from real market tick data or the MT4/MT5 Strategy Tester, but reference simulation values, simplified assessments, and guidelines from our built-in browser model. Please use them purely as reference information prior to live deployment.',
      tabMetrics: 'Detailed Metrics',
      tabChart: 'Equity Curve (3 Months)',
      tabTrades: (count) => `Trade History Log (${count})`,
      tabNote: 'Instant verification without MT5',
      metricsWinRateTrades: 'Win Rate / Trades',
      metricsTradesPerWeek: 'Avg Weekly Trades',
      metricsTradeAutoOpt: 'Optimized to your preference',
      metricsAvgProfitLoss: 'Avg Profit / Avg Loss',
      metricsRiskRewardRatio: 'Risk-Reward Ratio',
      metricsSharpeRatio: 'Sharpe Ratio',
      metricsSharpeNote: 'Excellent risk-adjusted return',
      chartTitle: '3-Month Balance Trend (Initial: ¥100,000)',
      chartFinalBalance: 'Final Balance',
      sharpeRatio: 'Sharpe Ratio',
      sharpeRatioNote: 'Excellent risk-adjusted return',
      chartBalance: '3-Month Balance Trend (Initial: ¥100,000)',
      chartFinal: 'Final Balance',
      tradeFilterAll: 'ALL',
      tradeFilterBuy: 'BUY',
      tradeFilterSell: 'SELL',
      tradeFilterWins: 'WINS',
      tradeFilterLosses: 'LOSSES',
      colId: '#',
      colOpenTime: 'Date / Time',
      colType: 'Type',
      colLots: 'Lot',
      colProfitPips: 'P&L (pips)',
      colProfitAmount: 'P&L (JPY)',
      colReason: 'Close Reason',
      colDateTime: 'Date / Time',
      colPips: 'P&L (pips)',
      colAmount: 'P&L (JPY)',
      metricsTitle: 'EA Evaluation Metrics',
      metricsTag: 'Reference Values from Internal Model / Simplified Evaluation',
      metricsSubTitle: 'Guideline Only (Not Actual or Confirmed Historical Performance)',
      curveFitUpgradeHint: 'How to view Curve Fitting Risk?',
      expectedPayoff: 'Expected Payoff (per trade)',
      expectedPayoffNote: 'Reference Simulation Value',
      profitLossRatio: 'P/L Ratio (Avg Win / Avg Loss)',
      profitLossRatioNote: 'Internal Model Reference',
      maxConsecutiveWins: 'Max Consecutive Wins',
      maxConsecutiveWinsNote: 'Simplified Evaluation (3 mo)',
      maxConsecutiveLosses: 'Max Consecutive Losses',
      maxConsecutiveLossesNote: 'Simplified Evaluation (3 mo)',
      estTradesPerWeek: 'Estimated Weekly Trades',
      estTradesPerWeekNote: 'Guideline Estimate',
      recoveryFactor: 'Recovery Factor',
      recoveryFactorNote: 'Reference (Net Profit / Max DD)',
      disclaimerTitle: '[Data Disclaimer & Usage Notice]',
      disclaimerText: 'Metrics shown on this dashboard are reference simulation values, simplified evaluations, and estimation guidelines generated by an internal algorithmic model. They are not actual, realized, or certified values from real market tick data or MT4/MT5 strategy tester backtests. Please use solely as reference information before live deployment.',
      tabSummary: 'Detailed Metrics',
      tabNotice: 'Instant verification without MT5',
      winRateTrades: 'Win Rate / Trades',
      weeklyTrades: 'Avg Weekly Trades',
      weeklyTradesNote: 'Optimized to your preference',
      avgProfitLoss: 'Avg Profit / Avg Loss',
      upgradeLongTerm: '1, 3, & 5-Year Backtests Available in Pro',
      tableTitle: 'Reference Simulation Results',
      tableTag: 'Internal Model Reference',
      pf: 'Profit Factor (PF)',
      maxDrawdown: 'Max Drawdown',
      targetFreq: 'Desired Trading Frequency',
      simPeriod: 'Simulation Period',
      simPeriodNote: 'Short Period (Free Edition)',
      simPeriodValue: '3 Months',
      baseCapital: 'Base Capital',
      simProfit: 'Estimated Reference Net Profit',
      simProfitNote: 'Amount in JPY (ROI% hidden)',
      profitNotice: 'Estimated profits are calculated based on ¥100,000 JPY standard capital.',
      minLotLabel: 'Minimum Lot (Testing Condition)',
      minLotTag: 'Fixed in Free Edition',
      minLotDesc: 'For safety verification, all simulations and generated MQL codes in Free Edition operate strictly at Minimum Lot (0.01 lot).',
      minLotNote: 'Custom fixed lot sizing and automatic compounding features are available in EA Maker Zero Pro.',
    },
    sourceCode: {
      title: 'Production EA Source Code',
      badge: '100% Compilable',
      subtitle: 'Production-ready code equipped with trade error guards, zero-division prevention, and broker lot normalization.',
      compileBadge: '100% Compilable',
      desc: 'Production-ready code equipped with trade error guards, zero-division prevention, and broker lot normalization.',
      copied: 'Copied',
      copyCode: 'Copy Code',
      scanning: 'Scanning Code Safety...',
      rescanBtn: 'Re-verify Code Safety',
      compileNotice: 'Compiles with 0 errors on MetaEditor 5 (Build 3800+) / MetaEditor 4',
      auditVerified: 'Strict Error Detection & Zero-Division Audit Passed',
      auditDesc: 'Compliant with MQL5 standard trade libraries, no uninitialized variables or null pointers.',
      auditScore: '0 Errors / 0 Warnings',
      passed: 'PASSED',
      paramName: 'Parameter Name',
      paramType: 'Type',
      paramDefault: 'Default Value',
      paramDesc: 'Description / Purpose',
      paramAdjustable: 'Customizable',
      copyBtn: 'Copy Code',
      downloadBtn: 'Download File',
      tabCode: 'MQL Source Code',
      tabAudit: 'Safety Audit & Zero-Divide Checks',
      tabGuide: 'MT4/MT5 Installation Guide',
      auditTitle: 'Strict Error Detection & Zero-Division Audit Passed',
      auditBadge: '0 Errors / 0 Warnings',
      btnRecheck: 'Re-verify Code Safety',
      btnRechecking: 'Checking...',
      zeroDivideTitle: 'Zero-Division SafeGuard',
      zeroDivideDesc: 'In ATR calculation, Point values, tick size, and spread division routines, fallback protections prevent runtime crashes if denominators are zero or negative.',
      errorGuardTitle: 'Trade Server Error Auto-Retry (Errors 10004 / 10006 / 130)',
      errorGuardDesc: 'Performs up to 3 automated retries with comprehensive diagnostic logging on requotes, context busy, or invalid slippage.',
      lotNormTitle: 'Broker Lot Normalization & Margin Check',
      lotNormDesc: 'Automatically rounds lot sizes according to broker minLot, maxLot, and lotStep to preemptively prevent OrderSend failures.',
      guideTitle: 'Installation Guide for MT4 / MT5',
      step1Title: '1. Download Source Code',
      step1Desc: 'Click "Download File" above to save the .mq5 or .mq4 file to your local computer.',
      step2Title: '2. Compile in MetaEditor',
      step2Desc: 'Open MetaEditor from MetaTrader, place the file in the MQL5/Experts or MQL4/Experts folder, and press Compile (F7). Confirm 0 errors.',
      step3Title: '3. Attach to Chart',
      step3Desc: 'Drag the EA from the Navigator panel onto your target chart, and ensure "Allow Algo Trading" is checked in Common settings.',
      lockedBadge: 'Pro Edition Exclusive',
      lockedTitle: 'EA Source Code is Exclusive to Pro Edition',
      lockedDesc: 'In the Free Edition, you can verify algorithmic simulation results, safety audits, and buyer parameter configurations. Exporting, viewing, and downloading full compilable MQL4/MQL5 production code ready for live MT4/MT5 deployment is available in EA Maker Zero Pro.',
      unlockBtn: 'Unlock & Export EA Source Code',
      copyLocked: 'Copying source code is exclusive to Pro Edition',
      copyBtnLocked: 'Copy Code (Pro)',
      downloadLocked: 'Save (Pro)',
      featureListTitle: 'Code specifications unlocked in EA Maker Zero Pro:',
      featureItem1: 'Fully compilable MQL5 & MQL4 production code (.mq5 / .mq4)',
      featureItem2: 'Automated trade server error auto-retry (Errors 10004/10006/130)',
      featureItem3: 'Zero-division protection & broker lot normalization functions',
      featureItem4: 'Commercial marketplace & GogoJungle listing ready',
    },
    salesPackage: {
      title: 'GogoJungle Listing Page & Buyer Manual',
      badge: 'Ready to Copy & Paste',
      desc: 'Complete sales package including parameter manual, recommended environments, FAQs, and risk disclaimers.',
      subtitle: 'Complete sales package including parameter manual, recommended environments, FAQs, and risk disclaimers.',
      openMarket: 'Open GogoJungle',
      copiedText: 'Listing Text Copied',
      copyAll: 'Copy Full Listing & Manual',
      previewTitle: 'Suggested Listing Title',
      highlights: 'Product Highlights & Key Selling Points',
      recommendedSpec: 'Recommended Operating Environment for Buyers',
      broker: 'Recommended Broker',
      leverage: 'Recommended Leverage',
      deposit: 'Recommended Margin',
      vps: 'VPS Hosting',
      vpsDesc: '24/7 continuous operation recommended',
      faqTitle: 'Frequently Asked Questions (FAQ)',
      disclaimerTitle: 'Investment Risk & Legal Disclaimer (GogoJungle compliant)',
      copyAllBtn: 'Copy Full Listing & Manual',
      tabOverview: 'Product Overview & Features',
      tabManual: 'Parameter Manual',
      tabFaq: 'FAQ (Frequently Asked Questions)',
      tabDisclaimer: 'Notes & Disclaimers',
      recommendedEnv: 'Recommended Operating Environment',
      brokerLabel: 'Recommended Broker',
      leverageLabel: 'Recommended Leverage',
      minDepositLabel: 'Minimum Deposit',
      recDepositLabel: 'Recommended Deposit',
      vpsLabel: 'VPS Recommended',
    },
    upgradeModal: {
      badge: 'Pro Edition',
      exclusive: 'Pro Exclusive Feature',
      close: 'Close',
      title: 'EA Maker Zero Pro Feature Expansion',
      bannerDefault: 'Thank you for using the Free Edition. Upgrading to Pro unlocks all limitations and grants access to professional-grade algorithmic trading tools.',
      ctaDefault: 'Explore Pro Features',
      triggerPairTitle: 'Currency Pair Limitations',
      triggerPairMsg: 'Free Edition allows 1 currency pair per session (EUR/USD). Upgrade to access all currency pairs and multi-currency portfolio EAs.',
      triggerPfTitle: 'Profit Factor (PF) Goal Limitations',
      triggerPfMsg: 'Advanced profit factor targets such as PF 1.5+ and PF 1.8+ are exclusive to the Pro Edition.',
      triggerDdTitle: 'Max Drawdown Limitations',
      triggerDdMsg: 'To specify stricter low-drawdown parameters (3% or 5%), please upgrade to the Pro Edition.',
      triggerPeriodTitle: 'Simulation Period Limitations',
      triggerPeriodMsg: 'Free Edition provides 3-month reference testing. Long-term walk-forward testing for 1, 3, and 5 years is available in Pro.',
      triggerCapitalTitle: 'Base Capital Setting',
      triggerCapitalMsg: 'Free Edition estimated profits are calculated based on ¥100,000 JPY. Flexible capital customization from ¥100k to ¥10M is available in Pro.',
      triggerLotTitle: 'Trading Lot Sizing Setting',
      triggerLotMsg: 'Free Edition is fixed at Minimum Lot (0.01 lot) for safe testing. Custom lot sizes and automatic compounding are available in Pro.',
      triggerCurveFitTitle: 'Curve Fitting (Overfitting) Risk Analysis',
      triggerCurveFitMsg: 'The Pro Edition calculates and displays Curve Fitting Risk (%) through In-Sample (IS) and Out-of-Sample (OOS) walk-forward analysis on historical tick data.',
      featuresHeader: 'Features Unlocked in EA Maker Zero Pro',
      feature1Title: 'All Currency Pairs & Multi-Currency Portfolios',
      feature1Desc: 'Unlimited generation for USD/JPY, GBP/JPY, EUR/JPY, Gold (XAU/USD), and major currency pairs.',
      feature2Title: 'PF 1.5 - 2.0+ High-Expectancy Filters',
      feature2Desc: 'Filters out false breakouts to design high-win-rate, commercial-grade EA models.',
      feature3Title: 'Max DD 3% & 5% Ironclad Defense',
      feature3Desc: 'Strict drawdown controls ideal for large capital accounts and hands-off safe operation.',
      feature4Title: '1-Year, 3-Year, & 5-Year Walk-Forward Backtesting',
      feature4Desc: 'Verify robustness across full market cycles directly in your browser without MT5.',
      feature5Title: 'Custom Base Capital (¥100k to ¥10M)',
      feature5Desc: 'Automatic lot calculation and compounding simulations tailored to your investment budget.',
      feature6Title: 'Unlimited Gemini AI Custom Logic Conversion',
      feature6Desc: 'Convert YouTube strategies or custom rules into production MQL code using plain language.',
      migrationTitle: 'Seamless Migration of Free Edition Code & Data',
      migrationDesc: 'All strategies, MQL codes, and simulation presets created in Free Edition carry over seamlessly.',
      continueFree: 'Continue with Free Edition',
      proBadge: 'Pro Edition',
      defaultTitle: 'EA Maker Zero Pro Feature Expansion',
      defaultBanner: 'Thank you for using the Free Edition. Upgrading to Pro unlocks all limitations and grants access to professional-grade algorithmic trading tools.',
      defaultCta: 'Explore Pro Features',
      pairTitle: 'Currency Pair Limitations',
      pairBanner: 'Free Edition allows 1 currency pair per session (EUR/USD). Upgrade to access all currency pairs and multi-currency portfolio EAs.',
      pairCta: 'Explore Pro Features',
      pfTitle: 'Profit Factor (PF) Goal Limitations',
      pfBanner: 'Advanced profit factor targets such as PF 1.5+ and PF 1.8+ are exclusive to the Pro Edition.',
      pfCta: 'Expand PF Settings',
      ddTitle: 'Max Drawdown Limitations',
      ddBanner: 'To specify stricter low-drawdown parameters (3% or 5%), please upgrade to the Pro Edition.',
      ddCta: 'Unlock Low-Risk Parameters',
      periodTitle: 'Simulation Period Limitations',
      periodBanner: 'Free Edition provides 3-month reference testing. Long-term walk-forward testing for 1, 3, and 5 years is available in Pro.',
      periodCta: 'Unlock Long-Term Backtests',
      capitalTitle: 'Base Capital Setting',
      capitalBanner: 'Free Edition estimated profits are calculated based on ¥100,000 JPY. Flexible capital customization from ¥100k to ¥10M is available in Pro.',
      capitalCta: 'Customize Capital Settings',
      lotTitle: 'Trading Lot Sizing Setting',
      lotBanner: 'Free Edition is fixed at Minimum Lot (0.01 lot) for safe testing. Custom lot sizes and automatic compounding are available in Pro.',
      lotCta: 'Expand Lot Settings',
      triggerMaxPositionsTitle: 'Unlock Max Positions & Multi-Entry Engine',
      triggerMaxPositionsMsg: 'Free Edition is restricted to [1 Position Only] for baseline safety. Upgrading to EA Maker Zero Pro unlocks configurable max positions: [<=5], [<=10], [<=20], [20+], or [Auto]! Enables multi-tier pyramiding, grid trading, and institutional portfolio balancing.',
      triggerMaxPositionsCta: 'Unlock Configurable Positions (Pro)',
      curveFitTitle: 'Curve Fitting (Overfitting) Risk Analysis',
      curveFitBanner: 'The Pro Edition calculates and displays Curve Fitting Risk (%) through In-Sample (IS) and Out-of-Sample (OOS) walk-forward analysis on historical tick data.',
      curveFitCta: 'Unlock Curve Fitting Analysis',
      triggerCodeTitle: 'EA Source Code Export & Download',
      triggerCodeMsg: 'In the Free Edition, EA source code viewing and downloading are restricted. Upgrade to EA Maker Zero Pro to export full MQL5/MQL4 production code, download .mq5/.mq4 files, and access commercial compilation tools.',
      triggerCodeCta: 'Unlock EA Source Code',
      triggerSpeedTitle: 'Ultra-Fast Cloud Parallel Backtesting (~10s Cloud Speed)',
      triggerSpeedMsg: 'The Free Edition sequentially runs detailed full-tick simulation and genetic algorithm optimization on client compute, taking around 5 minutes. EA Maker Zero Pro utilizes dedicated distributed cloud clusters to run multi-parameter optimization across multi-year tick data in parallel (~10-15s execution).',
      triggerSpeedCta: 'Unlock High-Speed Pro Edition',
      proFeatureHeader: 'Key Features Unlocked in Pro Edition',
      closeBtn: 'Close',
    },
    generationProgress: {
      modalTitle: 'Executing High-Precision EA Backtest & Full-Tick Simulation',
      modalSubtitle: 'Sequentially analyzing past 3 months of M15 tick data (~128,000 ticks) and fill dynamics (Est. duration: ~5 min)',
      statusSimulating: 'Precision Backtest in Progress',
      step1Title: '1. Loading Historical Ticks & Building Spread Model',
      step1Desc: 'Scanning 2,880 historical candlestick bars / 128,450 ticks. Reconstructing floating spread (1.2-2.8 pips) & weekend gaps...',
      step2Title: '2. Technical Signal Verification & Entry Evaluation',
      step2Desc: 'Evaluating EMA/MACD filters & ATR volatility. Matching buy/sell triggers against real tick streams bar-by-bar...',
      step3Title: '3. Fill Execution Simulation & Slippage Stress-Testing',
      step3Desc: 'Auditing limit/stop fill rates, midnight spread surge stress-tests, and zero-divide guard routines...',
      step4Title: '4. Drawdown Analysis & Performance Metric Aggregation',
      step4Desc: 'Aggregating Profit Factor, Recovery Factor, Max consecutive wins/losses, Sharpe Ratio, and 1,000 Monte Carlo runs...',
      step5Title: '5. MQL5/MQL4 Production Code Integrity Verification',
      step5Desc: 'Performing final audit on Error 10004/10006 auto-retry wrappers and order lot normalization functions...',
      processedBarsLabel: 'Analyzed Bars',
      simulatedTradesLabel: 'Detected Trades',
      winRateLabel: 'Est. Win Rate',
      currentPfLabel: 'Profit Factor',
      auditLabel: 'Safety Audit Status',
      ticksProcessedLabel: 'Ticks Scanned',
      monteCarloLabel: 'Monte Carlo Iterations',
      equityCurveTitle: 'Live Equity Curve Monitor (Quant Exploration & Stress-Testing)',
      generationLabel: 'Trial Generation',
      balanceLabel: 'Est. Balance',
      profitPipsLabel: 'Profit Pips',
      candidateHighNotice: '⚡ High Candidate Model Detected: Target Profit Factor achieved, passing to stress tests...',
      stressTestNotice: '🔥 Final Candidate Selection: Auditing slippage & drawdown tolerance...',
      optimalLockedNotice: '✅ Optimal Model Verified (OPTIMAL ARCHITECTURE VERIFIED)',
      fitnessLabel: 'Model Fitness',
      trialCounterLabel: 'Evaluated Models',
      rapidSweepBadge: 'Tick Parallel Model Sweep',
      retryReason1: '⚠️ Max Drawdown Limit Exceeded (DD 18.5% > 10.0%). Discarding invalid parameters; running GA crossover for Generation #2...',
      retryReason2: '⚠️ Profit Factor Below Target (PF 0.98 < 1.20). Spread friction costs too high. Re-calibrating dynamic ATR volatility filters...',
      retryReason3: '⚠️ Slippage vulnerability detected during midnight rollover. Injecting adaptive rollover spread guard into final model...',
      retrySuccess: '✅ All Stress-Tests Passed! Robust upward-sloping optimal model detected (PF: 1.46 / Max DD: 8.4%)!',
      stageTitle1: 'Gen 1/4: Parameter Exploration & Stress-Testing',
      stageTitle2: 'Gen 2/4: Trend Filter Selection & Spread Friction',
      stageTitle3: 'Gen 3/4: Volatility Adaptive SL/TP Fine-Tuning',
      stageTitle4: 'Gen 4/4 (Final): Optimal Model Full-Period Backtest',
      skipSpeedBtn: '⚡ Fast-Forward via Pro Cloud Parallel (~10s Speed)',
      skipSpeedHint: '※ Pro Edition parallel cloud processing dramatically reduces this 5-minute wait down to ~10 seconds.',
      recentTradesTitle: 'Simulation Order Stream (Real-Time Trade Detection)',
      speedProBannerTitle: '⚡ High-Speed Cloud Parallel Execution in Pro (~10-15s Execution)',
      speedProBannerDesc: 'Free Edition runs exhaustive single-thread sequential verification (~5-6 min). Pro Edition processes optimization batches across dedicated cloud clusters in ~10-15 seconds.',
      speedProBtn: 'Explore Pro High-Speed Edition',
      progressPercent: 'Progress',
    },
    aiModal: {
      title: 'Gemini AI Strategy Builder & EA Auto-Coder',
      subtitle: 'Enter popular trading strategies or custom ideas, and AI will instantly generate optimized MQL5 code.',
      researchPrompt: 'Research Sources:',
      gogojungleLink: 'GogoJungle Popular EAs',
      youtubeLink: 'YouTube Trading Strategies',
      templatesTitle: 'Popular Strategy Templates (Click to apply prompt)',
      customPromptLabel: 'Custom Logic Requirements & Rules',
      customPromptPlaceholder: 'e.g., Detect dip-buying with Dow Theory on H1, enter on M30 only when breakout occurs from Bollinger Bands squeeze. Set Stop Loss at swing low, targeting 1-2 swing trades per week.',
      cancel: 'Cancel',
      generate: 'Generate EA & Backtest with Gemini AI',
      generating: 'AI Generating EA Code...',
      quickIdeasTitle: 'One-Click Strategy Presets',
      promptLabel: 'Strategy Rules & Entry/Exit Logic',
      promptPlaceholder: 'e.g., Determine trend with H4 EMA200, enter on M30 RSI divergence. Stop-loss at recent swing high/low...',
      strategyTypeLabel: 'Strategy Type',
      btnGenerate: 'Generate MQL Code & Listing with AI',
      btnGenerating: 'AI Generating...',
      closeBtn: 'Close',
    },
  },
};
