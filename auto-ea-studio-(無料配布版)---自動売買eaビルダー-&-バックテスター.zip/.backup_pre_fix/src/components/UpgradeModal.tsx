/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Sparkles,
  Lock,
  Check,
  ArrowRight,
  X,
  ShieldCheck,
  Zap,
  Layers,
  Coins,
  CalendarCheck,
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

export type UpgradeTrigger =
  | 'PAIR'
  | 'PF'
  | 'DD'
  | 'PERIOD'
  | 'CAPITAL'
  | 'LOT'
  | 'MAX_POSITIONS'
  | 'CURVE_FIT'
  | 'CODE'
  | 'SPEED'
  | 'GENERAL';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  trigger?: UpgradeTrigger;
}

export const UpgradeModal: React.FC<UpgradeModalProps> = ({
  isOpen,
  onClose,
  trigger = 'GENERAL',
}) => {
  const { language, t } = useLanguage();
  const isEn = language === 'en';

  if (!isOpen) return null;

  // Specific guidance text and CTA based on trigger
  let title = t.upgradeModal.title;
  let bannerMessage = t.upgradeModal.bannerDefault;
  let ctaText = t.upgradeModal.ctaDefault;

  if (trigger === 'PAIR') {
    title = t.upgradeModal.triggerPairTitle;
    bannerMessage = t.upgradeModal.triggerPairMsg;
    ctaText = t.upgradeModal.ctaDefault;
  } else if (trigger === 'PF') {
    title = t.upgradeModal.triggerPfTitle;
    bannerMessage = t.upgradeModal.triggerPfMsg;
    ctaText = isEn ? 'Unlock Higher PF Conditions' : 'PF条件を拡張する';
  } else if (trigger === 'DD') {
    title = t.upgradeModal.triggerDdTitle;
    bannerMessage = t.upgradeModal.triggerDdMsg;
    ctaText = isEn ? 'Unlock Lower Drawdown Conditions' : 'より低リスクな条件を開放';
  } else if (trigger === 'PERIOD') {
    title = t.upgradeModal.triggerPeriodTitle;
    bannerMessage = t.upgradeModal.triggerPeriodMsg;
    ctaText = isEn ? 'Unlock Multi-Year Walk-Forward' : '長期検証機能を開放する';
  } else if (trigger === 'CAPITAL') {
    title = t.upgradeModal.triggerCapitalTitle;
    bannerMessage = t.upgradeModal.triggerCapitalMsg;
    ctaText = isEn ? 'Customize Account Margin' : '資金設定をカスタマイズする';
  } else if (trigger === 'LOT') {
    title = t.upgradeModal.triggerLotTitle;
    bannerMessage = t.upgradeModal.triggerLotMsg;
    ctaText = isEn ? 'Unlock Custom Lot & Compounding' : 'ロット設定を拡張する';
  } else if (trigger === 'MAX_POSITIONS') {
    title = t.upgradeModal.triggerMaxPositionsTitle;
    bannerMessage = t.upgradeModal.triggerMaxPositionsMsg;
    ctaText = t.upgradeModal.triggerMaxPositionsCta;
  } else if (trigger === 'CURVE_FIT') {
    title = t.upgradeModal.triggerCurveFitTitle;
    bannerMessage = t.upgradeModal.triggerCurveFitMsg;
    ctaText = isEn ? 'Unlock Curve Fitting Diagnostics' : 'カーブフィッティング検証を開放';
  } else if (trigger === 'CODE') {
    title = t.upgradeModal.triggerCodeTitle;
    bannerMessage = t.upgradeModal.triggerCodeMsg;
    ctaText = t.upgradeModal.triggerCodeCta;
  } else if (trigger === 'SPEED') {
    title = t.upgradeModal.triggerSpeedTitle;
    bannerMessage = t.upgradeModal.triggerSpeedMsg;
    ctaText = t.upgradeModal.triggerSpeedCta;
  }

  const proFeatures = [
    {
      icon: Zap,
      title: isEn ? 'Ultra-Fast Cloud Parallel Engine (High-Speed)' : '超高速クラウド並列エンジン (高速版)',
      desc: isEn
        ? 'Dramatically faster! Distributed cloud clusters process multi-year tick data and parameter optimizations in parallel (~10-15s).'
        : '待機時間を大幅短縮！専用クラウド分散クラスタが膨大な過去ティックデータと複数パラメータを並列処理（約10〜15秒で高速完了）。',
    },
    {
      icon: Layers,
      title: t.upgradeModal.feature1Title,
      desc: t.upgradeModal.feature1Desc,
    },
    {
      icon: Zap,
      title: t.upgradeModal.feature2Title,
      desc: t.upgradeModal.feature2Desc,
    },
    {
      icon: ShieldCheck,
      title: t.upgradeModal.feature3Title,
      desc: t.upgradeModal.feature3Desc,
    },
    {
      icon: CalendarCheck,
      title: t.upgradeModal.feature4Title,
      desc: t.upgradeModal.feature4Desc,
    },
    {
      icon: Coins,
      title: t.upgradeModal.feature5Title,
      desc: t.upgradeModal.feature5Desc,
    },
    {
      icon: Sparkles,
      title: t.upgradeModal.feature6Title,
      desc: t.upgradeModal.feature6Desc,
    },
  ];

  return (
    <div
      id="upgrade-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="upgrade-modal-container"
        className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-slate-900 via-blue-950/50 to-slate-900 border-b border-slate-800 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold tracking-wider px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 uppercase">
                  {t.upgradeModal.badge}
                </span>
                <span className="text-xs text-slate-400">{t.upgradeModal.exclusive}</span>
              </div>
              <h3 className="text-base font-bold text-white mt-0.5">{title}</h3>
            </div>
          </div>
          <button
            id="upgrade-modal-close-button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition cursor-pointer"
            aria-label={t.upgradeModal.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Specific Banner */}
          <div className="p-4 rounded-xl bg-blue-950/50 border border-blue-500/40 flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-300 flex items-center justify-center shrink-0 mt-0.5">
              <Lock className="w-3.5 h-3.5" />
            </div>
            <div>
              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-medium">
                {bannerMessage}
              </p>
            </div>
          </div>

          {/* Comparison / Pro Features Grid */}
          <div>
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.upgradeModal.featuresHeader}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {proFeatures.map((item, idx) => {
                const IconComponent = item.icon;
                return (
                  <div
                    key={idx}
                    className="p-3 rounded-lg bg-slate-800/60 border border-slate-700/60 flex items-start gap-2.5"
                  >
                    <div className="w-7 h-7 rounded-md bg-cyan-500/10 border border-cyan-500/25 flex items-center justify-center text-cyan-400 shrink-0">
                      <IconComponent className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-slate-200">
                        {item.title}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                        {item.desc}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Guarantee / Safe Box */}
          <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-700/40 text-xs text-slate-400 space-y-1">
            <div className="flex items-center gap-1.5 text-slate-300 font-medium">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{t.upgradeModal.migrationTitle}</span>
            </div>
            <p className="text-[11px] pl-5.5 text-slate-400">
              {t.upgradeModal.migrationDesc}
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-900 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            id="upgrade-modal-dismiss-button"
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition cursor-pointer"
          >
            {t.upgradeModal.continueFree}
          </button>
          <button
            id="upgrade-modal-cta-button"
            onClick={() => {
              alert(
                isEn
                  ? 'Opening the Auto EA Studio Pro info page.\nAll currency pairs, PF 1.5+ to 2.0+, Max DD 3% to 5%, 5-year testing, and custom capital margin will be unlocked.'
                  : '上位版（Auto EA Studio Pro）の案内ページを開きます。\n全通貨ペア、PF 1.5+〜2.0+、最大DD 3%〜5%、長期5年検証、運用資金自由設定がすべて開放されます。'
              );
              onClose();
            }}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-lg bg-gradient-to-r from-blue-600 via-cyan-600 to-teal-500 hover:from-blue-500 hover:to-cyan-400 text-white text-xs font-bold shadow-lg shadow-cyan-900/40 transition cursor-pointer"
          >
            <span>{ctaText}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
