/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { EASpec } from '../types';
import {
  Code,
  Copy,
  Check,
  Download,
  ShieldCheck,
  AlertTriangle,
  FileCode2,
  CheckCircle2,
  RefreshCw,
  SlidersHorizontal,
  Lock,
  Sparkles,
} from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { UpgradeTrigger } from './UpgradeModal';

interface SourceCodePanelProps {
  eaSpec: EASpec;
  onOpenUpgradeModal?: (trigger: UpgradeTrigger) => void;
}

export const SourceCodePanel: React.FC<SourceCodePanelProps> = ({
  eaSpec,
  onOpenUpgradeModal,
}) => {
  const { language, t } = useLanguage();
  const isEn = language === 'en';

  const [lang, setLang] = useState<'MQL5' | 'MQL4'>('MQL5');
  const [activeSubTab, setActiveSubTab] = useState<'code' | 'params' | 'audit'>('code');
  const [isRechecking, setIsRechecking] = useState(false);
  const [auditPassed, setAuditPassed] = useState(true);

  const currentCode = lang === 'MQL5' ? eaSpec.mql5Code : eaSpec.mql4Code;
  const fileName = `${eaSpec.name}.${lang === 'MQL5' ? 'mq5' : 'mq4'}`;

  const handleCopyLocked = () => {
    if (onOpenUpgradeModal) {
      onOpenUpgradeModal('CODE');
    }
  };

  const handleDownloadLocked = () => {
    if (onOpenUpgradeModal) {
      onOpenUpgradeModal('CODE');
    }
  };

  const handleRunRecheck = () => {
    setIsRechecking(true);
    setTimeout(() => {
      setIsRechecking(false);
      setAuditPassed(true);
    }, 600);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/25 flex items-center justify-center text-blue-400">
            <FileCode2 className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              {t.sourceCode.title}
              <span className="text-[11px] font-semibold text-amber-400 bg-amber-950/60 border border-amber-800/60 px-2 py-0.5 rounded flex items-center gap-1">
                <Lock className="w-3 h-3" />
                {t.sourceCode.lockedBadge}
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              {t.sourceCode.desc}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* MQL5 / MQL4 Switcher */}
          <div className="flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setLang('MQL5')}
              className={`px-3 py-1 rounded text-xs font-semibold transition cursor-pointer ${
                lang === 'MQL5'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              MetaTrader 5 (.mq5)
            </button>
            <button
              onClick={() => setLang('MQL4')}
              className={`px-3 py-1 rounded text-xs font-semibold transition cursor-pointer ${
                lang === 'MQL4'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              MetaTrader 4 (.mq4)
            </button>
          </div>

          <button
            type="button"
            onClick={handleCopyLocked}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-amber-300 border border-amber-800/50 text-xs font-medium transition cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            <span>{t.sourceCode.copyBtnLocked}</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadLocked}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-slate-950 text-xs font-bold transition shadow-md shadow-amber-900/30 cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5 text-slate-950" />
            <span>{t.sourceCode.downloadLocked}</span>
          </button>
        </div>
      </div>

      {/* Sub Tabs: Code View / Parameter Table / Safety Audit */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveSubTab('code')}
            className={`px-3 py-1 rounded text-xs font-semibold transition cursor-pointer ${
              activeSubTab === 'code'
                ? 'bg-slate-800 text-blue-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {isEn ? `Full Source Code (${lang})` : `ソースコード全文 (${lang})`}
          </button>
          <button
            onClick={() => setActiveSubTab('audit')}
            className={`px-3 py-1 rounded text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'audit'
                ? 'bg-slate-800 text-emerald-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>{t.sourceCode.tabAudit}</span>
          </button>
          <button
            onClick={() => setActiveSubTab('params')}
            className={`px-3 py-1 rounded text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'params'
                ? 'bg-slate-800 text-amber-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
            <span>{isEn ? `Buyer Parameters (${eaSpec.parameters.length})` : `購入者用パラメータ一覧 (${eaSpec.parameters.length}項目)`}</span>
          </button>
        </div>

        {activeSubTab === 'audit' && (
          <button
            onClick={handleRunRecheck}
            disabled={isRechecking}
            className="flex items-center gap-1.5 px-3 py-1 rounded text-xs bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3 h-3 ${isRechecking ? 'animate-spin text-emerald-400' : ''}`} />
            <span>{isRechecking ? t.sourceCode.scanning : t.sourceCode.rescanBtn}</span>
          </button>
        )}
      </div>

      {/* Sub Tab Content: Source Code View (Locked in Free Edition) */}
      {activeSubTab === 'code' && (
        <div className="relative overflow-hidden rounded-xl border border-slate-800 bg-slate-950 min-h-[380px] flex flex-col items-center justify-center p-6 text-center">
          {/* Subtle obscured watermark background */}
          <div className="absolute inset-0 opacity-10 select-none pointer-events-none filter blur-[4px] p-5 font-mono text-[11px] text-slate-500 overflow-hidden leading-relaxed text-left">
            <div>//+------------------------------------------------------------------+</div>
            <div>//|                                   AutoEA_Production_Pro.mq5        |</div>
            <div>//|                 Copyright 2026, Auto EA Studio Pro Edition          |</div>
            <div>//+------------------------------------------------------------------+</div>
            <div>#property copyright "Auto EA Studio Pro"</div>
            <div>#property version   "2.00"</div>
            <div>#include &lt;Trade\Trade.mqh&gt;</div>
            <div>CTrade trade;</div>
            <div>input double InpLotSize = 0.01;</div>
            <div>input int InpStopLoss = 35;</div>
            <div>input int InpTakeProfit = 50;</div>
            <div>void OnInit() &#123; /* PRO TRADING ENGINE INITIALIZATION */ &#125;</div>
            <div>void OnTick() &#123; /* TRADE ENGINE &amp; ERROR RETRY HANDLER */ &#125;</div>
            <div>bool CheckZeroDivide(double denom) &#123; return denom &gt; 0; &#125;</div>
            <div>bool ExecuteTradeWithRetry(...) &#123; /* RETRY 10004/10006/130 */ &#125;</div>
          </div>

          {/* Centered Lock Card */}
          <div className="relative z-10 max-w-lg mx-auto bg-slate-900/95 border border-amber-500/30 rounded-2xl p-6 sm:p-7 shadow-2xl backdrop-blur-md space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500/20 to-amber-600/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mx-auto shadow-inner">
              <Lock className="w-6 h-6" />
            </div>

            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-[11px] font-bold text-amber-400">
                <Sparkles className="w-3 h-3" />
                <span>{t.sourceCode.lockedBadge}</span>
              </div>
              <h3 className="text-base font-bold text-white">
                {t.sourceCode.lockedTitle}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {t.sourceCode.lockedDesc}
              </p>
            </div>

            <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 text-left text-xs space-y-1.5 text-slate-300">
              <div className="text-[11px] font-bold text-amber-300">
                {t.sourceCode.featureListTitle}
              </div>
              <div className="flex items-center gap-2 text-[11px] text-slate-400">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>{t.sourceCode.featureItem1}</span>
              </div>
              <div className="flex items-center gap-2 text-[11px] text-slate-400">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>{t.sourceCode.featureItem2}</span>
              </div>
              <div className="flex items-center gap-2 text-[11px] text-slate-400">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>{t.sourceCode.featureItem3}</span>
              </div>
              <div className="flex items-center gap-2 text-[11px] text-slate-400">
                <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>{t.sourceCode.featureItem4}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onOpenUpgradeModal?.('CODE')}
              className="w-full flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs transition shadow-lg shadow-amber-950/50 cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{t.sourceCode.unlockBtn}</span>
            </button>
          </div>
        </div>
      )}

      {/* Sub Tab Content: Safety Audit */}
      {activeSubTab === 'audit' && (
        <div className="space-y-3">
          <div className="bg-emerald-950/30 border border-emerald-500/30 rounded-lg p-3 text-xs text-emerald-300 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                <strong>{t.sourceCode.auditVerified}</strong> {t.sourceCode.auditDesc}
              </span>
            </div>
            <span className="text-[10px] bg-emerald-900/60 px-2 py-0.5 rounded font-bold">
              {t.sourceCode.auditScore}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {eaSpec.safetyChecks.map((check) => (
              <div
                key={check.id}
                className="bg-slate-950/60 border border-slate-800 rounded-lg p-3 space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{check.name}</span>
                  </div>
                  <span className="text-[10px] text-emerald-400 bg-emerald-950 px-1.5 py-0.5 rounded border border-emerald-800/60 font-semibold">
                    {t.sourceCode.passed}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">{check.description}</p>
                <div className="bg-slate-900 border border-slate-800 rounded p-2 text-[10px] font-mono text-cyan-300 overflow-x-auto">
                  <code>{check.codeSnippet}</code>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sub Tab Content: Parameters */}
      {activeSubTab === 'params' && (
        <div className="overflow-x-auto bg-slate-950/60 border border-slate-800 rounded-lg">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-800/80 text-slate-300">
              <tr>
                <th className="p-2.5">{t.sourceCode.paramName}</th>
                <th className="p-2.5">{t.sourceCode.paramType}</th>
                <th className="p-2.5">{t.sourceCode.paramDefault}</th>
                <th className="p-2.5">{t.sourceCode.paramDesc}</th>
                <th className="p-2.5">{t.sourceCode.paramAdjustable}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              {eaSpec.parameters.map((p) => (
                <tr key={p.name} className="hover:bg-slate-800/40">
                  <td className="p-2.5 font-mono text-cyan-400 font-semibold">{p.name}</td>
                  <td className="p-2.5 text-slate-400 font-mono text-[11px]">{p.type}</td>
                  <td className="p-2.5 font-mono text-emerald-400 font-bold">
                    {String(p.defaultValue)}
                  </td>
                  <td className="p-2.5 text-slate-200">{p.description}</td>
                  <td className="p-2.5">
                    <span className="px-2 py-0.5 rounded text-[10px] bg-blue-500/15 text-blue-400 border border-blue-500/30 font-medium">
                      {isEn ? 'Buyer Customizable' : '購入者調整可能'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
