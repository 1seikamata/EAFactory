/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BuyerConfig } from '../types';
import { Sparkles, X, Bot, CheckCircle2, AlertCircle, ArrowRight, ExternalLink } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

interface AiAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: BuyerConfig;
  onApplyAiStrategy: (aiData: any) => void;
}

export const AiAssistantModal: React.FC<AiAssistantModalProps> = ({
  isOpen,
  onClose,
  config,
  onApplyAiStrategy,
}) => {
  const { language, t } = useLanguage();
  const isEn = language === 'en';

  const [prompt, setPrompt] = useState('');
  const [strategyCategory, setStrategyCategory] = useState('YOUTUBE_PULSE');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const quickIdeas = isEn
    ? [
        {
          title: 'Popular YouTube Trend: Multi-Timeframe EMA Perfect Order & ATR Breakout',
          prompt:
            'Identify macro trend with H4 EMA200, wait for M30 EMA20/50 perfect order, and enter on recent high/low breakout. Stop Loss at ATR x 1.5, Take Profit at ATR x 2.5.',
        },
        {
          title: 'GogoJungle Classic: Bollinger Bands Squeeze & RSI Divergence',
          prompt:
            'Capture initial momentum when Bollinger Bands expand from a tight squeeze. Confirm RSI momentum above/below 50 before entry. Includes spread filter and Friday night close.',
        },
        {
          title: 'Tokyo Session Fixing Anomaly & London Breakout Hybrid',
          prompt:
            'A specialized time-window swing EA capturing Tokyo market fixing anomaly tendencies combined with London session volatility. Targets ~2 high-probability trades weekly without curve-fitting.',
        },
      ]
    : [
        {
          title: 'YouTube大人気: マルチタイム移動平均線パーフェクトオーダー & ATRブレイク',
          prompt:
            '上位足(H4)のEMA200で長期トレンドを認識し、執行足(M30)のEMA20/50のパーフェクトオーダー確定後に、直近高値安値ブレイクアウトでエントリーする王道手法。損切りはATR×1.5倍、利確はATR×2.5倍。',
        },
        {
          title: 'GogoJungle王道: ボリンジャーバンド・スクイーズブレイク & RSIダイバージェンス',
          prompt:
            'ボリンジャーバンドがスクイーズ（収縮）からエクスパンション（急拡大）した初動を捉え、RSIが50以上/以下の勢いを確認してエントリー。スプレッドフィルターと金曜夜間全決済を内蔵。',
        },
        {
          title: '東京時間仲値・ゴトー日アノマリー × ロンドンブレイク融合型',
          prompt:
            'USDJPYの東京仲値アノマリーの特性と、ロンドン市場オープン時のボラティリティ初動を組み合わせた特定時間帯スイングEA。過剰最適化を避け週2回程度の高確率エントリーを狙う。',
        },
      ];

  const handleGenerate = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/generate-custom-ea', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pair: config.pair,
          timeframe: config.timeframe,
          desiredPf: config.desiredPf,
          maxDrawdown: config.maxDrawdown,
          frequency: config.frequency,
          strategyType: strategyCategory,
          customPrompt: prompt,
        }),
      });

      const resData = await response.json();
      if (!response.ok || !resData.success) {
        throw new Error(resData.error || (isEn ? 'Failed to generate AI strategy.' : 'AI手法の生成に失敗しました。'));
      }

      onApplyAiStrategy(resData.data);
      onClose();
    } catch (err: any) {
      setError(err.message || (isEn ? 'Network error occurred.' : '通信エラーが発生しました。'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                {t.aiModal.title}
              </h3>
              <p className="text-[11px] text-slate-400">
                {t.aiModal.subtitle}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Reference Links */}
          <div className="bg-slate-950/50 border border-slate-800 rounded-lg p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
            <span className="text-slate-400">{t.aiModal.researchPrompt}</span>
            <div className="flex items-center gap-3">
              <a
                href="https://www.gogojungle.co.jp/"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-cyan-400 hover:underline"
              >
                <span>{t.aiModal.gogojungleLink}</span>
                <ExternalLink className="w-3 h-3" />
              </a>
              <a
                href="https://www.youtube.com/results?search_query=%E3%83%88%E3%83%AC%E3%83%BC%E3%83%89%E6%89%8B%E6%B3%95"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-rose-400 hover:underline"
              >
                <span>{t.aiModal.youtubeLink}</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          {/* Quick Idea Templates */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">
              {t.aiModal.templatesTitle}
            </label>
            <div className="space-y-1.5">
              {quickIdeas.map((idea, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setPrompt(idea.prompt)}
                  className="w-full text-left p-2.5 rounded-lg bg-slate-950/60 hover:bg-slate-800/80 border border-slate-800 text-xs text-slate-300 transition group cursor-pointer"
                >
                  <div className="font-semibold text-cyan-300 group-hover:text-cyan-200">
                    {idea.title}
                  </div>
                  <div className="text-[11px] text-slate-400 truncate mt-0.5">{idea.prompt}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Prompt input */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">
              {t.aiModal.customPromptLabel}
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={t.aiModal.customPromptPlaceholder}
              className="w-full h-28 bg-slate-950 border border-slate-700 rounded-lg p-3 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition resize-none"
            />
          </div>

          {/* Config Preview Summary */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-3 text-xs flex items-center justify-between text-slate-300">
            <span>{isEn ? 'Target:' : '対象:'} <strong>{config.pair}</strong> / <strong>{config.timeframe}</strong></span>
            <span>{isEn ? 'Target PF:' : '目標PF:'} <strong>{config.desiredPf}</strong></span>
            <span>{isEn ? 'Max DD:' : '最大DD許容:'} <strong>{config.maxDrawdown}</strong></span>
            <span>{isEn ? 'Freq:' : '頻度:'} <strong>{config.frequency}</strong></span>
          </div>

          {error && (
            <div className="p-3 rounded-lg bg-rose-950/40 border border-rose-800/50 text-xs text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{error}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-end gap-2.5">
          <button
            onClick={onClose}
            disabled={loading}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition cursor-pointer"
          >
            {t.aiModal.cancel}
          </button>
          <button
            onClick={handleGenerate}
            disabled={loading}
            className="flex items-center gap-2 px-5 py-2 rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white text-xs font-semibold shadow-lg shadow-cyan-900/30 transition cursor-pointer disabled:opacity-50"
          >
            <Sparkles className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>{loading ? t.aiModal.generating : t.aiModal.generate}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

