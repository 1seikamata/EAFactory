/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SalesPackage } from '../types';
import { ShoppingBag, Copy, Check, ExternalLink, HelpCircle, AlertCircle, Server } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

interface SalesPackagePanelProps {
  salesPackage: SalesPackage;
}

export const SalesPackagePanel: React.FC<SalesPackagePanelProps> = ({ salesPackage }) => {
  const { language, t } = useLanguage();
  const isEn = language === 'en';

  const [copied, setCopied] = useState(false);

  const getFullMarkdown = () => {
    if (isEn) {
      return `# ${salesPackage.title}
${salesPackage.subTitle}

## [Highlights & Key Features]
${salesPackage.catchyPoints.map((p) => `- ${p}`).join('\n')}

## [Concept & Product Overview]
${salesPackage.productOverview}

## [Recommended Environment]
- Recommended Broker: ${salesPackage.recommendedEnvironment.broker}
- Recommended Leverage: ${salesPackage.recommendedEnvironment.leverage}
- Minimum Margin: ${salesPackage.recommendedEnvironment.minDeposit}
- Recommended Margin: ${salesPackage.recommendedEnvironment.recommendedDeposit}
- VPS Recommended: ${salesPackage.recommendedEnvironment.vpsRecommended ? 'Recommended (24/7 continuous operation)' : 'Optional'}

## [Buyer Parameter Setup Manual]
${salesPackage.parameterManual
  .map(
    (grp) => `### ${grp.group}
| Parameter | Default | Description | Note |
|---|---|---|---|
${grp.items.map((it) => `| ${it.name} | ${it.defaultValue} | ${it.description} | ${it.note} |`).join('\n')}`
  )
  .join('\n\n')}

## [Frequently Asked Questions (FAQ)]
${salesPackage.faqList.map((f) => `### ${f.question}\n${f.answer}`).join('\n\n')}

## [Risk Disclosure & Disclaimer]
${salesPackage.riskDisclaimer}
`;
    }

    return `# ${salesPackage.title}
${salesPackage.subTitle}

## 【キャッチコピー・特徴】
${salesPackage.catchyPoints.map((p) => `- ${p}`).join('\n')}

## 【商品の特徴・開発コンセプト】
${salesPackage.productOverview}

## 【推奨動作環境】
- 推奨ブローカー: ${salesPackage.recommendedEnvironment.broker}
- 推奨レバレッジ: ${salesPackage.recommendedEnvironment.leverage}
- 最低証拠金: ${salesPackage.recommendedEnvironment.minDeposit}
- 推奨証拠金: ${salesPackage.recommendedEnvironment.recommendedDeposit}
- VPS推奨: ${salesPackage.recommendedEnvironment.vpsRecommended ? '推奨 (24時間安定稼働)' : '不要'}

## 【購入者様向け パラメータ設定マニュアル】
${salesPackage.parameterManual
  .map(
    (grp) => `### ${grp.group}
| パラメータ名 | 初期値 | 説明 | 備考 |
|---|---|---|---|
${grp.items.map((it) => `| ${it.name} | ${it.defaultValue} | ${it.description} | ${it.note} |`).join('\n')}`
  )
  .join('\n\n')}

## 【よくある質問 (FAQ)】
${salesPackage.faqList.map((f) => `### ${f.question}\n${f.answer}`).join('\n\n')}

## 【注意事項・免責事項】
${salesPackage.riskDisclaimer}
`;
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getFullMarkdown());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/25 flex items-center justify-center text-amber-400">
            <ShoppingBag className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              {t.salesPackage.title}
              <span className="text-[11px] font-semibold text-amber-400 bg-amber-950/60 border border-amber-800/60 px-2 py-0.5 rounded">
                {t.salesPackage.badge}
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              {t.salesPackage.desc}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <a
            href="https://www.gogojungle.co.jp/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 text-xs font-medium transition"
          >
            <span>{t.salesPackage.openMarket}</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold transition shadow-md shadow-amber-900/30 cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-white" />
                <span>{t.salesPackage.copiedText}</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>{t.salesPackage.copyAll}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Title & Subtitle Preview */}
      <div className="bg-slate-950/70 border border-slate-800 rounded-lg p-4 space-y-2">
        <div className="text-xs text-amber-400 font-semibold">{t.salesPackage.previewTitle}</div>
        <h3 className="text-base font-bold text-slate-100 leading-snug">{salesPackage.title}</h3>
        <p className="text-xs text-slate-300">{salesPackage.subTitle}</p>
      </div>

      {/* Catchy Highlights */}
      <div className="space-y-2">
        <div className="text-xs font-semibold text-slate-300">{t.salesPackage.highlights}</div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {salesPackage.catchyPoints.map((point, i) => (
            <div
              key={i}
              className="flex items-start gap-2 bg-slate-950/40 border border-slate-800/80 rounded-lg p-2.5 text-xs text-slate-300"
            >
              <div className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 text-[10px] font-bold">
                ✓
              </div>
              <span>{point}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Recommended Environment */}
      <div className="bg-slate-950/60 border border-slate-800 rounded-lg p-4 space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
          <Server className="w-4 h-4 text-cyan-400" />
          <span>{t.salesPackage.recommendedSpec}</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[11px]">{t.salesPackage.broker}</div>
            <div className="text-slate-200 font-medium mt-1">{salesPackage.recommendedEnvironment.broker}</div>
          </div>
          <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[11px]">{t.salesPackage.leverage}</div>
            <div className="text-slate-200 font-medium mt-1">{salesPackage.recommendedEnvironment.leverage}</div>
          </div>
          <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[11px]">{t.salesPackage.deposit}</div>
            <div className="text-emerald-400 font-semibold mt-1">{salesPackage.recommendedEnvironment.recommendedDeposit}</div>
          </div>
          <div className="bg-slate-900 p-2.5 rounded border border-slate-800">
            <div className="text-slate-400 text-[11px]">{t.salesPackage.vps}</div>
            <div className="text-slate-200 font-medium mt-1">{t.salesPackage.vpsDesc}</div>
          </div>
        </div>
      </div>

      {/* FAQ list */}
      <div className="space-y-2">
        <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300">
          <HelpCircle className="w-4 h-4 text-cyan-400" />
          <span>{t.salesPackage.faqTitle}</span>
        </div>
        <div className="space-y-2">
          {salesPackage.faqList.map((faq, i) => (
            <div
              key={i}
              className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3 space-y-1 text-xs"
            >
              <div className="font-bold text-slate-200 text-xs">{faq.question}</div>
              <p className="text-slate-400 leading-relaxed text-[11px]">{faq.answer}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Disclaimer */}
      <div className="bg-rose-950/20 border border-rose-800/30 rounded-lg p-3.5 flex items-start gap-2.5 text-xs text-rose-300">
        <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
        <div className="space-y-1">
          <div className="font-bold text-rose-200">{t.salesPackage.disclaimerTitle}</div>
          <p className="text-rose-300/80 text-[11px] leading-relaxed">
            {salesPackage.riskDisclaimer}
          </p>
        </div>
      </div>
    </div>
  );
};

