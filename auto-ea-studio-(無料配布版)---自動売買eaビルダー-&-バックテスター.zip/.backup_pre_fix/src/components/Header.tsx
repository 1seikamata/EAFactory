/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Bot, Sparkles, Download, Lock, Globe } from 'lucide-react';
import { UpgradeTrigger } from './UpgradeModal';
import { useLanguage } from '../i18n/LanguageContext';

interface HeaderProps {
  onOpenAiModal: () => void;
  onExportAll: () => void;
  onOpenUpgradeModal: (trigger: UpgradeTrigger) => void;
  isAiGenerating?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenAiModal,
  onExportAll,
  onOpenUpgradeModal,
  isAiGenerating,
}) => {
  const { language, setLanguage, t } = useLanguage();

  return (
    <header
      id="main-header"
      className="border-b border-slate-800 bg-slate-900/95 backdrop-blur sticky top-0 z-40 px-4 lg:px-8 py-3.5 shadow-md"
    >
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-lg font-black text-slate-100 tracking-tight">
                {t.header.title}
              </h1>
              <span className="px-2 py-0.5 text-[11px] font-bold rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                {t.header.freeBadge}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {t.header.subtitle}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 self-end sm:self-auto flex-wrap">
          {/* Upgrade CTA */}
          <button
            id="header-upgrade-button"
            type="button"
            onClick={() => onOpenUpgradeModal('GENERAL')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white text-xs font-bold transition shadow-md shadow-cyan-900/30 cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5 text-cyan-200" />
            <span>{t.common.proFeaturesBtn}</span>
          </button>

          <button
            id="header-ai-modal-button"
            type="button"
            onClick={onOpenAiModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-cyan-300 border border-slate-700 hover:border-slate-600 text-xs font-medium transition shadow-sm cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>{isAiGenerating ? t.common.aiGenerating : t.common.aiAnalysisBtn}</span>
          </button>

          <button
            id="header-export-all-button"
            type="button"
            onClick={onExportAll}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-300" />
            <span>{t.common.exportAllBtn}</span>
          </button>

          {/* Language Switcher UI (ヘッダー右上に配置: 日本語 | English) */}
          <div
            id="header-language-switcher"
            className="flex items-center rounded-lg bg-slate-800 border border-slate-700 p-0.5 text-xs shadow-inner"
            aria-label="Language Selector"
          >
            <Globe className="w-3.5 h-3.5 text-slate-400 ml-1.5 mr-1 shrink-0" />
            <button
              type="button"
              id="lang-btn-ja"
              onClick={() => setLanguage('ja')}
              className={`px-2 py-1 rounded text-xs font-bold transition cursor-pointer ${
                language === 'ja'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              日本語
            </button>
            <span className="text-slate-600 px-1 select-none">|</span>
            <button
              type="button"
              id="lang-btn-en"
              onClick={() => setLanguage('en')}
              className={`px-2 py-1 rounded text-xs font-bold transition cursor-pointer ${
                language === 'en'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              English
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

