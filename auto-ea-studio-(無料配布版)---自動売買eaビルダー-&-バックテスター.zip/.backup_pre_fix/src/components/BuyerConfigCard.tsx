/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  BuyerConfig,
  CurrencyPair,
  Timeframe,
  ProfitFactorGoal,
  MaxDrawdownLimit,
  TradeFrequency,
  MaxPositions,
} from '../types';
import {
  Sliders,
  RefreshCw,
  Sparkles,
  Check,
  Lock,
  Calendar,
  Wallet,
  Scale,
  ArrowRight,
  Play,
  Zap,
  Layers,
} from 'lucide-react';
import { UpgradeTrigger } from './UpgradeModal';
import { useLanguage } from '../i18n/LanguageContext';

interface BuyerConfigCardProps {
  config: BuyerConfig;
  onChange: (newConfig: BuyerConfig) => void;
  onRunBacktest: () => void;
  isRunning: boolean;
  onOpenUpgradeModal: (trigger: UpgradeTrigger) => void;
}

export const BuyerConfigCard: React.FC<BuyerConfigCardProps> = ({
  config,
  onChange,
  onRunBacktest,
  isRunning,
  onOpenUpgradeModal,
}) => {
  const { language, t } = useLanguage();
  const isEn = language === 'en';

  const updateField = <K extends keyof BuyerConfig>(key: K, value: BuyerConfig[K]) => {
    onChange({
      ...config,
      [key]: value,
    });
  };

  // 1. 通貨ペア：無料版はEUR/USDのみ。他はクリックでアップグレードモーダルへ誘導
  const pairOptions: {
    value: CurrencyPair;
    label: string;
    desc: string;
    isProOnly?: boolean;
  }[] = [
    {
      value: 'EURUSD',
      label: isEn ? 'EUR/USD (Euro / US Dollar)' : 'EUR/USD (ユーロドル)',
      desc: isEn
        ? 'Highest market liquidity & smooth trend formation (Free Edition)'
        : '世界最大取引量・素直なトレンド形成（無料版対象）',
      isProOnly: false,
    },
    {
      value: 'USDJPY',
      label: isEn ? 'USD/JPY (US Dollar / Japanese Yen)' : 'USD/JPY (ドル円)',
      desc: isEn ? 'Tightest spread & very popular among retail traders' : 'スプレッド狭小・日本人トレーダー一番人気',
      isProOnly: true,
    },
    {
      value: 'GBPJPY',
      label: isEn ? 'GBP/JPY (Pound / Japanese Yen)' : 'GBP/JPY (ポンド円)',
      desc: isEn ? 'High volatility with strong explosive momentum' : '高ボラティリティ・トレンド爆発力重視',
      isProOnly: true,
    },
    {
      value: 'EURJPY',
      label: isEn ? 'EUR/JPY (Euro / Japanese Yen)' : 'EUR/JPY (ユーロ円)',
      desc: isEn ? 'Optimal for stable cross-currency swing trading' : '安定スイングトレード向け',
      isProOnly: true,
    },
    {
      value: 'XAUUSD',
      label: isEn ? 'XAU/USD (Gold)' : 'XAU/USD (ゴールド)',
      desc: isEn ? 'Ultra-high intraday range & quick profit velocity' : '高ボラティリティ・短時間での高利得',
      isProOnly: true,
    },
    {
      value: 'AUTO',
      label: isEn ? '🌟 Auto (AI Recommended / Multi-Pair)' : '🌟 お任せ (AI推奨 / マルチ通貨)',
      desc: isEn
        ? 'Auto-selects optimal win-rate pair based on market regime'
        : '市場環境に応じた最適高勝率ペアを自動適用',
      isProOnly: true,
    },
  ];

  // 2. 時間足：無料版でもすべて選択可能（制限なし）
  const timeframeOptions: { value: Timeframe; label: string; badge?: string }[] = [
    { value: 'M5', label: isEn ? 'M5 (5-min)' : 'M5 (5分足)' },
    { value: 'M15', label: isEn ? 'M15 (15-min)' : 'M15 (15分足)' },
    { value: 'M30', label: isEn ? 'M30 (30-min)' : 'M30 (30分足)', badge: t.config.recommendedBadge },
    { value: 'H1', label: isEn ? 'H1 (1-hour)' : 'H1 (1時間足)', badge: t.config.stableBadge },
    { value: 'H4', label: isEn ? 'H4 (4-hour)' : 'H4 (4時間足)', badge: t.config.swingBadge },
    { value: 'D1', label: isEn ? 'D1 (Daily)' : 'D1 (日足)' },
    { value: 'AUTO', label: isEn ? '🌟 AI Auto' : '🌟 AI推奨足', badge: t.config.autoBadge },
  ];

  // 3. PF：無料版は「PF 1.2以上」の1種類のみ。他は鍵付きPro限定
  const pfOptions: {
    value: ProfitFactorGoal;
    label: string;
    desc: string;
    isProOnly?: boolean;
  }[] = [
    {
      value: '1.2+',
      label: isEn ? 'PF 1.2+ (Core Standard)' : 'PF 1.2以上 (基本水準)',
      desc: isEn
        ? 'Most resilient and robust for long-term real account execution (Free Edition)'
        : '実運用で最も破綻しにくく長期安定（無料版選択可能）',
      isProOnly: false,
    },
    {
      value: '1.5+',
      label: isEn ? 'PF 1.5+ (High-Yield Balance)' : 'PF 1.5以上 (高収益バランス)',
      desc: isEn ? 'High mathematical expectancy popular for commercial EA sales' : 'プロ販売用で人気の高い高期待値設計',
      isProOnly: true,
    },
    {
      value: '1.8+',
      label: isEn ? 'PF 1.8+ (Prime Performance)' : 'PF 1.8以上 (極上パフォーマンス)',
      desc: isEn ? 'High profit efficiency through strict entry selectivity' : '厳選エントリーによる高い利益効率',
      isProOnly: true,
    },
    {
      value: '2.0+',
      label: isEn ? 'PF 2.0+ (Premium Edge)' : 'PF 2.0以上 (プレミアム目標)',
      desc: isEn ? 'Pursuing the highest tier statistical market edge' : '最高峰のエッジを追求',
      isProOnly: true,
    },
    {
      value: 'AUTO',
      label: isEn ? '🌟 Auto (AI Optimization)' : '🌟 お任せ (自動最適化)',
      desc: isEn ? 'Targets high yields while preventing curve-fitting' : '過剰最適化を避けつつ高収益を狙う',
      isProOnly: true,
    },
  ];

  // 4. 最大ドローダウン：無料版は「最大DD 10%以下」の1種類のみ初期選択
  const ddOptions: {
    value: MaxDrawdownLimit;
    label: string;
    desc: string;
    isProOnly?: boolean;
  }[] = [
    {
      value: '10%',
      label: isEn ? 'Max DD <= 10% (Safe Standard)' : '最大DD 10%以下 (標準安全圏)',
      desc: isEn
        ? 'Free Edition default: balanced risk tolerance maintaining healthy profitability'
        : '無料版初期設定・十分な収益性を維持する適度なリスク許容度',
      isProOnly: false,
    },
    {
      value: '5%',
      label: isEn ? 'Max DD <= 5% (Target Achieved)' : '最大DD 5%以下 (指定目標クリア)',
      desc: isEn ? 'Low-drawdown defensive profile for hands-off safe trading' : '安心して放置できる低ドローダウン防衛水準',
      isProOnly: true,
    },
    {
      value: '3%',
      label: isEn ? 'Max DD <= 3% (Ultra Low Risk)' : '最大DD 3%以下 (極限の低リスク)',
      desc: isEn ? 'Capital defense top priority for large institutional accounts' : '資金防衛最優先・大口運用向け鉄壁設計',
      isProOnly: true,
    },
    {
      value: 'AUTO',
      label: isEn ? '🌟 Auto (Dynamic Risk Control)' : '🌟 お任せ (自動リスク調整)',
      desc: isEn ? 'Minimizes drawdown while securing adequate trade volume' : '取引数を確保しながらDDを最小化',
      isProOnly: true,
    },
  ];

  // 5. 希望取引回数：無料版でもすべて選択可能（制限なし・鍵なし）
  const freqOptions: { value: TradeFrequency; label: string; desc: string }[] = [
    {
      value: 'WEEKLY_1_2',
      label: isEn ? '1-2 times / week' : '週1〜2回',
      desc: isEn ? 'Zero over-trading; selective swing entries avoiding whipsaws' : '無駄打ちゼロ・だましを徹底回避する厳選スイング',
    },
    {
      value: 'WEEKLY_1_3',
      label: isEn ? '1-3 times / week' : '週1〜3回',
      desc: isEn ? 'Standard balanced entry frequency with healthy sample size' : '最もバランスが良い標準的なエントリー頻度',
    },
    {
      value: 'WEEKLY_3_5',
      label: isEn ? '3-5 times / week' : '週3〜5回',
      desc: isEn ? 'Hybrid day & swing trading capturing multi-day momentum' : '売買機会を逃さないデイトレ・スイング複合',
    },
    {
      value: 'DAILY_1',
      label: isEn ? 'Once per day' : '日に1回',
      desc: isEn ? 'Active daily management with consistent market engagement' : '毎日の収支確認を楽しみたいアクティブ運用',
    },
    {
      value: 'DAILY_2_3',
      label: isEn ? '2-3 times / day' : '日に2〜3回',
      desc: isEn ? 'Capitalizes on intraday session volatility bursts' : '高ボラティリティ時の短期積み上げ重視',
    },
    {
      value: 'NO_SPEC',
      label: isEn ? 'No restriction' : '指定なし',
      desc: isEn ? 'Prioritizes expected profit value regardless of trade count' : 'シグナル頻度に拘らず利益期待値を最優先',
    },
    {
      value: 'AI_RECOMMENDED',
      label: isEn ? '🌟 AI Recommended' : '🌟 AI推奨',
      desc: isEn ? 'Optimally allocated to currency pair & timeframe volatility' : '時間足・通貨ペアのボラティリティに最適配分',
    },
  ];

  // 6. バックテスト期間：無料版は3か月固定。他は上位版限定
  const periodOptions = [
    { value: '3MONTHS', label: isEn ? '3 Months' : '3か月', badge: t.config.freeRefBadge, isProOnly: false },
    { value: '1YEAR', label: isEn ? '1 Year' : '1年', badge: t.config.proOnlyBadge, isProOnly: true },
    { value: '3YEARS', label: isEn ? '3 Years' : '3年', badge: t.config.proOnlyBadge, isProOnly: true },
    { value: '5YEARS', label: isEn ? '5 Years' : '5年', badge: t.config.proOnlyBadge, isProOnly: true },
  ];

  // 9. ポジション数：無料版は「1個」のみ。上位版はポジション数を設定可能 (5以下, 10以下, 20以下, 20～, お任せ)
  const positionOptions: {
    value: MaxPositions;
    label: string;
    subLabel: string;
    isProOnly: boolean;
  }[] = [
    {
      value: '1',
      label: isEn ? '1 Position' : '1個',
      subLabel: isEn ? 'Free Edition (Single Position)' : '無料版 (単一ポジション・低リスク)',
      isProOnly: false,
    },
    {
      value: 'LE_5',
      label: isEn ? '<= 5' : '5以下',
      subLabel: isEn ? 'Small-Scale Scaling (Pro)' : '小規模分散エントリー (上位版)',
      isProOnly: true,
    },
    {
      value: 'LE_10',
      label: isEn ? '<= 10' : '10以下',
      subLabel: isEn ? 'Zone Building (Pro)' : 'ゾーン構築・スイング分散 (上位版)',
      isProOnly: true,
    },
    {
      value: 'LE_20',
      label: isEn ? '<= 20' : '20以下',
      subLabel: isEn ? 'Multi-Tier Pyramiding (Pro)' : '多層ピラミッディング (上位版)',
      isProOnly: true,
    },
    {
      value: 'GE_20',
      label: isEn ? '20+' : '20～',
      subLabel: isEn ? 'Dense Grid & Trailing (Pro)' : '高密度グリッド・トラリピ (上位版)',
      isProOnly: true,
    },
    {
      value: 'AUTO',
      label: isEn ? '🌟 Auto' : '🌟 お任せ',
      subLabel: isEn ? 'AI Dynamic Risk Adaptation (Pro)' : 'AI市場適応型・自動調整 (上位版)',
      isProOnly: true,
    },
  ];

  return (
    <div
      id="buyer-config-card"
      className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-2xl space-y-6"
    >
      {/* Card Header & Notice */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-start sm:items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base font-bold text-white">
                {t.config.title}
              </h2>
              <span className="text-[11px] font-semibold text-cyan-300 bg-cyan-950/80 border border-cyan-700/60 px-2.5 py-0.5 rounded-full">
                {t.config.freeBadge}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {t.config.description}
            </p>
          </div>
        </div>

        {/* Upgrade Banner Button */}
        <button
          id="config-header-upgrade-cta"
          onClick={() => onOpenUpgradeModal('GENERAL')}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-blue-950/70 border border-blue-600/50 hover:border-cyan-400 text-cyan-300 hover:text-white text-xs font-semibold transition cursor-pointer self-start sm:self-auto shrink-0 shadow-sm"
        >
          <Lock className="w-3.5 h-3.5 text-cyan-400" />
          <span>{t.common.proFeaturesBtn}</span>
          <ArrowRight className="w-3.5 h-3.5 ml-0.5 text-cyan-400" />
        </button>
      </div>

      {/* Grid of Inputs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* 1. 通貨ペア */}
        <div id="section-currency-pair" className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <span>{t.config.pairTitle}</span>
              <span className="text-[10px] font-normal text-cyan-400 bg-cyan-950/60 px-1.5 py-0.2 rounded border border-cyan-800/60">
                {isEn ? '1 Pair' : '1ペア選択'}
              </span>
            </label>
            <span className="text-[11px] text-slate-400 font-medium">
              {isEn ? 'Current: ' : '現在: '}
              <strong className="text-cyan-300">{config.pair}</strong>
            </span>
          </div>

          <div className="grid grid-cols-1 gap-1.5">
            {pairOptions.map((opt) => {
              const selected = config.pair === opt.value;
              const isPro = opt.isProOnly;

              return (
                <button
                  key={opt.value}
                  type="button"
                  id={`pair-option-${opt.value}`}
                  onClick={() => {
                    if (isPro) {
                      onOpenUpgradeModal('PAIR');
                    } else {
                      updateField('pair', opt.value);
                    }
                  }}
                  className={`p-2.5 rounded-xl text-left text-xs transition border cursor-pointer flex items-center justify-between ${
                    selected
                      ? 'bg-cyan-950/70 border-cyan-500 text-white font-semibold shadow-md shadow-cyan-950/50'
                      : isPro
                      ? 'bg-slate-850/50 border-slate-800 text-slate-400 hover:bg-slate-800/80 hover:border-slate-700'
                      : 'bg-slate-800/60 border-slate-700 text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex-1 min-w-0 pr-2">
                    <div className="flex items-center gap-2">
                      <span className={selected ? 'text-cyan-300 font-bold' : ''}>
                        {opt.label}
                      </span>
                      {isPro && (
                        <span className="inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.2 rounded bg-slate-800 border border-slate-700 text-amber-300">
                          <Lock className="w-2.5 h-2.5" /> {t.config.proOnlyBadge}
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate mt-0.5">
                      {opt.desc}
                    </div>
                  </div>

                  {selected ? (
                    <div className="w-5 h-5 rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300 shrink-0">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  ) : isPro ? (
                    <Lock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  ) : null}
                </button>
              );
            })}
          </div>

          <p className="text-[11px] text-slate-400 leading-tight">
            {t.config.pairLimitNotice}
          </p>
        </div>

        {/* 2. 時間足 (制限なし) */}
        <div id="section-timeframe" className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <span>{t.config.timeframeTitle}</span>
              <span className="text-[10px] font-normal text-emerald-400 bg-emerald-950/60 px-1.5 py-0.2 rounded border border-emerald-800/60">
                {isEn ? 'All Available' : '全足選択可能'}
              </span>
            </label>
            <span className="text-[11px] text-slate-400 font-medium">
              {isEn ? 'Current: ' : '現在: '}
              <strong className="text-emerald-300">{config.timeframe}</strong>
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
            {timeframeOptions.map((opt) => {
              const selected = config.timeframe === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  id={`timeframe-option-${opt.value}`}
                  onClick={() => updateField('timeframe', opt.value)}
                  className={`px-2.5 py-2 rounded-xl text-center text-xs transition border cursor-pointer ${
                    selected
                      ? 'bg-emerald-950/70 border-emerald-500 text-emerald-200 font-bold shadow-md'
                      : 'bg-slate-800/60 border-slate-700/70 text-slate-300 hover:bg-slate-800 hover:border-slate-600'
                  } ${opt.value === 'AUTO' ? 'col-span-2 sm:col-span-3' : ''}`}
                >
                  <div className="flex items-center justify-center gap-1">
                    <span>{opt.label}</span>
                    {opt.badge && opt.value !== 'AUTO' && (
                      <span className="text-[9px] px-1 py-0.2 bg-emerald-500/20 text-emerald-300 rounded font-normal">
                        {opt.badge}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          <p className="text-[11px] text-slate-400 leading-tight">
            {t.config.timeframeNotice}
          </p>
        </div>

        {/* 3. プロフィットファクター (PF) */}
        <div id="section-pf" className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <span>{t.config.pfTitle}</span>
            </label>
            <span className="text-[11px] text-slate-400 font-medium">
              {isEn ? 'Free: ' : '無料版: '}
              <strong className="text-cyan-300">PF 1.2+</strong>
            </span>
          </div>

          <div className="space-y-1.5">
            {pfOptions.map((opt) => {
              const selected = config.desiredPf === opt.value;
              const isPro = opt.isProOnly;

              return (
                <button
                  key={opt.value}
                  type="button"
                  id={`pf-option-${opt.value}`}
                  onClick={() => {
                    if (isPro) {
                      onOpenUpgradeModal('PF');
                    } else {
                      updateField('desiredPf', opt.value);
                    }
                  }}
                  className={`w-full p-2.5 rounded-xl text-left text-xs transition border cursor-pointer flex items-center justify-between ${
                    selected
                      ? 'bg-cyan-950/70 border-cyan-500 text-cyan-200 font-bold shadow-md'
                      : isPro
                      ? 'bg-slate-850/40 border-slate-800 text-slate-400 hover:bg-slate-800/80 hover:border-slate-700'
                      : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex-1 min-w-0 pr-2">
                    <div className="flex items-center gap-2">
                      <span className={selected ? 'text-cyan-300 font-bold' : ''}>
                        {opt.label}
                      </span>
                      {isPro && (
                        <span className="inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.2 rounded bg-slate-850 border border-slate-700 text-amber-300 font-normal">
                          <Lock className="w-2.5 h-2.5" /> {t.config.proOnlyBadge}
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate mt-0.5">
                      {opt.desc}
                    </div>
                  </div>

                  {selected ? (
                    <div className="w-5 h-5 rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300 shrink-0">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  ) : isPro ? (
                    <Lock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  ) : null}
                </button>
              );
            })}
          </div>

          <p className="text-[11px] text-slate-400 leading-tight">
            {t.config.pfLimitNotice}
          </p>
        </div>

        {/* 4. 最大ドローダウン */}
        <div id="section-max-dd" className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <span>{t.config.ddTitle}</span>
            </label>
            <span className="text-[11px] text-slate-400 font-medium">
              {isEn ? 'Free: ' : '無料版: '}
              <strong className="text-cyan-300">{isEn ? '<= 10%' : '10%以下'}</strong>
            </span>
          </div>

          <div className="space-y-1.5">
            {ddOptions.map((opt) => {
              const selected = config.maxDrawdown === opt.value;
              const isPro = opt.isProOnly;

              return (
                <button
                  key={opt.value}
                  type="button"
                  id={`dd-option-${opt.value}`}
                  onClick={() => {
                    if (isPro) {
                      onOpenUpgradeModal('DD');
                    } else {
                      updateField('maxDrawdown', opt.value);
                    }
                  }}
                  className={`w-full p-2.5 rounded-xl text-left text-xs transition border cursor-pointer flex items-center justify-between ${
                    selected
                      ? 'bg-cyan-950/70 border-cyan-500 text-cyan-200 font-bold shadow-md'
                      : isPro
                      ? 'bg-slate-850/40 border-slate-800 text-slate-400 hover:bg-slate-800/80 hover:border-slate-700'
                      : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex-1 min-w-0 pr-2">
                    <div className="flex items-center gap-2">
                      <span className={selected ? 'text-cyan-300 font-bold' : ''}>
                        {opt.label}
                      </span>
                      {isPro && (
                        <span className="inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.2 rounded bg-slate-850 border border-slate-700 text-amber-300 font-normal">
                          <Lock className="w-2.5 h-2.5" /> {t.config.proOnlyBadge}
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate mt-0.5">
                      {opt.desc}
                    </div>
                  </div>

                  {selected ? (
                    <div className="w-5 h-5 rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300 shrink-0">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  ) : isPro ? (
                    <Lock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  ) : null}
                </button>
              );
            })}
          </div>

          <p className="text-[11px] text-slate-400 leading-tight">
            {t.config.ddLimitNotice}
          </p>
        </div>

        {/* 5. 希望取引回数 (制限なし) */}
        <div id="section-frequency" className="space-y-2 md:col-span-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <span>{t.config.freqTitle}</span>
              <span className="text-[10px] font-normal text-emerald-400 bg-emerald-950/60 px-1.5 py-0.2 rounded border border-emerald-800/60">
                {isEn ? 'All Available' : '全回数選択可能'}
              </span>
            </label>
            <span className="text-[11px] text-slate-400 font-medium">
              {isEn ? 'Current: ' : '現在: '}
              <strong className="text-emerald-300">
                {freqOptions.find((f) => f.value === config.frequency)?.label || (isEn ? 'Selected' : '選択中')}
              </strong>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-1.5">
            {freqOptions.map((opt) => {
              const selected = config.frequency === opt.value;
              return (
                <button
                  key={opt.value}
                  type="button"
                  id={`freq-option-${opt.value}`}
                  onClick={() => updateField('frequency', opt.value)}
                  className={`p-2.5 rounded-xl text-left text-xs transition border cursor-pointer flex items-start justify-between ${
                    selected
                      ? 'bg-emerald-950/70 border-emerald-500 text-emerald-200 font-bold shadow-md'
                      : 'bg-slate-800/60 border-slate-700/70 text-slate-300 hover:bg-slate-800 hover:border-slate-600'
                  }`}
                >
                  <div className="min-w-0 flex-1 pr-1">
                    <div className="font-semibold text-slate-100">{opt.label}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5 leading-snug">
                      {opt.desc}
                    </div>
                  </div>
                  {selected && (
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  )}
                </button>
              );
            })}
          </div>

          <p className="text-[11px] text-slate-400 leading-tight">
            {t.config.freqNotice}
          </p>
        </div>

        {/* 6. バックテスト期間 (無料版は3か月固定) */}
        <div id="section-period" className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.config.periodTitle}</span>
            </label>
            <span className="text-[11px] text-cyan-300 font-semibold">
              {isEn ? '[ 3 Months ] Free Edition' : '[ 3か月 ] 無料版'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-1.5">
            {periodOptions.map((opt) => {
              const selected = opt.value === '3MONTHS';
              const isPro = opt.isProOnly;

              return (
                <button
                  key={opt.value}
                  type="button"
                  id={`period-option-${opt.value}`}
                  onClick={() => {
                    if (isPro) {
                      onOpenUpgradeModal('PERIOD');
                    }
                  }}
                  className={`p-2.5 rounded-xl text-center text-xs transition border cursor-pointer ${
                    selected
                      ? 'bg-cyan-950/70 border-cyan-500 text-cyan-200 font-bold shadow-md'
                      : 'bg-slate-850/40 border-slate-800 text-slate-400 hover:bg-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-center gap-1.5">
                    <span>{opt.label}</span>
                    {isPro ? (
                      <span className="inline-flex items-center gap-0.5 text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-amber-300 font-normal">
                        <Lock className="w-2.5 h-2.5" /> {t.config.proOnlyBadge}
                      </span>
                    ) : (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 font-normal">
                        {t.config.freeBadge}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          <p className="text-[11px] text-slate-400 leading-tight">
            {t.config.periodNotice}
          </p>
        </div>

        {/* 7. 運用予定資金 (100万円固定表示) */}
        <div id="section-capital" className="space-y-2 md:col-span-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Wallet className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.config.capitalTitle}</span>
            </label>
            <button
              type="button"
              id="capital-upgrade-hint"
              onClick={() => onOpenUpgradeModal('CAPITAL')}
              className="text-[11px] text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
            >
              {isEn ? 'Want custom capital? (Pro Edition)' : '資金を自由に設定するには？ (上位版)'}
            </button>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-baseline gap-2">
                <span className="text-lg font-black text-white tracking-tight">
                  {t.config.capitalValue}
                </span>
                <span className="text-xs font-medium text-slate-400">
                  {isEn ? '(Base capital ¥1,000,000 JPY - Free Edition fixed)' : '(基準資金100万円・無料配布版固定)'}
                </span>
              </div>
              <p className="text-[11px] text-slate-300 mt-1">
                {t.config.capitalDesc}
              </p>
            </div>

            <button
              type="button"
              id="capital-pro-button"
              onClick={() => onOpenUpgradeModal('CAPITAL')}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-750 text-slate-300 text-xs font-medium flex items-center gap-1.5 transition cursor-pointer self-stretch sm:self-auto justify-center"
            >
              <Lock className="w-3 h-3 text-amber-300" />
              <span>{t.config.capitalProHint}</span>
            </button>
          </div>
        </div>

        {/* 8. 最小ロット (Minimum Lot) */}
        <div id="section-minimum-lot" className="space-y-2 md:col-span-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Scale className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.config.lotTitle}</span>
            </label>
            <button
              type="button"
              id="lot-upgrade-hint"
              onClick={() => onOpenUpgradeModal('LOT')}
              className="text-[11px] text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
            >
              {t.config.lotProHint}
            </button>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-baseline gap-2">
                <span className="text-xs text-slate-400 font-semibold">{t.config.lotLabel}</span>
                <span className="text-lg font-black text-cyan-300 tracking-tight">
                  {t.config.lotValue}
                </span>
                <span className="text-[10px] text-amber-300 bg-amber-950/60 border border-amber-800/60 px-1.5 py-0.5 rounded">
                  {t.config.lotFixedTag}
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {t.config.lotDesc}
              </p>
              <p className="text-[11px] text-slate-400">
                {t.config.lotSubNote}
              </p>
            </div>

            <button
              type="button"
              id="lot-pro-button"
              onClick={() => onOpenUpgradeModal('LOT')}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-750 text-slate-300 text-xs font-medium flex items-center gap-1.5 transition cursor-pointer self-stretch sm:self-auto justify-center shrink-0"
            >
              <Lock className="w-3 h-3 text-amber-300" />
              <span>{t.config.lotProButton}</span>
            </button>
          </div>
        </div>

        {/* 9. ポジション数 (無料版は1ポジションのみ・上位版で設定可能) */}
        <div id="section-max-positions" className="space-y-2 md:col-span-2">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.config.positionsTitle}</span>
              <span className="text-[10px] font-semibold text-cyan-300 bg-cyan-950/80 border border-cyan-700/60 px-2 py-0.2 rounded-full">
                {isEn ? 'Free: 1 Position' : '無料版: 1個固定'}
              </span>
            </label>
            <button
              type="button"
              id="positions-upgrade-hint"
              onClick={() => onOpenUpgradeModal('MAX_POSITIONS')}
              className="text-[11px] text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
            >
              {isEn ? 'Want multiple positions or grid trading? (Pro Edition)' : '複数ポジション・グリッド設定をするには？ (上位版)'}
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
            {positionOptions.map((opt) => {
              const currentVal = config.maxPositions || '1';
              const selected = currentVal === opt.value;
              const isPro = opt.isProOnly;

              return (
                <button
                  key={opt.value}
                  type="button"
                  id={`position-option-${opt.value}`}
                  onClick={() => {
                    if (isPro) {
                      onOpenUpgradeModal('MAX_POSITIONS');
                    } else {
                      updateField('maxPositions', opt.value);
                    }
                  }}
                  className={`p-3 rounded-xl text-left text-xs transition border cursor-pointer flex flex-col justify-between h-full relative group ${
                    selected
                      ? 'bg-cyan-950/80 border-cyan-500 text-cyan-200 font-bold shadow-lg shadow-cyan-950/50 ring-1 ring-cyan-500/50'
                      : isPro
                      ? 'bg-slate-850/40 border-slate-800 text-slate-400 hover:bg-slate-800/80 hover:border-slate-700'
                      : 'bg-slate-800/60 border-slate-700 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-start justify-between gap-1 w-full mb-1">
                    <span className={`text-sm font-bold ${selected ? 'text-cyan-300' : 'text-slate-200'}`}>
                      {opt.label}
                    </span>
                    {selected ? (
                      <div className="w-4 h-4 rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300 shrink-0">
                        <Check className="w-3 h-3" />
                      </div>
                    ) : isPro ? (
                      <div className="flex items-center gap-0.5 text-[9px] px-1.5 py-0.2 rounded bg-slate-900/90 border border-slate-750 text-amber-300 font-normal">
                        <Lock className="w-2.5 h-2.5" />
                        <span>{t.config.proOnlyBadge}</span>
                      </div>
                    ) : null}
                  </div>

                  <div className="text-[10px] text-slate-400 leading-tight">
                    {opt.subLabel}
                  </div>

                  {isPro && (
                    <div className="mt-2 pt-1.5 border-t border-slate-800/80 flex items-center gap-1 text-[10px] text-amber-400/90 group-hover:text-amber-300">
                      <Sparkles className="w-2.5 h-2.5" />
                      <span>{isEn ? 'Unlock in Pro' : '上位版で設定可能'}</span>
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          <p className="text-[11px] text-slate-400 leading-tight">
            {t.config.positionsLimitNotice}
          </p>
        </div>
      </div>

      {/* Primary Action Button */}
      <div className="pt-4 border-t border-slate-800 flex flex-col items-center justify-center gap-3">
        <button
          id="btn-start-ea-generation"
          type="button"
          onClick={onRunBacktest}
          disabled={isRunning}
          className="w-full sm:w-auto min-w-[340px] px-8 py-4 rounded-2xl bg-gradient-to-r from-blue-600 via-cyan-500 to-teal-400 hover:from-blue-500 hover:via-cyan-400 hover:to-teal-300 text-slate-950 font-black text-base transition duration-200 shadow-xl shadow-cyan-500/25 hover:shadow-cyan-400/40 flex items-center justify-center gap-3 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed group active:scale-[0.99]"
        >
          {isRunning ? (
            <>
              <RefreshCw className="w-5 h-5 animate-spin text-slate-950" />
              <span>{t.config.btnGenerating}</span>
            </>
          ) : (
            <>
              <Play className="w-5 h-5 fill-slate-950 text-slate-950 group-hover:scale-110 transition-transform" />
              <span>{t.config.btnGenerate}</span>
              <ArrowRight className="w-5 h-5 text-slate-950 group-hover:translate-x-1 transition-transform" />
            </>
          )}
        </button>

        <div className="flex flex-col items-center gap-1.5 text-center max-w-xl px-2">
          <p className="text-xs text-slate-400 flex items-center justify-center gap-1.5">
            <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>{t.config.btnSubText}</span>
          </p>
          <p className="text-[11px] text-slate-500">
            {t.config.speedHintNote}
          </p>
          <button
            type="button"
            onClick={() => onOpenUpgradeModal('SPEED')}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-400 hover:text-amber-300 underline cursor-pointer mt-0.5"
          >
            <Zap className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span>{t.config.speedHintLink}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

