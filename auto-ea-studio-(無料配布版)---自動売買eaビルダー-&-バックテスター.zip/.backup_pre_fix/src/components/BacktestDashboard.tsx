/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BacktestResult, BuyerConfig } from '../types';
import {
  TrendingUp,
  ShieldCheck,
  Calendar,
  Layers,
  CheckCircle2,
  Lock,
  ArrowRight,
  Info,
  DollarSign,
  Activity,
  Award,
  Scale,
  BarChart3,
  HelpCircle,
  Zap,
} from 'lucide-react';
import { UpgradeTrigger } from './UpgradeModal';
import { useLanguage } from '../i18n/LanguageContext';

interface BacktestDashboardProps {
  result: BacktestResult;
  config: BuyerConfig;
  onOpenUpgradeModal?: (trigger: UpgradeTrigger) => void;
}

export const BacktestDashboard: React.FC<BacktestDashboardProps> = ({
  result,
  config,
  onOpenUpgradeModal,
}) => {
  const { language, t } = useLanguage();
  const isEn = language === 'en';

  const [tradeFilter, setTradeFilter] = useState<'ALL' | 'BUY' | 'SELL' | 'WINS' | 'LOSSES'>('ALL');

  const formatCurrency = (val: number) => {
    if (isEn) {
      return `${val >= 0 ? '+' : ''}¥${val.toLocaleString('en-US')} JPY`;
    }
    return `${val >= 0 ? '+' : ''}${val.toLocaleString('ja-JP')}円`;
  };

  const getFrequencyLabel = (freq: string) => {
    if (isEn) {
      switch (freq) {
        case 'WEEKLY_1_2':
          return '1-2 / week';
        case 'WEEKLY_1_3':
          return '1-3 / week';
        case 'WEEKLY_3_5':
          return '3-5 / week';
        case 'DAILY_1':
          return 'Daily (1x)';
        case 'DAILY_2_3':
          return 'Daily (2-3x)';
        case 'NO_SPEC':
          return 'No restriction';
        case 'AI_RECOMMENDED':
        case 'AUTO':
          return 'AI Recommended';
        default:
          return '1-3 / week';
      }
    }
    switch (freq) {
      case 'WEEKLY_1_2':
        return '週1〜2回';
      case 'WEEKLY_1_3':
        return '週1〜3回';
      case 'WEEKLY_3_5':
        return '週3〜5回';
      case 'DAILY_1':
        return '日に1回';
      case 'DAILY_2_3':
        return '日に2〜3回';
      case 'NO_SPEC':
        return '指定なし';
      case 'AI_RECOMMENDED':
      case 'AUTO':
        return 'AI推奨';
      default:
        return '週1〜3回';
    }
  };

  // SVG Chart Dimensions & Calculations
  const chartWidth = 800;
  const chartHeight = 240;
  const padding = { top: 20, right: 30, bottom: 30, left: 70 };

  const minBalance = Math.min(...result.equityCurve.map((d) => d.balance)) * 0.98;
  const maxBalance = Math.max(...result.equityCurve.map((d) => d.balance)) * 1.02;

  const getX = (index: number) => {
    return (
      padding.left +
      (index / Math.max(1, result.equityCurve.length - 1)) *
        (chartWidth - padding.left - padding.right)
    );
  };

  const getY = (val: number) => {
    return (
      chartHeight -
      padding.bottom -
      ((val - minBalance) / Math.max(1, maxBalance - minBalance)) *
        (chartHeight - padding.top - padding.bottom)
    );
  };

  const pointsString = result.equityCurve
    .map((d, i) => `${getX(i)},${getY(d.balance)}`)
    .join(' ');

  const areaString = `${pointsString} ${getX(
    result.equityCurve.length - 1
  )},${chartHeight - padding.bottom} ${padding.left},${chartHeight - padding.bottom}`;

  const filteredTrades = result.trades.filter((t) => {
    if (tradeFilter === 'BUY') return t.type === 'BUY';
    if (tradeFilter === 'SELL') return t.type === 'SELL';
    if (tradeFilter === 'WINS') return t.profitAmount > 0;
    if (tradeFilter === 'LOSSES') return t.profitAmount < 0;
    return true;
  });

  return (
    <div
      id="backtest-dashboard"
      className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-2xl space-y-6"
    >
      {/* 1. Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold tracking-wider px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 uppercase">
              {t.backtest.badge}
            </span>
            <h3 className="text-base font-bold text-white">
              {t.backtest.title}
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            {isEn
              ? `Generated and verified a 3-month reference backtest based on ${config.pair} / ${config.timeframe}.`
              : `設定したパラメータ（${config.pair} / ${config.timeframe}）に基づき、3か月の参考バックテストを高速検証しました。`}
          </p>
        </div>

        {onOpenUpgradeModal && (
          <button
            id="backtest-upgrade-cta"
            type="button"
            onClick={() => onOpenUpgradeModal('PERIOD')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-xs text-cyan-300 hover:text-white transition cursor-pointer self-start sm:self-auto"
          >
            <Lock className="w-3.5 h-3.5 text-amber-300" />
            <span>{t.backtest.upgradeLongTerm}</span>
          </button>
        )}
      </div>

      {/* 2. SPECIFICATION EXACT TABLE: 参考シミュレーション結果 */}
      <div
        id="reference-simulation-result-table"
        className="rounded-xl bg-gradient-to-br from-slate-900 via-blue-950/40 to-slate-900 border border-cyan-500/30 p-5 shadow-lg"
      >
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800/80">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
              <Award className="w-4 h-4" />
            </div>
            <h4 className="text-sm font-bold text-white tracking-wide">
              {t.backtest.tableTitle}
            </h4>
          </div>
          <span className="text-[11px] text-amber-300 bg-amber-950/60 border border-amber-800/60 px-2 py-0.5 rounded">
            {t.backtest.tableTag}
          </span>
        </div>

        {/* Structured Grid in exact requirement format */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {/* PF */}
          <div className="p-3.5 rounded-xl bg-slate-800/70 border border-slate-700/60 flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300">{t.backtest.pf}</span>
            <span className="text-base font-extrabold text-cyan-300">
              {result.profitFactor}
            </span>
          </div>

          {/* 最大ドローダウン */}
          <div className="p-3.5 rounded-xl bg-slate-800/70 border border-slate-700/60 flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300">
              {t.backtest.maxDrawdown}
            </span>
            <span className="text-base font-extrabold text-cyan-300">
              {result.maxDrawdownPercent}%
            </span>
          </div>

          {/* 希望取引回数 */}
          <div className="p-3.5 rounded-xl bg-slate-800/70 border border-slate-700/60 flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300">
              {t.backtest.targetFreq}
            </span>
            <span className="text-base font-extrabold text-slate-100">
              {getFrequencyLabel(config.frequency)}
            </span>
          </div>

          {/* シミュレーション期間 */}
          <div className="p-3.5 rounded-xl bg-slate-800/70 border border-slate-700/60 flex items-center justify-between">
            <div>
              <div className="text-xs font-semibold text-slate-300">
                {t.backtest.simPeriod}
              </div>
              <div className="text-[10px] text-amber-400">{t.backtest.simPeriodNote}</div>
            </div>
            <span className="text-base font-extrabold text-slate-100">{t.backtest.simPeriodValue}</span>
          </div>

          {/* 基準資金 */}
          <div className="p-3.5 rounded-xl bg-slate-800/70 border border-slate-700/60 flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300">{t.backtest.baseCapital}</span>
            <span className="text-base font-extrabold text-slate-100">
              {isEn
                ? `¥${(result.baseCapital || 1000000).toLocaleString('en-US')} JPY`
                : `${(result.baseCapital || 1000000).toLocaleString('ja-JP')}円`}
            </span>
          </div>

          {/* 参考シミュレーション利益額 (金額表示・利益率は非表示) */}
          <div className="p-3.5 rounded-xl bg-cyan-950/60 border border-cyan-500/50 flex items-center justify-between">
            <div>
              <div className="text-xs font-bold text-cyan-200">
                {t.backtest.simProfit}
              </div>
              <div className="text-[10px] text-cyan-400">{t.backtest.simProfitNote}</div>
            </div>
            <span className="text-lg font-black text-emerald-400">
              {formatCurrency(result.totalNetProfit)}
            </span>
          </div>
        </div>

        {/* Notice line */}
        <div className="mt-3 pt-3 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
          <span>
            {t.backtest.profitNotice}
          </span>
          <span className="hidden sm:inline text-slate-400">
            {isEn
              ? `Total Trades: ${result.totalTrades} (Win Rate: ${result.winRate}%)`
              : `総取引数: ${result.totalTrades}回 (勝率: ${result.winRate}%)`}
          </span>
        </div>
      </div>

      {/* 2.5. 最小ロット (Minimum Lot) 検証カード */}
      <div
        id="dashboard-minimum-lot-card"
        className="rounded-xl bg-slate-900/90 border border-slate-700/80 p-4 shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
      >
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 mt-0.5">
            <Scale className="w-4 h-4" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-200">{t.backtest.minLotLabel}</span>
              <span className="text-sm font-black text-cyan-300">
                {result.minimumLot || 0.01} lot
              </span>
              <span className="text-[10px] text-slate-400 bg-slate-800 border border-slate-700 px-1.5 py-0.2 rounded">
                {t.backtest.minLotTag}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
              {t.backtest.minLotDesc}
            </p>
            <p className="text-[11px] text-slate-400">
              {t.backtest.minLotNote}
            </p>
          </div>
        </div>

        {onOpenUpgradeModal && (
          <button
            type="button"
            id="btn-upgrade-lot"
            onClick={() => onOpenUpgradeModal('LOT')}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 border border-slate-700 text-cyan-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shrink-0 self-stretch sm:self-auto justify-center"
          >
            <Lock className="w-3 h-3 text-amber-300" />
            <span>{t.backtest.lotUpgradeBtn}</span>
          </button>
        )}
      </div>

      {/* 2.6. 最大ポジション数 (Max Positions) カード */}
      <div
        id="dashboard-max-positions-card"
        className="rounded-xl bg-slate-900/90 border border-slate-700/80 p-4 shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
      >
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0 mt-0.5">
            <Layers className="w-4 h-4" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-200">
                {isEn ? 'Max Positions (Risk Constraint)' : '最大ポジション数 (リスク制約)'}
              </span>
              <span className="text-sm font-black text-cyan-300">
                {config.maxPositions === 'LE_5'
                  ? '<= 5'
                  : config.maxPositions === 'LE_10'
                  ? '<= 10'
                  : config.maxPositions === 'LE_20'
                  ? '<= 20'
                  : config.maxPositions === 'GE_20'
                  ? '20+'
                  : config.maxPositions === 'AUTO'
                  ? (isEn ? 'Auto' : 'お任せ')
                  : (isEn ? '1 Position' : '1個')}
              </span>
              <span className="text-[10px] text-slate-400 bg-slate-800 border border-slate-700 px-1.5 py-0.2 rounded">
                {isEn ? 'Free Edition Fixed (Single Position)' : '無料版固定・単一ポジション'}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed max-w-2xl">
              {isEn
                ? 'For risk management and safety, the Free Edition is strictly locked to 1 position only. Upgrading to Pro enables configurable positions: <=5, <=10, <=20, 20+, or Auto.'
                : '無料版は安全重視のため最大保有ポジション数を「1個」に厳格制限しています。上位版（Auto EA Studio Pro）では「5以下」「10以下」「20以下」「20～」「お任せ」から自由に設定可能です。'}
            </p>
            <p className="text-[11px] text-slate-400">
              {isEn
                ? '※ Enables advanced multi-tier grid, pyramiding, and trend-scaling.'
                : '※ ナンピン・グリッド・多層ピラミッディング・ゾーン分割エントリー等に対応します。'}
            </p>
          </div>
        </div>

        {onOpenUpgradeModal && (
          <button
            type="button"
            id="btn-upgrade-positions"
            onClick={() => onOpenUpgradeModal('MAX_POSITIONS')}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 border border-slate-700 text-cyan-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shrink-0 self-stretch sm:self-auto justify-center"
          >
            <Lock className="w-3 h-3 text-amber-300" />
            <span>{isEn ? 'Unlock Multiple Positions (Pro)' : '複数ポジション設定を開放 (Pro)'}</span>
          </button>
        )}
      </div>

      {/* 2.8. EA評価指標 (内蔵モデルによる簡易評価・判定の目安) */}
      <div
        id="dashboard-ea-evaluation-metrics"
        className="rounded-xl bg-slate-900/80 border border-slate-800 p-5 space-y-4"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-blue-500/20 text-blue-400 flex items-center justify-center">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                {t.backtest.metricsTitle}
                <span className="text-[10px] font-semibold text-cyan-300 bg-cyan-950/80 border border-cyan-700/60 px-2 py-0.5 rounded">
                  {t.backtest.metricsTag}
                </span>
              </h4>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-400">
              {t.backtest.metricsSubTitle}
            </span>
            {onOpenUpgradeModal && (
              <button
                type="button"
                id="btn-upgrade-curve-fit"
                onClick={() => onOpenUpgradeModal('CURVE_FIT')}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
              >
                {t.backtest.curveFitUpgradeHint}
              </button>
            )}
          </div>
        </div>

        {/* Evaluation Metrics Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* 1. 期待利得 */}
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.expectedPayoff}</div>
            <div className="text-base font-bold text-emerald-400 mt-1">
              +{isEn ? '¥' : ''}{(result.evaluationMetrics?.expectedPayoff || Math.round(result.totalNetProfit / Math.max(1, result.totalTrades))).toLocaleString()}{isEn ? ' JPY' : '円'}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.expectedPayoffNote}
            </div>
          </div>

          {/* 2. 損益比 (ペイオフレシオ) */}
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.profitLossRatio}</div>
            <div className="text-base font-bold text-cyan-300 mt-1">
              1 : {result.evaluationMetrics?.profitLossRatio || result.riskRewardRatio}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.profitLossRatioNote}
            </div>
          </div>

          {/* 3. 最大連勝数 */}
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.maxConsecutiveWins}</div>
            <div className="text-base font-bold text-white mt-1">
              {result.evaluationMetrics?.maxConsecutiveWins || 3} {isEn ? 'Wins' : '連勝'}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.maxConsecutiveWinsNote}
            </div>
          </div>

          {/* 4. 最大連敗数 */}
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.maxConsecutiveLosses}</div>
            <div className="text-base font-bold text-amber-300 mt-1">
              {result.evaluationMetrics?.maxConsecutiveLosses || 2} {isEn ? 'Losses' : '連敗'}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.maxConsecutiveLossesNote}
            </div>
          </div>

          {/* 5. 推定週間取引頻度 */}
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.estTradesPerWeek}</div>
            <div className="text-base font-bold text-cyan-300 mt-1">
              {isEn ? `~${result.tradesPerWeek} / wk` : `約 ${result.tradesPerWeek} 回/週`}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.estTradesPerWeekNote}
            </div>
          </div>

          {/* 6. リカバリーファクター */}
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.recoveryFactor}</div>
            <div className="text-base font-bold text-cyan-300 mt-1">
              {result.evaluationMetrics?.recoveryFactor || Number((result.totalNetProfit / Math.max(1, result.maxDrawdownAmount)).toFixed(2))}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.recoveryFactorNote}
            </div>
          </div>
        </div>

        {/* Disclaimer Note according to user instructions */}
        <div className="p-3 rounded-lg bg-slate-950/60 border border-slate-800 text-[11px] text-slate-400 leading-relaxed flex items-start gap-2">
          <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-slate-300">
              {t.backtest.disclaimerTitle}
            </span>{' '}
            {t.backtest.disclaimerText}
          </div>
        </div>
      </div>

      {/* 3. EA評価指標の下に直接配置: 詳細サマリー、資産曲線チャート、取引履歴ログ */}
      <div className="space-y-6 pt-2">
        {/* 詳細メトリクス 4カード */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.winRateTrades}</div>
            <div className="text-base font-bold text-white mt-1">
              {result.winRate}%
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {isEn
                ? `${result.winningTrades}W / ${result.losingTrades}L`
                : `${result.winningTrades}勝 ${result.losingTrades}敗`}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.weeklyTrades}</div>
            <div className="text-base font-bold text-cyan-300 mt-1">
              {isEn ? `~${result.tradesPerWeek} / wk` : `約 ${result.tradesPerWeek} 回 / 週`}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.weeklyTradesNote}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.avgProfitLoss}</div>
            <div className="text-base font-bold text-white mt-1">
              {formatCurrency(result.averageProfit)} / {formatCurrency(-result.averageLoss)}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {isEn ? `Risk/Reward 1 : ${result.riskRewardRatio}` : `リスクリワード比 1 : ${result.riskRewardRatio}`}
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50">
            <div className="text-[11px] text-slate-400 font-medium">{t.backtest.sharpeRatio}</div>
            <div className="text-base font-bold text-cyan-300 mt-1">
              {result.sharpeRatio}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {t.backtest.sharpeRatioNote}
            </div>
          </div>
        </div>

        {/* 資産曲線 (残高推移チャート) */}
        <div id="section-equity-curve" className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 sm:p-5 overflow-hidden space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              <h4 className="text-xs font-bold text-slate-200">
                {t.backtest.chartBalance}
              </h4>
            </div>
            <span className="text-xs font-semibold text-cyan-400 bg-cyan-950/60 border border-cyan-800/60 px-2.5 py-1 rounded-lg self-start sm:self-auto">
              {t.backtest.chartFinal}: {isEn ? `¥${result.finalBalance.toLocaleString('en-US')} JPY` : `${result.finalBalance.toLocaleString('ja-JP')}円`}
            </span>
          </div>

          <div className="w-full overflow-x-auto">
            <svg
              viewBox={`0 0 ${chartWidth} ${chartHeight}`}
              className="w-full h-48 sm:h-56 select-none"
            >
              <defs>
                <linearGradient id="freeEquityGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.35" />
                  <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Grid Lines */}
              {[0, 0.25, 0.5, 0.75, 1].map((ratio, i) => {
                const y =
                  chartHeight -
                  padding.bottom -
                  ratio * (chartHeight - padding.top - padding.bottom);
                const val = Math.round(minBalance + ratio * (maxBalance - minBalance));
                return (
                  <g key={i}>
                    <line
                      x1={padding.left}
                      y1={y}
                      x2={chartWidth - padding.right}
                      y2={y}
                      stroke="#1e293b"
                      strokeDasharray="3,3"
                    />
                    <text
                      x={padding.left - 8}
                      y={y + 3}
                      fill="#64748b"
                      fontSize="9"
                      textAnchor="end"
                    >
                      {val.toLocaleString()}
                    </text>
                  </g>
                );
              })}

              {/* Area and Line */}
              <polygon points={areaString} fill="url(#freeEquityGradient)" />
              <polyline
                points={pointsString}
                fill="none"
                stroke="#06b6d4"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
        </div>

        {/* 取引履歴ログ */}
        <div id="section-trade-logs" className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 sm:p-5 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
            <h4 className="text-xs font-bold text-slate-200 flex items-center gap-2">
              <span>{isEn ? `Trade History Log (${result.trades.length} trades)` : `取引履歴ログ一覧 (全${result.trades.length}件)`}</span>
            </h4>

            {/* Filter Buttons */}
            <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
              {(['ALL', 'BUY', 'SELL', 'WINS', 'LOSSES'] as const).map((filter) => (
                <button
                  key={filter}
                  type="button"
                  onClick={() => setTradeFilter(filter)}
                  className={`px-2.5 py-1 rounded-lg transition cursor-pointer text-xs ${
                    tradeFilter === filter
                      ? 'bg-slate-800 text-cyan-300 font-bold border border-slate-700'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          <div className="max-h-72 overflow-y-auto rounded-xl border border-slate-800 bg-slate-950/40 text-xs">
            <table className="w-full text-left">
              <thead className="sticky top-0 bg-slate-900 text-slate-400 text-[10px] uppercase border-b border-slate-800">
                <tr>
                  <th className="p-2">#</th>
                  <th className="p-2">{t.backtest.colDateTime}</th>
                  <th className="p-2">{t.backtest.colType}</th>
                  <th className="p-2">Lot</th>
                  <th className="p-2">{t.backtest.colPips}</th>
                  <th className="p-2 text-right">{t.backtest.colAmount}</th>
                  <th className="p-2">{t.backtest.colReason}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-850">
                {filteredTrades.slice(0, 50).map((t) => (
                  <tr key={t.id} className="hover:bg-slate-850/50">
                    <td className="p-2 text-slate-500">{t.id}</td>
                    <td className="p-2 text-slate-400">{t.openTime}</td>
                    <td className="p-2">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          t.type === 'BUY'
                            ? 'bg-blue-950 text-blue-300'
                            : 'bg-amber-950 text-amber-300'
                        }`}
                      >
                        {t.type}
                      </span>
                    </td>
                    <td className="p-2 text-slate-300">{t.lots}</td>
                    <td
                      className={`p-2 font-medium ${
                        t.profitPips >= 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {t.profitPips > 0 ? `+${t.profitPips}` : t.profitPips}
                    </td>
                    <td
                      className={`p-2 text-right font-semibold ${
                        t.profitAmount >= 0 ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {formatCurrency(t.profitAmount)}
                    </td>
                    <td className="p-2 text-slate-400 text-[10px]">{t.reason}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

