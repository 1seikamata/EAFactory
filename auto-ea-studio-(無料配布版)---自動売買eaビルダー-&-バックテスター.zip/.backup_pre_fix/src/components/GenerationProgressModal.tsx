/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  Cpu,
  BarChart3,
  TrendingUp,
  AlertTriangle,
  Zap,
  Lock,
  ChevronRight,
  Activity,
  Layers,
  ArrowUpRight,
  Filter,
  Flame,
  Binary,
} from 'lucide-react';
import { BuyerConfig } from '../types';
import { useLanguage } from '../i18n/LanguageContext';
import { UpgradeTrigger } from './UpgradeModal';

interface GenerationProgressModalProps {
  isOpen: boolean;
  config: BuyerConfig;
  onComplete: () => void;
  onOpenUpgradeModal: (trigger?: UpgradeTrigger) => void;
}

// EA Candidate pattern for high-frequency testing
interface CandidateSample {
  id: number;
  name: string;
  params: string;
  points: number[];
  pf: number;
  maxDd: number;
  status: 'REJECTED' | 'DISCARDED' | 'OVERFITTED' | 'QUALIFIED' | 'ELITE';
  reason: string;
}

export const GenerationProgressModal: React.FC<GenerationProgressModalProps> = ({
  isOpen,
  config,
  onComplete,
  onOpenUpgradeModal,
}) => {
  const { language, t } = useLanguage();
  const isEn = language === 'en';

  // Overall Generation Progress
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [progressPercent, setProgressPercent] = useState(0);
  const [barsProcessed, setBarsProcessed] = useState(0);
  const [ticksProcessed, setTicksProcessed] = useState(0);
  const [activeStageIndex, setActiveStageIndex] = useState(0);

  // Massive Screening Counters (Simulating tens of thousands of EAs)
  const [testedCandidatesCount, setTestedCandidatesCount] = useState(148);
  const [rejectedCount, setRejectedCount] = useState(145);
  const [qualifiedCount, setQualifiedCount] = useState(1);
  const [currentGen, setCurrentGen] = useState(1);
  const [fitnessScore, setFitnessScore] = useState('0.46');
  const [screenSpeed, setScreenSpeed] = useState(185); // candidates per second

  // High-Frequency Scanner: Flashing candidate waveform (updates several times per second)
  const [currentCandidate, setCurrentCandidate] = useState<CandidateSample>({
    id: 1042,
    name: 'EA-EURUSD-M15-GEN01-042',
    params: 'TP:18p SL:25p RSI:65/35 ATR:1.5x',
    points: [100, 104, 102, 107, 98, 92, 88, 85, 79],
    pf: 0.82,
    maxDd: 21.4,
    status: 'REJECTED',
    reason: 'プロフィットファクター基準未達 (PF < 1.30)',
  });

  // Champion / Elite Equity Curve (The best model that evolves over generations)
  const [championPoints, setChampionPoints] = useState<number[]>([
    1000000, 1008000, 1012000, 1009000, 1024000, 1019000, 1035000, 1042000,
  ]);

  // Genetic audit logs
  const [auditLog, setAuditLog] = useState<string[]>([]);

  const totalBars = 2880;
  const totalTicks = 128450;
  const targetCandidatesMax = 48200;

  // Stages definition
  const stages = useMemo(
    () => [
      { id: 1, title: '初期個体群 12,000種 全自動スクリーニング' },
      { id: 2, title: '遺伝的交叉＆変異フィルタ（粗悪ロジック大量棄却）' },
      { id: 3, title: '過剰最適化（カーブフィッティング）耐性検査' },
      { id: 4, title: '最優秀エリート個体 確定＆MQL構造体コンパイル' },
    ],
    []
  );

  const steps = useMemo(
    () => [
      {
        title: '全自動パラメータ空間走査（毎秒180通り超の並行評価）',
        desc: '移動平均・RSI・ATR・ボリンジャー等のパラメータ組み合わせを総当たり検査',
        icon: Binary,
      },
      {
        title: 'ドローダウン耐性＆ナンピン・マーチン不使用監査',
        desc: '最大ドローダウン20%超や破綻リスクの高いモデルを即時スクラップ＆ビルド',
        icon: AlertTriangle,
      },
      {
        title: 'スプレッド拡大＆スリッページ負荷ストレステスト',
        desc: '不利約定環境下での利益耐性とスプレッド耐性をシミュレーション走査',
        icon: Activity,
      },
      {
        title: 'ウォークフォワード検証＆アウトオブサンプル検定',
        desc: '未知の相場期間に適用し、カーブフィッティング（過剰適合）を厳重排除',
        icon: BarChart3,
      },
      {
        title: '最優秀ロジック確定＆MT4/MT5配布パッケージ生成',
        desc: '全40,000超の候補から選び抜かれた単一の堅牢パラメータをコード出力',
        icon: ShieldCheck,
      },
    ],
    []
  );

  // Helper to generate a random discarded or qualified candidate waveform
  const generateRandomCandidate = (candId: number, gen: number): CandidateSample => {
    const indicators = ['RSI+ATR', 'EMA-Cross', 'BB-Reversal', 'MACD-Div', 'Keltner-Break', 'PriceAction-Engulf'];
    const ind = indicators[Math.floor(Math.random() * indicators.length)];
    const tp = Math.floor(Math.random() * 35 + 12);
    const sl = Math.floor(Math.random() * 30 + 10);
    const mult = (Math.random() * 1.5 + 1.1).toFixed(1);

    const typeRoll = Math.random();
    let status: CandidateSample['status'] = 'REJECTED';
    let reason = 'PF基準未達 (PF < 1.30)';
    let pf = +(Math.random() * 0.5 + 0.7).toFixed(2);
    let maxDd = +(Math.random() * 22 + 14).toFixed(1);

    // Generate 12-16 points waveform
    const pts: number[] = [100];
    let cur = 100;

    if (typeRoll < 0.45) {
      // Dump / Drawdown reject
      status = 'REJECTED';
      reason = `最大ドローダウン超過 (DD: -${maxDd}%)`;
      for (let i = 0; i < 12; i++) {
        cur += Math.random() * 6 - (i > 5 ? 7 : 3);
        pts.push(Math.max(50, Math.round(cur)));
      }
    } else if (typeRoll < 0.8) {
      // Overfitted (initial looks high, then crashes)
      status = 'OVERFITTED';
      reason = 'アウトオブサンプル検定 破綻検知 (過剰適合)';
      pf = 1.05;
      for (let i = 0; i < 12; i++) {
        cur += i < 7 ? Math.random() * 8 + 2 : -(Math.random() * 10 + 4);
        pts.push(Math.max(60, Math.round(cur)));
      }
    } else if (typeRoll < 0.96) {
      // Discarded due to low trade count / stagnant
      status = 'DISCARDED';
      reason = '取引頻度不足 (統計的優位性欠如)';
      pf = 1.12;
      for (let i = 0; i < 12; i++) {
        cur += (Math.random() - 0.48) * 4;
        pts.push(Math.round(cur));
      }
    } else {
      // Rare qualified candidate!
      status = 'QUALIFIED';
      reason = '第' + gen + '世代 優秀候補として保持 (合格)';
      pf = +(Math.random() * 0.35 + 1.45).toFixed(2);
      maxDd = +(Math.random() * 5 + 6).toFixed(1);
      for (let i = 0; i < 12; i++) {
        cur += Math.random() * 7 - 1.5;
        pts.push(Math.round(cur));
      }
    }

    return {
      id: candId,
      name: `EA-${config.pair || 'EURUSD'}-GEN0${gen}-${candId.toString().padStart(5, '0')}`,
      params: `TP:${tp}p SL:${sl}p ${ind} ATR:${mult}x`,
      points: pts,
      pf,
      maxDd,
      status,
      reason,
    };
  };

  // Main Progression Timer
  // Total duration: around 3 to 4 minutes (approx 210 seconds = 210,000ms).
  // Step interval: 110ms. Total steps: ~1910 steps.
  // We do NOT disclose completion time to the user.
  useEffect(() => {
    if (!isOpen) {
      setCurrentStepIndex(0);
      setProgressPercent(0);
      setBarsProcessed(0);
      setTicksProcessed(0);
      setActiveStageIndex(0);
      setTestedCandidatesCount(148);
      setRejectedCount(145);
      setQualifiedCount(1);
      setCurrentGen(1);
      setFitnessScore('0.46');
      setAuditLog([]);
      return;
    }

    let progress = 0;
    let testedCount = 148;
    let rejCount = 145;
    let qualCount = 1;
    let gen = 1;

    // High frequency flashing candidate interval (1秒間に約4〜5回切り替わる)
    const flashInterval = setInterval(() => {
      testedCount += Math.floor(Math.random() * 12 + 6);
      const newCand = generateRandomCandidate(testedCount, gen);
      setCurrentCandidate(newCand);

      if (newCand.status === 'QUALIFIED') {
        qualCount += 1;
        setQualifiedCount(qualCount);
        // Evolve champion points slightly
        setChampionPoints((prev) => {
          const last = prev[prev.length - 1];
          const gain = Math.floor(Math.random() * 12000 + 4000);
          return [...prev, last + gain].slice(-45);
        });
      } else {
        rejCount += Math.floor(Math.random() * 8 + 5);
        setRejectedCount(rejCount);
      }
      setTestedCandidatesCount(testedCount);

      // Fluctuate screening speed slightly for organic realism
      setScreenSpeed(Math.floor(175 + Math.sin(progress) * 35 + Math.random() * 20));
    }, 220);

    // Deep deliberate progress interval (~3.5 minutes total)
    // 100% / 1910 steps ≈ 0.0523% per 110ms
    const stepIncrement = 0.0523;

    const progressInterval = setInterval(() => {
      progress += stepIncrement;
      if (progress >= 100) progress = 100;

      const roundedPct = Math.min(100, Math.round(progress));
      setProgressPercent(roundedPct);

      // Bars and ticks
      setBarsProcessed(Math.min(totalBars, Math.round((progress / 100) * totalBars)));
      setTicksProcessed(Math.min(totalTicks, Math.round((progress / 100) * totalTicks)));

      // Generation & Stages
      if (progress < 25) {
        setActiveStageIndex(0);
        setCurrentStepIndex(0);
        gen = 1;
        setCurrentGen(1);
        setFitnessScore((0.45 + (progress / 25) * 0.35).toFixed(2));
      } else if (progress < 50) {
        setActiveStageIndex(1);
        setCurrentStepIndex(1);
        gen = 3;
        setCurrentGen(3);
        setFitnessScore((0.8 + ((progress - 25) / 25) * 0.3).toFixed(2));
      } else if (progress < 75) {
        setActiveStageIndex(2);
        setCurrentStepIndex(2);
        gen = 5;
        setCurrentGen(5);
        setFitnessScore((1.1 + ((progress - 50) / 25) * 0.25).toFixed(2));
      } else if (progress < 95) {
        setActiveStageIndex(3);
        setCurrentStepIndex(3);
        gen = 7;
        setCurrentGen(7);
        setFitnessScore((1.35 + ((progress - 75) / 20) * 0.18).toFixed(2));
      } else {
        setActiveStageIndex(3);
        setCurrentStepIndex(4);
        gen = 8;
        setCurrentGen(8);
        setFitnessScore('1.56');
      }

      // Add occasional meaningful audit log entry
      if (Math.random() < 0.035) {
        const logTemplates = [
          `[走査] パラメータ群 #${testedCount.toLocaleString()} 検査: RSI過度シグナルにより棄却`,
          `[淘汰] 第${gen}世代 交叉実行: 破綻リスクモデル 420件 をメモリから一括破棄`,
          `[生存] 候補 #${testedCount.toLocaleString()} がドローダウン<10% 基準を突破`,
          `[検定] スリッページ負荷テスト: 0.8pips遅延でもプラス収支を維持する遺伝子を保存`,
          `[変異] ボラティリティ適応型ATR乗数ロジックを次世代個体群へ注入中...`,
        ];
        const msg = logTemplates[Math.floor(Math.random() * logTemplates.length)];
        setAuditLog((prev) => [msg, ...prev.slice(0, 4)]);
      }

      if (progress >= 100) {
        clearInterval(progressInterval);
        clearInterval(flashInterval);
        setTimeout(() => {
          onComplete();
        }, 800);
      }
    }, 110);

    return () => {
      clearInterval(progressInterval);
      clearInterval(flashInterval);
    };
  }, [isOpen, onComplete, config.pair]);

  if (!isOpen) return null;

  // Render SVG Sparkline for candidate waveform
  const candSvgWidth = 320;
  const candSvgHeight = 90;
  const candMin = Math.min(...currentCandidate.points);
  const candMax = Math.max(...currentCandidate.points);
  const candRange = candMax - candMin || 1;
  const candPath = currentCandidate.points
    .map((val, idx) => {
      const x = (idx / (currentCandidate.points.length - 1)) * candSvgWidth;
      const y = candSvgHeight - ((val - candMin) / candRange) * (candSvgHeight - 16) - 8;
      return `${x},${y}`;
    })
    .join(' ');

  // Render SVG Sparkline for champion elite curve
  const champSvgWidth = 480;
  const champSvgHeight = 110;
  const champMin = Math.min(...championPoints);
  const champMax = Math.max(...championPoints);
  const champRange = champMax - champMin || 1;
  const champPath = championPoints
    .map((val, idx) => {
      const x = (idx / (championPoints.length - 1)) * champSvgWidth;
      const y = champSvgHeight - ((val - champMin) / champRange) * (champSvgHeight - 20) - 10;
      return `${x},${y}`;
    })
    .join(' ');

  return (
    <div
      id="generation-progress-modal"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-4 overflow-y-auto animate-fade-in"
    >
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-auto">
        {/* Header with High-Tech Status */}
        <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
              <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                <span>高密度遺伝的アルゴリズム・何万通り全自動探索中</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                  GENETIC ENGINE v4.8
                </span>
              </h3>
            </div>
            <p className="text-xs text-slate-400">
              粗悪・破綻リスクのあるロジックを1秒間に何枚も即時スクラップ＆ビルドし、生き残った堅牢モデルのみを選抜しています
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
            <button
              id="generation-modal-pro-speed-btn"
              type="button"
              onClick={() => onOpenUpgradeModal('SPEED')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 text-xs font-bold shadow-md shadow-amber-900/30 transition cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5 fill-slate-950" />
              <span>上位版（Proクラウド分散クラスタ）案内</span>
            </button>
          </div>
        </div>

        {/* Global Progress Bar (No completion time disclosed) */}
        <div className="bg-slate-950/70 px-5 pt-3 pb-2.5 border-b border-slate-800/80">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs mb-1.5">
            <div className="flex items-center gap-3">
              <span className="text-cyan-400 font-bold font-mono">
                探索空間収束率: {progressPercent}%
              </span>
              <span className="text-slate-400 font-mono text-[11px] hidden sm:inline">
                第 {currentGen} 世代個体群走査中
              </span>
            </div>
            <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400">
              <span className="text-amber-300 font-semibold flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                {screenSpeed} モデル/秒
              </span>
              <span>•</span>
              <span>走査履歴: {barsProcessed.toLocaleString()} bars ({ticksProcessed.toLocaleString()} ticks)</span>
            </div>
          </div>
          <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-emerald-400 transition-all duration-150"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Main Content Area */}
        <div className="p-5 space-y-5">
          {/* Generation Stage Tracker */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
            {stages.map((stg, idx) => {
              const isPast = idx < activeStageIndex;
              const isCurrent = idx === activeStageIndex;
              return (
                <div
                  key={stg.id}
                  className={`p-2.5 rounded-xl border text-xs transition-all ${
                    isCurrent
                      ? 'bg-cyan-950/40 border-cyan-500/60 text-white shadow-sm shadow-cyan-900/20 ring-1 ring-cyan-500/30'
                      : isPast
                      ? 'bg-slate-800/50 border-slate-700/60 text-slate-400'
                      : 'bg-slate-900/40 border-slate-800 text-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-mono uppercase font-bold text-cyan-400">
                      PHASE 0{stg.id}
                    </span>
                    {isPast ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    ) : isCurrent ? (
                      <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                    ) : null}
                  </div>
                  <div className="font-semibold text-[11px] leading-snug line-clamp-2">{stg.title}</div>
                </div>
              );
            })}
          </div>

          {/* TWO-COLUMN QUANT MONITOR */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* LEFT: 1秒間に何枚も検証される「超高速スクリーニング・オシロスコープ」 (5 Cols) */}
            <div className="lg:col-span-5 bg-slate-950 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between space-y-3 relative overflow-hidden">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-amber-400 animate-pulse" />
                  <span className="text-xs font-bold text-slate-200">
                    毎秒連続検証オシロスコープ
                  </span>
                </div>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                  REAL-TIME CANDIDATES
                </span>
              </div>

              {/* Candidate Info Badge */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-lg p-2.5 space-y-1.5">
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <span className="text-cyan-300 font-bold truncate max-w-[190px]">
                    {currentCandidate.name}
                  </span>
                  <span
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      currentCandidate.status === 'QUALIFIED'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                        : currentCandidate.status === 'OVERFITTED'
                        ? 'bg-purple-950 text-purple-300 border border-purple-800'
                        : 'bg-rose-950 text-rose-300 border border-rose-800'
                    }`}
                  >
                    {currentCandidate.status}
                  </span>
                </div>
                <div className="text-[10px] font-mono text-slate-400 truncate">
                  {currentCandidate.params}
                </div>
              </div>

              {/* Rapid Candidate Waveform Canvas */}
              <div className="bg-slate-950/90 border border-slate-850 rounded-lg p-2 relative overflow-hidden">
                <div className="text-[9px] font-mono text-slate-500 absolute top-1.5 left-2">
                  試行曲線プレビュー (瞬時評価中)
                </div>
                <svg viewBox={`0 0 ${candSvgWidth} ${candSvgHeight}`} className="w-full h-20 select-none">
                  {/* Zero Grid Line */}
                  <line
                    x1="0"
                    y1={candSvgHeight / 2}
                    x2={candSvgWidth}
                    y2={candSvgHeight / 2}
                    stroke="#1e293b"
                    strokeDasharray="2 2"
                  />
                  {/* High Frequency Waveform */}
                  <polyline
                    points={candPath}
                    fill="none"
                    stroke={
                      currentCandidate.status === 'QUALIFIED'
                        ? '#10b981'
                        : currentCandidate.status === 'OVERFITTED'
                        ? '#a855f7'
                        : '#f43f5e'
                    }
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between border-t border-slate-800/80 pt-1 font-mono">
                  <span>PF: <strong className={currentCandidate.pf >= 1.3 ? 'text-emerald-400' : 'text-slate-300'}>{currentCandidate.pf}</strong></span>
                  <span>最大DD: <strong className={currentCandidate.maxDd <= 15 ? 'text-emerald-400' : 'text-rose-400'}>{currentCandidate.maxDd}%</strong></span>
                  <span className="text-[9px] text-slate-500 truncate max-w-[130px]">{currentCandidate.reason}</span>
                </div>
              </div>

              {/* Real-time Tally Counters */}
              <div className="grid grid-cols-3 gap-2 text-center font-mono">
                <div className="p-2 rounded bg-slate-900/60 border border-slate-800">
                  <div className="text-[10px] text-slate-400">総検証ロジック数</div>
                  <div className="text-sm font-bold text-white">
                    {testedCandidatesCount.toLocaleString()}
                  </div>
                </div>
                <div className="p-2 rounded bg-rose-950/20 border border-rose-900/30">
                  <div className="text-[10px] text-rose-300">不適合・棄却</div>
                  <div className="text-sm font-bold text-rose-400">
                    {rejectedCount.toLocaleString()}
                  </div>
                </div>
                <div className="p-2 rounded bg-emerald-950/20 border border-emerald-900/30">
                  <div className="text-[10px] text-emerald-300">合格候補キープ</div>
                  <div className="text-sm font-bold text-emerald-400">
                    {qualifiedCount}
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT: 「第N世代 最優秀エリートモデル」の洗練プロセス (7 Cols) */}
            <div className="lg:col-span-7 bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col justify-between space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-bold text-slate-200">
                    選抜エリートEA 資産推移（世代進化モニター）
                  </span>
                </div>
                <div className="flex items-center gap-2 font-mono text-xs">
                  <span className="text-slate-400 text-[11px]">最優秀モデル適合度:</span>
                  <strong className="text-cyan-300 font-bold">{fitnessScore} / 1.60</strong>
                </div>
              </div>

              {/* Champion Sparkline Canvas */}
              <div className="w-full bg-slate-900/40 rounded-lg p-2.5 border border-slate-850 overflow-hidden">
                <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 mb-1">
                  <span>世代淘汰により収束した最適解カーブ</span>
                  <span className="text-emerald-400 font-semibold">★ CURRENT BEST</span>
                </div>
                <svg viewBox={`0 0 ${champSvgWidth} ${champSvgHeight}`} className="w-full h-24 select-none">
                  <defs>
                    <linearGradient id="champGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.25" />
                      <stop offset="100%" stopColor="#06b6d4" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  <line
                    x1="0"
                    y1={champSvgHeight / 2}
                    x2={champSvgWidth}
                    y2={champSvgHeight / 2}
                    stroke="#1e293b"
                    strokeDasharray="3 3"
                  />
                  <polyline
                    points={champPath}
                    fill="none"
                    stroke="#06b6d4"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>

              {/* Live Genetic Optimization Stream Log */}
              <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] font-mono space-y-1 text-slate-300">
                <div className="text-[10px] font-bold text-cyan-400 flex items-center justify-between">
                  <span>GENETIC DISCARD & EVOLUTION LOG</span>
                  <span className="text-slate-500 font-normal">AUTO SCRAP & BUILD</span>
                </div>
                {auditLog.length > 0 ? (
                  auditLog.slice(0, 3).map((log, idx) => (
                    <div key={idx} className="truncate text-slate-400 text-[10px]">
                      {log}
                    </div>
                  ))
                ) : (
                  <div className="text-slate-500 text-[10px]">
                    毎秒数百通りのパラメータ空間を走査中...
                  </div>
                )}
              </div>

              {/* Pro Cloud Comparison Banner */}
              <div
                onClick={() => onOpenUpgradeModal('SPEED')}
                className="p-2.5 rounded-lg bg-gradient-to-br from-slate-900 to-amber-950/30 border border-amber-900/40 cursor-pointer hover:border-amber-600 transition group flex items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-1 text-[11px] font-bold text-amber-300">
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    <span>上位版（Proクラウド分散クラスタ）：約30分の極限検証</span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    無料版はクライアント環境で順次検証中。上位版では専用サーバ群が30分〜数時間をかけ、全銘柄・全時間軸の超高密度全ティック検証を実施します。
                  </div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-amber-300 shrink-0 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition" />
              </div>
            </div>
          </div>

          {/* Step-by-Step Security Audit Progress */}
          <div className="space-y-1.5 pt-1">
            {steps.map((st, idx) => {
              const Icon = st.icon;
              const isFinished = idx < currentStepIndex;
              const isCurrent = idx === currentStepIndex;
              return (
                <div
                  key={st.title}
                  className={`p-2.5 rounded-xl border flex items-center justify-between gap-3 text-xs transition-colors ${
                    isCurrent
                      ? 'bg-slate-800/80 border-cyan-500/50 text-white'
                      : isFinished
                      ? 'bg-slate-900/40 border-slate-800/80 text-slate-400'
                      : 'bg-slate-950/30 border-slate-850 text-slate-600'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div
                      className={`p-1.5 rounded-lg shrink-0 ${
                        isCurrent
                          ? 'bg-cyan-500/20 text-cyan-300'
                          : isFinished
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : 'bg-slate-800 text-slate-600'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <div className="min-w-0">
                      <div className="font-semibold text-[11px] truncate">{st.title}</div>
                      <div className="text-[10px] text-slate-500 truncate">{st.desc}</div>
                    </div>
                  </div>

                  <div className="shrink-0 font-mono text-[10px]">
                    {isFinished ? (
                      <span className="text-emerald-400 font-bold">COMPLETED</span>
                    ) : isCurrent ? (
                      <span className="text-cyan-400 font-bold animate-pulse">EVALUATING...</span>
                    ) : (
                      <span className="text-slate-600">QUEUED</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer info & Disclaimer (Completion time NOT disclosed) */}
        <div className="bg-slate-950 px-5 py-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-2 text-[10px] text-slate-500">
          <div>
            本結果は過去データを使用したシミュレーションであり、将来の利益を保証するものではありません。
          </div>
          <button
            id="generation-modal-skip-btn"
            type="button"
            onClick={onComplete}
            className="text-cyan-400 hover:text-cyan-300 underline font-medium cursor-pointer shrink-0"
          >
            検証完了へスキップ
          </button>
        </div>
      </div>
    </div>
  );
};
