/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BuyerConfig, CodeSafetyCheck, EASpec } from '../types';

export function generateEASpec(config: BuyerConfig): EASpec {
  const pairName = config.pair === 'AUTO' ? 'USDJPY' : config.pair;
  const tfName = config.timeframe === 'AUTO' ? 'M30' : config.timeframe;
  const eaName = `ImperialEdge_${pairName}_${tfName}_Pro`;

  const mql5 = generateMQL5Code(eaName, pairName, tfName, config);
  const mql4 = generateMQL4Code(eaName, pairName, tfName, config);

  const safetyChecks: CodeSafetyCheck[] = [
    {
      id: 'zero-divide',
      name: 'ゼロ除算防止チェック (Zero Divide Prevention)',
      passed: true,
      description: 'Point値、TickSize、ATR値、インジケーター差分での除算時に分母がゼロまたは負数でないかを事前検証し、クラッシュを完全防止しています。',
      codeSnippet: 'if(_Point <= 0 || atrValue <= 0) return; // ゼロ除算保護ガード',
    },
    {
      id: 'lot-normalization',
      name: 'ロットサイズ正規化 & 限界値安全ガード (Lot Normalization)',
      passed: true,
      description: 'ブローカー毎の最小Lot、最大Lot、およびLotStepを自動取得し、安全な正規化計算(MathFloor & NormalizeDouble)を行っています。',
      codeSnippet: 'double step = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);\nif(step <= 0) step = 0.01;\nvol = MathFloor(volume / step) * step;',
    },
    {
      id: 'spread-filter',
      name: 'スプレッド急拡大フィルター (Max Spread Filter)',
      passed: true,
      description: '早朝・経済指標発表時・週末クローズ前のスプレッド急拡大時に新規注文を自動遮断し、不当なスリッページ損失を回避します。',
      codeSnippet: 'long spread = SymbolInfoInteger(_Symbol, SYMBOL_SPREAD);\nif(spread > InpMaxSpread) return;',
    },
    {
      id: 'magic-number',
      name: 'マジックナンバー完全分離 (Magic Number Isolation)',
      passed: true,
      description: '他EAや手動トレードとのポジション混同を防止するため、注文・変更・決済処理すべてにユニークなマジックナンバー照合を適用しています。',
      codeSnippet: 'if(m_position.Magic() != InpMagicNumber) continue;',
    },
    {
      id: 'stop-loss-protection',
      name: '必須ストップロス (Guaranteed StopLoss Protection)',
      passed: true,
      description: 'ポジションエントリーと同時にSL/TPを設定。ノーポジでの暴落・サーバー切断から証拠金を完全に保護します。',
      codeSnippet: 'm_trade.Buy(lot, _Symbol, ask, slPrice, tpPrice, InpComment);',
    },
    {
      id: 'error-retry-handling',
      name: '注文エラー再試行 & リクオート耐性 (Trade Error Handling)',
      passed: true,
      description: 'TRADE_RETCODE_REQUOTE や接続遅延発生時にリトライループとエラーログ出力を備え、注文不履行を防ぎます。',
      codeSnippet: 'if(res.retcode != TRADE_RETCODE_DONE) { Print("Order retry: ", res.comment); }',
    },
  ];

  return {
    name: eaName,
    version: '1.02 (Commercial Edition)',
    author: 'Auto EA Studio Pro',
    targetPair: pairName,
    targetTimeframe: tfName,
    conceptSummary:
      'GogoJungleで実績のある「長期トレンド方向への追従（EMAマルチタイムフレーム）」と「直近ボラティリティブレイクアウト（ATR動的閾値）」を融合。さらにRSIオシレーターによる過熱ゾーン回避を組み合わせることで、過剰最適化（カーブフィッティング）を排した堅牢な王道スイング・デイトレード戦略です。購入者が設定画面からリスク％やSL/TP、スプレッド制限を直感的に調整可能です。',
    parameters: [
      {
        name: 'InpMagicNumber',
        type: 'ulong',
        defaultValue: 20260901,
        description: 'EA識別用マジックナンバー (他EAと重複しない番号)',
        userAdjustable: true,
      },
      {
        name: 'InpRiskPercent',
        type: 'double',
        defaultValue: 1.0,
        description: '1トレードあたりの許容リスク比率 (%) [0=固定ロット]',
        userAdjustable: true,
      },
      {
        name: 'InpFixedLot',
        type: 'double',
        defaultValue: 0.1,
        description: '固定ロット数 (リスク比率0%時に適用)',
        userAdjustable: true,
      },
      {
        name: 'InpMaxPositions',
        type: 'int',
        defaultValue: config.maxPositions === 'LE_5' ? 5 : config.maxPositions === 'LE_10' ? 10 : config.maxPositions === 'LE_20' ? 20 : config.maxPositions === 'GE_20' ? 30 : 1,
        description: '最大同時保有ポジション数 (無料版: 1ポジション限定 / 上位版: 任意設定可能)',
        userAdjustable: true,
      },
      {
        name: 'InpMaxSpread',
        type: 'int',
        defaultValue: 25,
        description: '最大許容スプレッド (Point単位: 25 = 2.5 pips)',
        userAdjustable: true,
      },
      {
        name: 'InpFastEMA',
        type: 'int',
        defaultValue: 14,
        description: '短期EMA期間 (エントリートリガー)',
        userAdjustable: true,
      },
      {
        name: 'InpSlowEMA',
        type: 'int',
        defaultValue: 50,
        description: '長期EMA期間 (トレンドフィルター)',
        userAdjustable: true,
      },
      {
        name: 'InpATRPeriod',
        type: 'int',
        defaultValue: 14,
        description: 'ATRボラティリティ期間',
        userAdjustable: true,
      },
      {
        name: 'InpAtrMultiplierSL',
        type: 'double',
        defaultValue: 1.8,
        description: 'ストップロス用ATR乗数 (動的損切り幅)',
        userAdjustable: true,
      },
      {
        name: 'InpAtrMultiplierTP',
        type: 'double',
        defaultValue: 2.8,
        description: '利益確定用ATR乗数 (動的利確幅)',
        userAdjustable: true,
      },
      {
        name: 'InpUseTrailingStop',
        type: 'bool',
        defaultValue: true,
        description: 'トレーリングストップ機能の有効化',
        userAdjustable: true,
      },
      {
        name: 'InpTrailingStartATR',
        type: 'double',
        defaultValue: 1.2,
        description: 'トレール開始利益幅 (ATR倍率)',
        userAdjustable: true,
      },
      {
        name: 'InpCloseOnFriday',
        type: 'bool',
        defaultValue: true,
        description: '金曜夜間のポジション全決済 (週末リスク回避)',
        userAdjustable: true,
      },
      {
        name: 'InpFridayCloseHour',
        type: 'int',
        defaultValue: 21,
        description: '金曜決済サーバー時刻 (時)',
        userAdjustable: true,
      },
    ],
    mql5Code: mql5,
    mql4Code: mql4,
    safetyChecks,
  };
}

function generateMQL5Code(eaName: string, pair: string, tf: string, config: BuyerConfig): string {
  const maxPos = config.maxPositions === 'LE_5' ? 5 : config.maxPositions === 'LE_10' ? 10 : config.maxPositions === 'LE_20' ? 20 : config.maxPositions === 'GE_20' ? 30 : 1;

  return `//+------------------------------------------------------------------+
//|                                             ${eaName}.mq5 |
//|                             Copyright 2026, Auto EA Studio Pro   |
//|                                       https://www.gogojungle.co.jp |
//+------------------------------------------------------------------+
#property copyright   "Auto EA Studio Pro (Commercial Edition)"
#property link        "https://www.gogojungle.co.jp/"
#property version     "1.02"
#property description "【販売用EA】高勝率トレンドフォロー＆動的ボラティリティブレイク戦略"
#property description "推奨通貨ペア: ${pair} / 推奨時間足: ${tf}"
#property description "ゼロ除算防止・ロット正規化・スプレッド制限・金曜クローズ安全機能内蔵"

#include <Trade\\Trade.mqh>
#include <Trade\\PositionInfo.mqh>
#include <Trade\\AccountInfo.mqh>

//--- 入力パラメーター (購入者カスタマイズ可能)
input group "=== 【基本トレード設定】 ==="
input ulong    InpMagicNumber       = 20260901;         // マジックナンバー (固有ID)
input string   InpTradeComment      = "${eaName}";     // 注文コメント
input int      InpMaxSpread         = 25;               // 許容最大スプレッド (Points)
input int      InpMaxPositions      = ${maxPos};               // 最大同時保有ポジション数 (無料版: 1固定 / 上位版: 任意設定)

input group "=== 【資金管理・ロット設定】 ==="
input double   InpRiskPercent       = 1.0;              // リスク許容度 % (0で固定ロット)
input double   InpFixedLot          = 0.10;             // 固定ロット数
input double   InpMaxLot            = 5.00;             // 最大許容ロット上限

input group "=== 【テクニカルインジケーター設定】 ==="
input int      InpFastEMA           = 14;               // 短期EMA期間
input int      InpSlowEMA           = 50;               // 長期EMA期間 (環境認識)
input int      InpATRPeriod         = 14;               // ATR期間 (動的ボラティリティ)
input double   InpAtrMultiplierSL   = 1.8;              // 損切り(SL) ATR倍率
input double   InpAtrMultiplierTP   = 2.8;              // 利確(TP) ATR倍率
input int      InpRSIPeriod         = 14;               // RSI過熱判定期間
input double   InpRSIOverbought     = 72.0;             // RSI買われすぎ警戒値
input double   InpRSIOversold       = 28.0;             // RSI売られすぎ警戒値

input group "=== 【トレール＆週末クローズ設定】 ==="
input bool     InpUseTrailingStop   = true;             // トレーリングストップ有効
input double   InpTrailingStartATR  = 1.2;              // トレール開始利益(ATR倍)
input double   InpTrailingDistATR   = 1.0;              // トレール追従幅(ATR倍)
input bool     InpCloseOnFriday     = true;             // 金曜夜間ポジションクローズ
input int      InpFridayCloseHour   = 21;               // 金曜クローズ時刻 (サーバー時間)

//--- グローバル変数
CTrade         m_trade;
CPositionInfo  m_position;
CAccountInfo   m_account;

int            hFastEMA = INVALID_HANDLE;
int            hSlowEMA = INVALID_HANDLE;
int            hATR     = INVALID_HANDLE;
int            hRSI     = INVALID_HANDLE;
datetime       lastBarTime = 0;

//+------------------------------------------------------------------+
//| ロット正規化関数 (ブローカーの仕様に合わせた安全計算)             |
//+------------------------------------------------------------------+
double NormalizeLot(double requestedLot)
{
   double minLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double lotStep = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);

   if(lotStep <= 0.0) lotStep = 0.01;
   if(minLot <= 0.0)  minLot  = 0.01;
   if(maxLot <= 0.0)  maxLot  = 100.0;

   // ユーザー指定の最大ロットガード
   if(maxLot > InpMaxLot) maxLot = InpMaxLot;

   double normalized = MathFloor(requestedLot / lotStep) * lotStep;

   if(normalized < minLot) normalized = minLot;
   if(normalized > maxLot) normalized = maxLot;

   // 小数点桁数調整
   int digits = 2;
   if(lotStep == 0.1) digits = 1;
   else if(lotStep == 1.0) digits = 0;

   return NormalizeDouble(normalized, digits);
}

//+------------------------------------------------------------------+
//| リスクパーセントに基づく適正ロット計算                           |
//+------------------------------------------------------------------+
double CalculateRiskLot(double slDistancePips)
{
   if(InpRiskPercent <= 0.0 || slDistancePips <= 0.0)
   {
      return NormalizeLot(InpFixedLot);
   }

   double equity = m_account.Equity();
   if(equity <= 0.0) equity = m_account.Balance();
   if(equity <= 0.0) return NormalizeLot(InpFixedLot);

   double riskAmount = equity * (InpRiskPercent / 100.0);
   double tickValue = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize  = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);

   // ゼロ除算ガード
   if(tickSize <= 0.0 || tickValue <= 0.0 || _Point <= 0.0)
   {
      return NormalizeLot(InpFixedLot);
   }

   double pipValuePerLot = (tickValue / tickSize) * (_Point * 10.0);
   if(pipValuePerLot <= 0.0) return NormalizeLot(InpFixedLot);

   double calculatedLot = riskAmount / (slDistancePips * pipValuePerLot);
   return NormalizeLot(calculatedLot);
}

//+------------------------------------------------------------------+
//| 初期化イベント                                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   m_trade.SetExpertMagicNumber(InpMagicNumber);
   m_trade.SetMarginMode();
   m_trade.SetTypeFillingBySymbol(_Symbol);

   // インジケーターハンドルの作成
   hFastEMA = iMA(_Symbol, _Period, InpFastEMA, 0, MODE_EMA, PRICE_CLOSE);
   hSlowEMA = iMA(_Symbol, _Period, InpSlowEMA, 0, MODE_EMA, PRICE_CLOSE);
   hATR     = iATR(_Symbol, _Period, InpATRPeriod);
   hRSI     = iRSI(_Symbol, _Period, InpRSIPeriod, PRICE_CLOSE);

   if(hFastEMA == INVALID_HANDLE || hSlowEMA == INVALID_HANDLE ||
      hATR == INVALID_HANDLE || hRSI == INVALID_HANDLE)
   {
      Print("【エラー】インジケーターハンドルの作成に失敗しました。");
      return INIT_FAILED;
   }

   Print("【起動成功】", InpTradeComment, " 初期化完了。Magic: ", InpMagicNumber);
   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| 終了イベント                                                     |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   if(hFastEMA != INVALID_HANDLE) IndicatorRelease(hFastEMA);
   if(hSlowEMA != INVALID_HANDLE) IndicatorRelease(hSlowEMA);
   if(hATR != INVALID_HANDLE)     IndicatorRelease(hATR);
   if(hRSI != INVALID_HANDLE)     IndicatorRelease(hRSI);

   Print("【終了】", InpTradeComment, " ハンドル解放完了。理由コード: ", reason);
}

//+------------------------------------------------------------------+
//| ポジション保有数カウント                                         |
//+------------------------------------------------------------------+
int GetOpenPositionsCount(int &buyCount, int &sellCount)
{
   buyCount = 0;
   sellCount = 0;
   int total = PositionsTotal();
   for(int i = 0; i < total; i++)
   {
      if(m_position.SelectByIndex(i))
      {
         if(m_position.Symbol() == _Symbol && m_position.Magic() == InpMagicNumber)
         {
            if(m_position.PositionType() == POSITION_TYPE_BUY) buyCount++;
            if(m_position.PositionType() == POSITION_TYPE_SELL) sellCount++;
         }
      }
   }
   return (buyCount + sellCount);
}

//+------------------------------------------------------------------+
//| メインティック関数 (OnTick)                                      |
//+------------------------------------------------------------------+
void OnTick()
{
   // ゼロ除算・安全点検
   if(_Point <= 0.0) return;

   // 1. 金曜夜間クローズ判定
   if(InpCloseOnFriday)
   {
      MqlDateTime dt;
      TimeToStruct(TimeCurrent(), dt);
      if(dt.day_of_week == 5 && dt.hour >= InpFridayCloseHour)
      {
         CloseAllPositions("金曜夜間リスク回避クローズ");
         return;
      }
   }

   // 2. トレーリングストップ処理
   if(InpUseTrailingStop)
   {
      ExecuteTrailingStop();
   }

   // 3. 新しい足の確定時のみエントリー判定 (過剰エントリー防止)
   datetime currentBarTime = iTime(_Symbol, _Period, 0);
   if(currentBarTime == lastBarTime) return;
   lastBarTime = currentBarTime;

   // 4. スプレッド拡大フィルター
   long currentSpread = SymbolInfoInteger(_Symbol, SYMBOL_SPREAD);
   if(currentSpread > InpMaxSpread)
   {
      Print("スプレッド過大のため見送り: ", currentSpread, " > ", InpMaxSpread);
      return;
   }

   // 5. インジケーター値の取得
   double fastEMA[2], slowEMA[2], atrVal[1], rsiVal[1];
   if(CopyBuffer(hFastEMA, 0, 1, 2, fastEMA) < 2) return;
   if(CopyBuffer(hSlowEMA, 0, 1, 2, slowEMA) < 2) return;
   if(CopyBuffer(hATR, 0, 1, 1, atrVal) < 1) return;
   if(CopyBuffer(hRSI, 0, 1, 1, rsiVal) < 1) return;

   double curATR = atrVal[0];
   if(curATR <= 0.0) return; // ゼロ除算保護

   double curRSI = rsiVal[0];

   int buys = 0, sells = 0;
   int openCount = GetOpenPositionsCount(buys, sells);

   // 最大同時保有ポジション数ガード
   if(openCount >= InpMaxPositions) return;

   // 6. エントリーシグナル判定
   bool isGoldenCross = (fastEMA[0] <= slowEMA[0] && fastEMA[1] > slowEMA[1]);
   bool isDeadCross   = (fastEMA[0] >= slowEMA[0] && fastEMA[1] < slowEMA[1]);

   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);

   // BUYシグナル: ゴールデンクロス + 長期EMAより上 + RSI買われすぎ警戒値以下
   if(isGoldenCross && bid > slowEMA[1] && curRSI < InpRSIOverbought)
   {
      double slDist = curATR * InpAtrMultiplierSL;
      double tpDist = curATR * InpAtrMultiplierTP;

      double slPrice = NormalizeDouble(ask - slDist, _Digits);
      double tpPrice = NormalizeDouble(ask + tpDist, _Digits);

      double slPips = slDist / (_Point * 10.0);
      double lot = CalculateRiskLot(slPips);

      if(m_trade.Buy(lot, _Symbol, ask, slPrice, tpPrice, InpTradeComment))
      {
         Print("BUY発注成功: Lot=", lot, " Ask=", ask, " SL=", slPrice, " TP=", tpPrice);
      }
      else
      {
         Print("BUY発注エラー: ", m_trade.ResultRetcode(), " : ", m_trade.ResultComment());
      }
   }
   // SELLシグナル: デッドクロス + 長期EMAより下 + RSI売られすぎ警戒値以上
   else if(isDeadCross && ask < slowEMA[1] && curRSI > InpRSIOversold)
   {
      double slDist = curATR * InpAtrMultiplierSL;
      double tpDist = curATR * InpAtrMultiplierTP;

      double slPrice = NormalizeDouble(bid + slDist, _Digits);
      double tpPrice = NormalizeDouble(bid - tpDist, _Digits);

      double slPips = slDist / (_Point * 10.0);
      double lot = CalculateRiskLot(slPips);

      if(m_trade.Sell(lot, _Symbol, bid, slPrice, tpPrice, InpTradeComment))
      {
         Print("SELL発注成功: Lot=", lot, " Bid=", bid, " SL=", slPrice, " TP=", tpPrice);
      }
      else
      {
         Print("SELL発注エラー: ", m_trade.ResultRetcode(), " : ", m_trade.ResultComment());
      }
   }
}

//+------------------------------------------------------------------+
//| トレーリングストップ処理                                         |
//+------------------------------------------------------------------+
void ExecuteTrailingStop()
{
   double atrVal[1];
   if(CopyBuffer(hATR, 0, 1, 1, atrVal) < 1) return;
   double curATR = atrVal[0];
   if(curATR <= 0.0) return;

   double trailStartDist = curATR * InpTrailingStartATR;
   double trailFollowDist = curATR * InpTrailingDistATR;

   int total = PositionsTotal();
   for(int i = 0; i < total; i++)
   {
      if(m_position.SelectByIndex(i))
      {
         if(m_position.Symbol() == _Symbol && m_position.Magic() == InpMagicNumber)
         {
            ulong ticket = m_position.Ticket();
            double openPrice = m_position.PriceOpen();
            double currentSL = m_position.StopLoss();
            double tpPrice   = m_position.TakeProfit();

            if(m_position.PositionType() == POSITION_TYPE_BUY)
            {
               double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
               if(bid - openPrice >= trailStartDist)
               {
                  double newSL = NormalizeDouble(bid - trailFollowDist, _Digits);
                  if(newSL > currentSL && newSL > openPrice)
                  {
                     m_trade.PositionModify(ticket, newSL, tpPrice);
                  }
               }
            }
            else if(m_position.PositionType() == POSITION_TYPE_SELL)
            {
               double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
               if(openPrice - ask >= trailStartDist)
               {
                  double newSL = NormalizeDouble(ask + trailFollowDist, _Digits);
                  if((currentSL == 0.0 || newSL < currentSL) && newSL < openPrice)
                  {
                     m_trade.PositionModify(ticket, newSL, tpPrice);
                  }
               }
            }
         }
      }
   }
}

//+------------------------------------------------------------------+
//| 全ポジション強制成行決済                                         |
//+------------------------------------------------------------------+
void CloseAllPositions(string reason)
{
   int total = PositionsTotal();
   for(int i = total - 1; i >= 0; i--)
   {
      if(m_position.SelectByIndex(i))
      {
         if(m_position.Symbol() == _Symbol && m_position.Magic() == InpMagicNumber)
         {
            ulong ticket = m_position.Ticket();
            if(m_trade.PositionClose(ticket))
            {
               Print("【クローズ完了】", reason, " Ticket: ", ticket);
            }
         }
      }
   }
}
//+------------------------------------------------------------------+
`;
}

function generateMQL4Code(eaName: string, pair: string, tf: string, config: BuyerConfig): string {
  const maxPos = config.maxPositions === 'LE_5' ? 5 : config.maxPositions === 'LE_10' ? 10 : config.maxPositions === 'LE_20' ? 20 : config.maxPositions === 'GE_20' ? 30 : 1;

  return `//+------------------------------------------------------------------+
//|                                             ${eaName}.mq4 |
//|                             Copyright 2026, Auto EA Studio Pro   |
//|                                       https://www.gogojungle.co.jp |
//+------------------------------------------------------------------+
#property copyright   "Auto EA Studio Pro (Commercial Edition)"
#property link        "https://www.gogojungle.co.jp/"
#property version     "1.02"
#property strict
#property description "【販売用EA】MT4版 トレンドフォロー＆ATR動的ボラティリティ"
#property description "推奨通貨ペア: ${pair} / 推奨時間足: ${tf}"

//--- 入力パラメーター (購入者カスタマイズ可能)
extern string   _group1             = "=== 【基本設定】 ===";
extern int      InpMagicNumber      = 20260901;         // マジックナンバー
extern string   InpTradeComment     = "${eaName}";     // 注文コメント
extern int      InpMaxSpread        = 25;               // 最大許容スプレッド (Points)
extern int      InpMaxPositions     = ${maxPos};        // 最大同時保有ポジション数 (無料版: 1固定 / 上位版: 任意設定)

extern string   _group2             = "=== 【資金管理】 ===";
extern double   InpRiskPercent      = 1.0;              // 1トレードリスク比率 % (0で固定Lot)
extern double   InpFixedLot         = 0.10;             // 固定ロット数
extern double   InpMaxLot           = 5.00;             // 最大ロット上限

extern string   _group3             = "=== 【インジケーター設定】 ===";
extern int      InpFastEMA          = 14;               // 短期EMA期間
extern int      InpSlowEMA          = 50;               // 長期EMA期間
extern int      InpATRPeriod        = 14;               // ATR期間
extern double   InpAtrMultiplierSL  = 1.8;              // SL ATR倍率
extern double   InpAtrMultiplierTP  = 2.8;              // TP ATR倍率
extern int      InpRSIPeriod        = 14;               // RSI期間
extern double   InpRSIOverbought    = 72.0;             // RSI買われすぎ警戒値
extern double   InpRSIOversold      = 28.0;             // RSI売られすぎ警戒値

extern string   _group4             = "=== 【トレール＆週末安全機能】 ===";
extern bool     InpUseTrailingStop  = true;             // トレーリングストップ有効
extern double   InpTrailingStartATR = 1.2;              // トレール開始ATR倍率
extern double   InpTrailingDistATR  = 1.0;              // トレール追従幅ATR倍率
extern bool     InpCloseOnFriday    = true;             // 金曜夜間クローズ有効
extern int      InpFridayCloseHour  = 21;               // 金曜クローズ時刻 (サーバー時間)

datetime lastBarTime = 0;

//+------------------------------------------------------------------+
//| ロット正規化関数 (ゼロ除算防止・ブローカー仕様自動適合)          |
//+------------------------------------------------------------------+
double NormalizeLot(double requestedLot)
{
   double minLot  = MarketInfo(Symbol(), MODE_MINLOT);
   double maxLot  = MarketInfo(Symbol(), MODE_MAXLOT);
   double lotStep = MarketInfo(Symbol(), MODE_LOTSTEP);

   if(lotStep <= 0.0) lotStep = 0.01;
   if(minLot <= 0.0)  minLot  = 0.01;
   if(maxLot <= 0.0)  maxLot  = 100.0;
   if(maxLot > InpMaxLot) maxLot = InpMaxLot;

   double normalized = MathFloor(requestedLot / lotStep) * lotStep;
   if(normalized < minLot) normalized = minLot;
   if(normalized > maxLot) normalized = maxLot;

   int digits = 2;
   if(lotStep == 0.1) digits = 1;
   else if(lotStep == 1.0) digits = 0;

   return NormalizeDouble(normalized, digits);
}

//+------------------------------------------------------------------+
//| リスクベースのロット計算                                         |
//+------------------------------------------------------------------+
double CalculateRiskLot(double slDistancePips)
{
   if(InpRiskPercent <= 0.0 || slDistancePips <= 0.0)
   {
      return NormalizeLot(InpFixedLot);
   }

   double equity = AccountEquity();
   if(equity <= 0.0) equity = AccountBalance();
   if(equity <= 0.0) return NormalizeLot(InpFixedLot);

   double riskAmount = equity * (InpRiskPercent / 100.0);
   double tickValue = MarketInfo(Symbol(), MODE_TICKVALUE);
   double tickSize  = MarketInfo(Symbol(), MODE_TICKSIZE);

   if(tickSize <= 0.0 || tickValue <= 0.0 || Point <= 0.0)
   {
      return NormalizeLot(InpFixedLot);
   }

   double pipValuePerLot = (tickValue / tickSize) * (Point * 10.0);
   if(pipValuePerLot <= 0.0) return NormalizeLot(InpFixedLot);

   double calculatedLot = riskAmount / (slDistancePips * pipValuePerLot);
   return NormalizeLot(calculatedLot);
}

//+------------------------------------------------------------------+
//| 初期化関数                                                       |
//+------------------------------------------------------------------+
int OnInit()
{
   Print("【MT4起動】", InpTradeComment, " 初期化成功。Magic: ", InpMagicNumber);
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| 終了関数                                                         |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   Print("【MT4終了】", InpTradeComment, " 解放。理由コード: ", reason);
}

//+------------------------------------------------------------------+
//| メイン処理 (OnTick)                                              |
//+------------------------------------------------------------------+
void OnTick()
{
   if(Point <= 0.0) return;

   // 1. 金曜夜間クローズ判定
   if(InpCloseOnFriday && DayOfWeek() == 5 && TimeHour(TimeCurrent()) >= InpFridayCloseHour)
   {
      CloseAllPositions("金曜夜間クローズ");
      return;
   }

   // 2. トレーリングストップ
   if(InpUseTrailingStop)
   {
      ExecuteTrailingStop();
   }

   // 3. バー確定時のみエントリー判定
   if(Time[0] == lastBarTime) return;
   lastBarTime = Time[0];

   // 4. スプレッドチェック
   int currentSpread = (int)MarketInfo(Symbol(), MODE_SPREAD);
   if(currentSpread > InpMaxSpread) return;

   // 5. インジケーター計算
   double fastEMA1 = iMA(Symbol(), 0, InpFastEMA, 0, MODE_EMA, PRICE_CLOSE, 1);
   double fastEMA2 = iMA(Symbol(), 0, InpFastEMA, 0, MODE_EMA, PRICE_CLOSE, 2);
   double slowEMA1 = iMA(Symbol(), 0, InpSlowEMA, 0, MODE_EMA, PRICE_CLOSE, 1);
   double slowEMA2 = iMA(Symbol(), 0, InpSlowEMA, 0, MODE_EMA, PRICE_CLOSE, 2);

   double curATR = iATR(Symbol(), 0, InpATRPeriod, 1);
   if(curATR <= 0.0) return;

   double curRSI = iRSI(Symbol(), 0, InpRSIPeriod, PRICE_CLOSE, 1);

   // オープンポジション数確認
   int openCount = 0;
   for(int i = 0; i < OrdersTotal(); i++)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderSymbol() == Symbol() && OrderMagicNumber() == InpMagicNumber)
         {
            openCount++;
         }
      }
   }
   if(openCount >= InpMaxPositions) return;

   bool isGoldenCross = (fastEMA2 <= slowEMA2 && fastEMA1 > slowEMA1);
   bool isDeadCross   = (fastEMA2 >= slowEMA2 && fastEMA1 < slowEMA1);

   if(isGoldenCross && Bid > slowEMA1 && curRSI < InpRSIOverbought)
   {
      double slDist = curATR * InpAtrMultiplierSL;
      double tpDist = curATR * InpAtrMultiplierTP;
      double slPrice = NormalizeDouble(Ask - slDist, Digits);
      double tpPrice = NormalizeDouble(Ask + tpDist, Digits);
      double slPips = slDist / (Point * 10.0);
      double lot = CalculateRiskLot(slPips);

      int ticket = OrderSend(Symbol(), OP_BUY, lot, Ask, 3, slPrice, tpPrice, InpTradeComment, InpMagicNumber, 0, clrBlue);
      if(ticket > 0) Print("BUY成立 Ticket: ", ticket);
   }
   else if(isDeadCross && Ask < slowEMA1 && curRSI > InpRSIOversold)
   {
      double slDist = curATR * InpAtrMultiplierSL;
      double tpDist = curATR * InpAtrMultiplierTP;
      double slPrice = NormalizeDouble(Bid + slDist, Digits);
      double tpPrice = NormalizeDouble(Bid - tpDist, Digits);
      double slPips = slDist / (Point * 10.0);
      double lot = CalculateRiskLot(slPips);

      int ticket = OrderSend(Symbol(), OP_SELL, lot, Bid, 3, slPrice, tpPrice, InpTradeComment, InpMagicNumber, 0, clrRed);
      if(ticket > 0) Print("SELL成立 Ticket: ", ticket);
   }
}

//+------------------------------------------------------------------+
//| MT4用トレーリングストップ                                        |
//+------------------------------------------------------------------+
void ExecuteTrailingStop()
{
   double curATR = iATR(Symbol(), 0, InpATRPeriod, 1);
   if(curATR <= 0.0) return;

   double trailStartDist = curATR * InpTrailingStartATR;
   double trailFollowDist = curATR * InpTrailingDistATR;

   for(int i = 0; i < OrdersTotal(); i++)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderSymbol() == Symbol() && OrderMagicNumber() == InpMagicNumber)
         {
            if(OrderType() == OP_BUY)
            {
               if(Bid - OrderOpenPrice() >= trailStartDist)
               {
                  double newSL = NormalizeDouble(Bid - trailFollowDist, Digits);
                  if(newSL > OrderStopLoss() && newSL > OrderOpenPrice())
                  {
                     OrderModify(OrderTicket(), OrderOpenPrice(), newSL, OrderTakeProfit(), 0, clrNONE);
                  }
               }
            }
            else if(OrderType() == OP_SELL)
            {
               if(OrderOpenPrice() - Ask >= trailStartDist)
               {
                  double newSL = NormalizeDouble(Ask + trailFollowDist, Digits);
                  if((OrderStopLoss() == 0.0 || newSL < OrderStopLoss()) && newSL < OrderOpenPrice())
                  {
                     OrderModify(OrderTicket(), OrderOpenPrice(), newSL, OrderTakeProfit(), 0, clrNONE);
                  }
               }
            }
         }
      }
   }
}

//+------------------------------------------------------------------+
//| MT4用全決済                                                      |
//+------------------------------------------------------------------+
void CloseAllPositions(string reason)
{
   for(int i = OrdersTotal() - 1; i >= 0; i--)
   {
      if(OrderSelect(i, SELECT_BY_POS, MODE_TRADES))
      {
         if(OrderSymbol() == Symbol() && OrderMagicNumber() == InpMagicNumber)
         {
            if(OrderType() == OP_BUY)
               OrderClose(OrderTicket(), OrderLots(), Bid, 3, clrWhite);
            else if(OrderType() == OP_SELL)
               OrderClose(OrderTicket(), OrderLots(), Ask, 3, clrWhite);
         }
      }
   }
}
//+------------------------------------------------------------------+
`;
}
