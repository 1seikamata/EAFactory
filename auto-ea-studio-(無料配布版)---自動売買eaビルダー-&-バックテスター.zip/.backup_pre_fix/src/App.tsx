/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BuyerConfig, BacktestResult, EASpec, SalesPackage } from './types';
import { runBacktest } from './services/backtester';
import { generateEASpec } from './services/mqlGenerator';
import { buildSalesPackage } from './services/salesCopyGenerator';
import { Header } from './components/Header';
import { BuyerConfigCard } from './components/BuyerConfigCard';
import { BacktestDashboard } from './components/BacktestDashboard';
import { SourceCodePanel } from './components/SourceCodePanel';
import { SalesPackagePanel } from './components/SalesPackagePanel';
import { AiAssistantModal } from './components/AiAssistantModal';
import { UpgradeModal, UpgradeTrigger } from './components/UpgradeModal';
import { GenerationProgressModal } from './components/GenerationProgressModal';
import { LanguageProvider, useLanguage } from './i18n/LanguageContext';
import {
  CheckCircle2,
  TrendingUp,
  FileText,
  Code2,
  Lock,
} from 'lucide-react';

function AppContent() {
  const { t } = useLanguage();

  const [buyerConfig, setBuyerConfig] = useState<BuyerConfig>({
    pair: 'EURUSD',
    timeframe: 'M30',
    desiredPf: '1.2+',
    maxDrawdown: '10%',
    frequency: 'WEEKLY_1_3',
    maxPositions: '1',
    strategyPreset: 'AUTO',
    testPeriod: '3MONTHS',
  });

  const [eaSpec, setEaSpec] = useState<EASpec>(() => generateEASpec(buyerConfig));
  const [backtestResult, setBacktestResult] = useState<BacktestResult>(() =>
    runBacktest(buyerConfig)
  );
  const [salesPackage, setSalesPackage] = useState<SalesPackage>(() =>
    buildSalesPackage(buyerConfig, eaSpec, backtestResult)
  );

  const [isRunningBacktest, setIsRunningBacktest] = useState(false);
  const [isGeneratingModalOpen, setIsGeneratingModalOpen] = useState(false);
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [isUpgradeModalOpen, setIsUpgradeModalOpen] = useState(false);
  const [upgradeTrigger, setUpgradeTrigger] = useState<UpgradeTrigger>('GENERAL');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [activeSection, setActiveSection] = useState<'all' | 'backtest' | 'code' | 'sales'>('all');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleOpenUpgradeModal = (trigger: UpgradeTrigger = 'GENERAL') => {
    setUpgradeTrigger(trigger);
    setIsUpgradeModalOpen(true);
  };

  const handleExecuteBacktest = () => {
    const newBacktest = runBacktest(buyerConfig);
    const newEa = generateEASpec(buyerConfig);
    const newSales = buildSalesPackage(buyerConfig, newEa, newBacktest);

    setBacktestResult(newBacktest);
    setEaSpec(newEa);
    setSalesPackage(newSales);
    setIsRunningBacktest(true);
    setIsGeneratingModalOpen(true);
  };

  const handleGenerationComplete = () => {
    setIsGeneratingModalOpen(false);
    setIsRunningBacktest(false);
    showToast(t.common.toastGenerated);

    setTimeout(() => {
      const backtestEl = document.getElementById('backtest-dashboard');
      if (backtestEl) {
        backtestEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 150);
  };

  const handleApplyAiStrategy = (aiData: any) => {
    if (aiData.mql5Code) {
      setEaSpec((prev) => ({
        ...prev,
        name: aiData.eaName || prev.name,
        conceptSummary: aiData.concept || prev.conceptSummary,
        mql5Code: aiData.mql5Code,
        mql4Code: aiData.mql4Code || prev.mql4Code,
      }));
    }

    if (aiData.salesHeadline || aiData.salesDescription) {
      setSalesPackage((prev) => ({
        ...prev,
        title: aiData.salesHeadline || prev.title,
        productOverview: aiData.salesDescription || prev.productOverview,
      }));
    }

    const newBacktest = runBacktest(buyerConfig);
    setBacktestResult(newBacktest);
    showToast(t.common.toastAiApplied);
  };

  const handleExportAll = () => {
    const combinedData = {
      edition: 'Free_Edition',
      spec: eaSpec,
      backtest: backtestResult,
      sales: salesPackage,
      config: buyerConfig,
      exportedAt: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(combinedData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${eaSpec.name}_FreeEdition_Package.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showToast(t.common.toastExported);
  };

  return (
    <div
      id="app-root"
      className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-cyan-500 selection:text-slate-950"
    >
      {/* Toast alert */}
      {toastMessage && (
        <div
          id="app-toast-alert"
          className="fixed bottom-5 right-5 z-50 bg-cyan-600 text-slate-950 px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-bold animate-in slide-in-from-bottom-5 border border-cyan-400"
        >
          <CheckCircle2 className="w-4 h-4 text-slate-950" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <Header
        onOpenAiModal={() => setIsAiModalOpen(true)}
        onExportAll={handleExportAll}
        onOpenUpgradeModal={handleOpenUpgradeModal}
      />

      {/* Main Container */}
      <main id="main-content" className="max-w-7xl mx-auto px-4 lg:px-8 py-6 space-y-6">
        {/* Navigation Quick Filter Tabs */}
        <div
          id="navigation-tabs-bar"
          className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/70 p-2.5 rounded-xl border border-slate-800 shadow-md"
        >
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              id="nav-tab-all"
              onClick={() => setActiveSection('all')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                activeSection === 'all'
                  ? 'bg-slate-800 text-white border border-slate-700 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {t.common.allView}
            </button>
            <button
              id="nav-tab-backtest"
              onClick={() => setActiveSection('backtest')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeSection === 'backtest'
                  ? 'bg-slate-800 text-cyan-300 border border-slate-700 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.common.simulationNav} (PF {backtestResult.profitFactor})</span>
            </button>
            <button
              id="nav-tab-code"
              onClick={() => setActiveSection('code')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeSection === 'code'
                  ? 'bg-slate-800 text-cyan-300 border border-slate-700 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Code2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.common.codeNav}</span>
            </button>
            <button
              id="nav-tab-sales"
              onClick={() => setActiveSection('sales')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeSection === 'sales'
                  ? 'bg-slate-800 text-cyan-300 border border-slate-700 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-cyan-400" />
              <span>{t.common.salesNav}</span>
            </button>
          </div>

          <button
            id="nav-upgrade-button"
            type="button"
            onClick={() => handleOpenUpgradeModal('GENERAL')}
            className="flex items-center gap-1.5 text-xs text-amber-300 bg-amber-950/40 hover:bg-amber-950/70 border border-amber-800/60 px-3 py-1 rounded-lg transition cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>{t.common.proUnlockNav}</span>
          </button>
        </div>

        {/* 1. Buyer Configuration Card */}
        <BuyerConfigCard
          config={buyerConfig}
          onChange={(newCfg) => {
            setBuyerConfig(newCfg);
          }}
          onRunBacktest={handleExecuteBacktest}
          isRunning={isRunningBacktest}
          onOpenUpgradeModal={handleOpenUpgradeModal}
        />

        {/* 2. Backtest Dashboard */}
        {(activeSection === 'all' || activeSection === 'backtest') && (
          <BacktestDashboard
            result={backtestResult}
            config={buyerConfig}
            onOpenUpgradeModal={handleOpenUpgradeModal}
          />
        )}

        {/* 3. Source Code Panel & Error/Zero-divide Re-check */}
        {(activeSection === 'all' || activeSection === 'code') && (
          <SourceCodePanel
            eaSpec={eaSpec}
            onOpenUpgradeModal={handleOpenUpgradeModal}
          />
        )}

        {/* 4. Sales Package & Manual Panel */}
        {(activeSection === 'all' || activeSection === 'sales') && (
          <SalesPackagePanel salesPackage={salesPackage} />
        )}
      </main>

      {/* Upgrade Guidance Modal */}
      <UpgradeModal
        isOpen={isUpgradeModalOpen}
        onClose={() => setIsUpgradeModalOpen(false)}
        trigger={upgradeTrigger}
      />

      {/* Gemini AI Strategy Customizer Modal */}
      <AiAssistantModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        config={buyerConfig}
        onApplyAiStrategy={handleApplyAiStrategy}
      />

      {/* Realistic Quant Simulation Progress Modal */}
      <GenerationProgressModal
        isOpen={isGeneratingModalOpen}
        config={buyerConfig}
        onComplete={handleGenerationComplete}
        onOpenUpgradeModal={handleOpenUpgradeModal}
      />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}

